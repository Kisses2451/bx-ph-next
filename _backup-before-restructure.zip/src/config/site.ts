export const siteName = 'Bloodlust Philippines'
