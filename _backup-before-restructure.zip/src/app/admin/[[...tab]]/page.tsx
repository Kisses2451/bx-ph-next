import type { Metadata } from 'next'
import { redirect } from 'next/navigation'
import { AdminRoute } from './AdminRoute'

export const metadata: Metadata = {
  title: 'Admin',
  robots: { index: false, follow: false },
}

// Handles /admin plus /admin/players, /admin/latest-updates, /admin/games,
// /admin/partners, /admin/events and /admin/staffs.
const ADMIN_TABS = ['players', 'latest-updates', 'games', 'partners', 'events', 'staffs']

export default async function Page({ params }: { params: Promise<{ tab?: string[] }> }) {
  const { tab } = await params

  if (tab && (tab.length > 1 || !ADMIN_TABS.includes(tab[0]))) {
    redirect('/')
  }

  return <AdminRoute />
}
