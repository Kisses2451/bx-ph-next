'use client'

import { Center, Spinner } from '@chakra-ui/react'
import { Suspense } from 'react'
import { ProtectedRoute } from '../../../components/ProtectedRoute'
import { AdminPage } from '../../../views/AdminPage'

export function AdminRoute() {
  return (
    // AdminPage reads ?tab= via useSearchParams, which Next.js requires inside Suspense.
    <Suspense fallback={<Center minH="50vh"><Spinner size="lg" color="brand.500" /></Center>}>
      <ProtectedRoute>
        <AdminPage />
      </ProtectedRoute>
    </Suspense>
  )
}
