'use client'

import { Center, Spinner, Text } from '@chakra-ui/react'

// Shown while a route segment loads (replaces the old <Suspense fallback={<PageLoader />}>).
export default function Loading() {
  return (
    <Center minH="50vh" flexDirection="column" gap={3}>
      <Spinner size="lg" color="brand.500" />
      <Text fontSize="sm" color="gray.500">Loading page…</Text>
    </Center>
  )
}
