'use client'

import { Center, Spinner } from '@chakra-ui/react'
import { useRouter } from 'next/navigation'
import { useEffect } from 'react'

// Unknown URLs go back to the home page, like the old <Navigate to="/" replace /> route.
export default function NotFound() {
  const router = useRouter()

  useEffect(() => {
    router.replace('/')
  }, [router])

  return (
    <Center minH="50vh">
      <Spinner size="lg" color="brand.500" />
    </Center>
  )
}
