import type { Metadata } from 'next'
import { SuccessPage } from '../../../views/SuccessPage'

export const metadata: Metadata = { title: 'Application submitted' }

export default function Page() {
  return <SuccessPage />
}
