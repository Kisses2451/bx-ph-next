import type { Metadata } from 'next'
import { ApplyPage } from '../../views/ApplyPage'

export const metadata: Metadata = { title: 'Join Now' }

export default function Page() {
  return <ApplyPage />
}
