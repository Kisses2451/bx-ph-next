import '@fontsource/chakra-petch/300.css'
import '@fontsource/chakra-petch/400.css'
import '@fontsource/chakra-petch/500.css'
import '@fontsource/chakra-petch/600.css'
import '@fontsource/chakra-petch/700.css'
import '../index.css'
import type { Metadata, Viewport } from 'next'
import type { ReactNode } from 'react'
import { Layout } from '../components/Layout'
import { siteName } from '../config/site'
import { Providers } from './providers'

export const metadata: Metadata = {
  title: {
    default: siteName,
    template: `%s | ${siteName}`,
  },
  icons: {
    icon: { url: '/bx-logo.svg', type: 'image/svg+xml' },
  },
}

export const viewport: Viewport = {
  width: 'device-width',
  initialScale: 1,
}

// Runs before first paint (same as the inline script in the old index.html) so the
// saved theme applies without a flash, and marks the page as JS-enabled for Reveal.
const themeBootstrap = `(() => {
  document.documentElement.classList.add('js')
  try {
    const savedTheme = window.localStorage.getItem('bx-theme')
    const prefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches
    document.documentElement.dataset.theme = savedTheme || (prefersDark ? 'dark' : 'light')
  } catch (error) {
    document.documentElement.dataset.theme = 'dark'
  }
})()`

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en" suppressHydrationWarning>
      <head>
        <script dangerouslySetInnerHTML={{ __html: themeBootstrap }} />
      </head>
      <body>
        <noscript>
          <style>{'.reveal,[data-reveal]{opacity:1!important;transform:none!important;visibility:visible!important;clip-path:none!important}'}</style>
        </noscript>
        {/* #root is kept because index.css styles and animates it. */}
        <div id="root">
          <Providers>
            <Layout>{children}</Layout>
          </Providers>
        </div>
      </body>
    </html>
  )
}
