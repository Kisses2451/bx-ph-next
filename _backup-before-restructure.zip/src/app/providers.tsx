'use client'

import { CacheProvider } from '@chakra-ui/next-js'
import { ChakraProvider, ColorModeScript, useColorMode } from '@chakra-ui/react'
import { useEffect, type ReactNode } from 'react'
import { ConfirmProvider } from '../components/ConfirmDialog'
import { ErrorBoundary } from '../components/ErrorBoundary'
import { PlayerProvider } from '../context/PlayerContext'
import { theme } from '../theme'

function ThemeSync() {
  const { colorMode } = useColorMode()

  useEffect(() => {
    document.documentElement.dataset.theme = colorMode
    try {
      window.localStorage.setItem('bx-theme', colorMode)
    } catch {
      // Storage unavailable; the theme still applies for this visit.
    }
  }, [colorMode])

  return null
}

// Everything that used to live in App.tsx: Chakra, theme sync, and app-wide context.
export function Providers({ children }: { children: ReactNode }) {
  return (
    <CacheProvider>
      <ColorModeScript initialColorMode={theme.config.initialColorMode} />
      <ChakraProvider theme={theme}>
        <ThemeSync />
        <ConfirmProvider>
          <PlayerProvider>
            <ErrorBoundary>{children}</ErrorBoundary>
          </PlayerProvider>
        </ConfirmProvider>
      </ChakraProvider>
    </CacheProvider>
  )
}
