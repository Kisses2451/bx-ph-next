import type { Metadata } from 'next'
import { ApplyPage } from '../../views/ApplyPage'

// /join and /apply show the same page; the join modal opens automatically on both.
export const metadata: Metadata = { title: 'Join Now' }

export default function Page() {
  return <ApplyPage />
}
