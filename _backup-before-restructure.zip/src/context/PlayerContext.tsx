import { createContext, useCallback, useContext, useEffect, useMemo, useState, type ReactNode } from 'react'
import { useLocalStorage } from '../hooks/useLocalStorage'
import { supabase } from '../lib/supabase'
import type { EventItem, LatestUpdateItem, StaffMember } from '../types/player'

type UserRole = 'guest' | 'admin'

type PlayerContextValue = {
  events: EventItem[]
  staffMembers: StaffMember[]
  latestUpdates: LatestUpdateItem[]
  role: UserRole
  isAuthenticated: boolean
  authLoading: boolean
  authError: string | null
  login: (nextRole?: UserRole) => void
  logout: () => void
  addEvent: (event: EventItem) => void
  updateEvent: (event: EventItem) => void
  deleteEvent: (eventId: string) => void
  addStaffMember: (member: StaffMember) => void
  updateStaffMember: (member: StaffMember) => void
  deleteStaffMember: (memberId: string) => void
  addLatestUpdate: (update: LatestUpdateItem) => void
  updateLatestUpdate: (update: LatestUpdateItem) => void
  deleteLatestUpdate: (updateId: string) => void
}

const PlayerContext = createContext<PlayerContextValue | undefined>(undefined)

function getAdminEmailAllowlist() {
  return (process.env.NEXT_PUBLIC_ADMIN_EMAIL ?? '')
    .split(',')
    .map((value: string) => value.trim().toLowerCase())
    .filter(Boolean)
}

async function resolveAdminRole(client: NonNullable<typeof supabase>, userId: string, email: string | null) {
  const adminEmails = getAdminEmailAllowlist()

  if (adminEmails.includes((email ?? '').toLowerCase())) {
    return 'admin'
  }

  const { data, error } = await client
    .from('admin_users')
    .select('role')
    .eq('user_id', userId)
    .maybeSingle()

  if (error && error.code !== 'PGRST116') {
    console.error('Admin role lookup failed:', error)
    return 'guest'
  }

  if (!data) {
    return 'guest'
  }

  return data.role === 'admin' ? 'admin' : 'guest'
}

// Shared app state keeps the admin dashboard and application flow coordinated.
export function PlayerProvider({ children }: { children: ReactNode }) {
  const [events, setEvents] = useLocalStorage<EventItem[]>('playerPortalEvents', [])
  const [staffMembers, setStaffMembers] = useLocalStorage<StaffMember[]>('playerPortalStaff', [])
  const [latestUpdates, setLatestUpdates] = useLocalStorage<LatestUpdateItem[]>('playerPortalUpdates', [])
  const [isAuthenticated, setIsAuthenticated] = useLocalStorage<boolean>('playerPortalAdmin', false)
  const [role, setRole] = useLocalStorage<UserRole>('playerPortalRole', 'guest')
  const [authLoading, setAuthLoading] = useState(true)
  const [authError, setAuthError] = useState<string | null>(null)

  useEffect(() => {
    const client = supabase

    if (!client) {
      setIsAuthenticated(false)
      setRole('guest')
      setAuthLoading(false)
      setAuthError('Supabase is not configured. Add NEXT_PUBLIC_SUPABASE_URL and NEXT_PUBLIC_SUPABASE_ANON_KEY to your .env.local file.')
      return
    }

    let ignore = false

    const syncSession = async () => {
      try {
        const { data: { session }, error } = await client.auth.getSession()
        if (error) {
          throw error
        }

        if (ignore) return

        const user = session?.user
        if (!user) {
          setIsAuthenticated(false)
          setRole('guest')
          setAuthError(null)
          setAuthLoading(false)
          return
        }

        const nextRole = await resolveAdminRole(client, user.id, user.email ?? null)
        setIsAuthenticated(true)
        setRole(nextRole)
        setAuthError(null)
      } catch (error) {
        console.error('Supabase session sync failed:', error)
        if (!ignore) {
          setIsAuthenticated(false)
          setRole('guest')
          setAuthError('Unable to validate the admin session. Check your Supabase configuration and auth settings.')
        }
      } finally {
        if (!ignore) setAuthLoading(false)
      }
    }

    syncSession()

    const { data: { subscription } } = client.auth.onAuthStateChange(async (_event, session) => {
      const user = session?.user
      if (!user) {
        setIsAuthenticated(false)
        setRole('guest')
        setAuthError(null)
        setAuthLoading(false)
        return
      }

      const nextRole = await resolveAdminRole(client, user.id, user.email ?? null)
      setIsAuthenticated(true)
      setRole(nextRole)
      setAuthError(null)
      setAuthLoading(false)
    })

    return () => {
      ignore = true
      subscription.unsubscribe()
    }
  }, [setIsAuthenticated, setRole])

  const login = useCallback((nextRole: UserRole = 'admin') => {
    setIsAuthenticated(true)
    setRole(nextRole)
  }, [setIsAuthenticated, setRole])

  const logout = useCallback(async () => {
    if (supabase) {
      await supabase.auth.signOut()
    }
    setIsAuthenticated(false)
    setRole('guest')
    setAuthError(null)
  }, [setIsAuthenticated, setRole])

  const addEvent = useCallback((event: EventItem) => {
    setEvents((current) => [event, ...current])
  }, [setEvents])

  const updateEvent = useCallback((event: EventItem) => {
    setEvents((current) => current.map((item) => item.id === event.id ? event : item))
  }, [setEvents])

  const deleteEvent = useCallback((eventId: string) => {
    setEvents((current) => current.filter((event) => event.id !== eventId))
  }, [setEvents])

  const addStaffMember = useCallback((member: StaffMember) => {
    setStaffMembers((current) => [member, ...current])
  }, [setStaffMembers])

  const updateStaffMember = useCallback((member: StaffMember) => {
    setStaffMembers((current) => current.map((item) => item.id === member.id ? member : item))
  }, [setStaffMembers])

  const deleteStaffMember = useCallback((memberId: string) => {
    setStaffMembers((current) => current.filter((member) => member.id !== memberId))
  }, [setStaffMembers])

  const addLatestUpdate = useCallback((update: LatestUpdateItem) => {
    setLatestUpdates((current) => [update, ...current])
  }, [setLatestUpdates])

  const updateLatestUpdate = useCallback((update: LatestUpdateItem) => {
    setLatestUpdates((current) => current.map((item) => item.id === update.id ? update : item))
  }, [setLatestUpdates])

  const deleteLatestUpdate = useCallback((updateId: string) => {
    setLatestUpdates((current) => current.filter((item) => item.id !== updateId))
  }, [setLatestUpdates])

  const value = useMemo<PlayerContextValue>(() => ({
    events,
    staffMembers,
    latestUpdates,
    role,
    isAuthenticated,
    authLoading,
    authError,
    login,
    logout,
    addEvent,
    updateEvent,
    deleteEvent,
    addStaffMember,
    updateStaffMember,
    deleteStaffMember,
    addLatestUpdate,
    updateLatestUpdate,
    deleteLatestUpdate,
  }), [events, staffMembers, latestUpdates, role, isAuthenticated, authLoading, authError, login, logout, addEvent, updateEvent, deleteEvent, addStaffMember, updateStaffMember, deleteStaffMember, addLatestUpdate, updateLatestUpdate, deleteLatestUpdate])

  return (
    <PlayerContext.Provider value={value}>
      {children}
    </PlayerContext.Provider>
  )
}

export function usePlayers() {
  const context = useContext(PlayerContext)

  if (!context) {
    throw new Error('usePlayers must be used within a PlayerProvider')
  }

  return context
}
