// sessionStorage key used to hand the submitted applicant from ApplyForm to the success page.
export const LAST_APPLICANT_KEY = 'bx-last-applicant'
