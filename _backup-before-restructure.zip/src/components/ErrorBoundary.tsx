import { Alert, AlertIcon, Box, Heading, Text } from '@chakra-ui/react'
import type { ErrorInfo, ReactNode } from 'react'
import { Component } from 'react'

interface ErrorBoundaryProps {
  children: ReactNode
}

interface ErrorBoundaryState {
  hasError: boolean
}

export class ErrorBoundary extends Component<ErrorBoundaryProps, ErrorBoundaryState> {
  state: ErrorBoundaryState = {
    hasError: false,
  }

  static getDerivedStateFromError(): ErrorBoundaryState {
    return { hasError: true }
  }

  componentDidCatch(error: Error, errorInfo: ErrorInfo) {
    console.error('Application error:', error, errorInfo)
  }

  render() {
    if (this.state.hasError) {
      return (
        <Box minH="60vh" display="flex" alignItems="center" justifyContent="center" p={6}>
          <Alert status="error" variant="subtle" borderRadius="lg" maxW="xl" flexDirection="column" alignItems="flex-start" p={8}>
            <AlertIcon boxSize="8" />
            <Heading as="h2" size="lg" mt={2}>
              Something went wrong
            </Heading>
            <Text mt={2}>
              The app encountered an unexpected error. Please refresh the page or return to the home screen.
            </Text>
          </Alert>
        </Box>
      )
    }

    return this.props.children
  }
}
