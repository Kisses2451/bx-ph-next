import { LogoTile } from './LogoTile'
import type { SupabaseGame } from '../types/player'

interface FeaturedGameCardProps {
  game: SupabaseGame
}

export function FeaturedGameCard({ game }: FeaturedGameCardProps) {
  return <LogoTile logoUrl={game.image_url} name={game.title} tone="game" />
}