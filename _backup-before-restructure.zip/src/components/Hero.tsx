'use client'

import { Box, Button, Container, Heading, Image, Stack, Text } from '@chakra-ui/react'
import { useEffect, useState } from 'react'
import RouterLink from 'next/link'
import { siteName } from '../config/site'
import { usePlayers } from '../context/PlayerContext'

const bxLogo = '/bx-logo.png'

export function Hero() {
  const { role, authLoading } = usePlayers()
  const showAdminAccess = !authLoading && role !== 'admin'
  const [showScrollCue, setShowScrollCue] = useState(true)

  useEffect(() => {
    const handleScroll = () => {
      if (window.scrollY > 24) setShowScrollCue(false)
    }
    window.addEventListener('scroll', handleScroll, { passive: true })
    return () => window.removeEventListener('scroll', handleScroll)
  }, [])

  return (
    <Box className="hero-editorial" color="white" width="100%">
      <Container className="shared-container" maxW="none" px={0} py={0}>
        <Stack direction={{ base: 'column', lg: 'row' }} align="flex-start" justify="space-between" spacing={5}>
          <Box className="hero-editorial__content" flex={2}>
            <Text className="editorial-eyebrow">Performance recruitment system / Est. 2021</Text>
            <Heading as="h1" className="hero-editorial__title" aria-label={siteName} fontSize="clamp(2.75rem, 8vw, 6rem)" lineHeight="1.05" letterSpacing="0.01em">
              <span aria-hidden="true" className="hero-editorial__title-line">BLOODLUST</span>
              <span aria-hidden="true" className="hero-editorial__title-line">PHILIPPINES CORP.</span>
            </Heading>
            <Text className="hero-editorial__copy">
              Discover, review, and onboard standout talent through a streamlined player application portal designed for modern football operations.
            </Text>
            <Stack className="hero-editorial__actions" direction={{ base: 'column', sm: 'row' }}>
              <Button
                as={RouterLink}
                className="btn-primary"
                href="/apply"
                size="lg"
                bg="var(--btn-primary-bg)"
                color="var(--btn-primary-text)"
                _hover={{ bg: 'var(--btn-primary-bg-hover)', color: 'var(--btn-primary-text)' }}
                onClick={(event) => {
                  event.preventDefault()
                  window.dispatchEvent(new CustomEvent('open-join-flow', { detail: event.currentTarget }))
                }}
              >
                Apply Now
              </Button>
              {authLoading ? <Box aria-hidden="true" w={{ base: 'full', sm: 'auto' }} minW={{ sm: '160px' }} h="48px" visibility="hidden" /> : null}
              {showAdminAccess ? <Button
                  as={RouterLink}
                  href="/admin"
                  size="lg"
                  variant="outline"
                  borderColor="whiteAlpha.400"
                  color="white"
                >
                  Admin Access
                </Button> : null}
            </Stack>
          </Box>

          <Box flex={1} display="flex" justifyContent="flex-end" w="100%">
            <Box
              borderTop="1px solid"
              borderBottom="1px solid"
              borderColor="whiteAlpha.400"
              py={5}
              w={{ base: '100%', lg: '360px' }}
            >
              <Box className="hero-editorial__logo-panel" overflow="hidden" aspectRatio={1} display="grid" placeItems="center" bg="transparent" border="1px solid" borderColor="brand.200" p={{ base: 4, md: 5 }}>
                <Image
                  src={bxLogo}
                  alt="Bloodlust Philippines logo"
                  width={900}
                  height={900}
                  h="100%"
                  display="block"
                  objectFit="contain"
                  objectPosition="center"
                  w="100%"
                  bg="transparent"
                  opacity={1}
                  filter="none"
                  mixBlendMode="normal"
                  decoding="async"
                />
              </Box>
              <Stack direction="row" justify="space-between" align="flex-start" mt={4}>
                <Box>
                  <Text fontSize="xs" color="gray.300" textTransform="uppercase" letterSpacing="0.14em">Organization identity</Text>
                  <Text fontSize="lg" fontWeight="bold">{siteName}</Text>
                </Box>
                <Box textAlign="right" maxW="130px">
                  <Text fontSize="xs" color="gray.300" textTransform="uppercase" letterSpacing="0.14em">Status</Text>
                  <Text fontSize="md" fontWeight="bold" color="accent.500">Open recruitment</Text>
                </Box>
              </Stack>
            </Box>
          </Box>
        </Stack>
      </Container>
      <Box className={`hero-editorial__scroll-cue${showScrollCue ? '' : ' hero-editorial__scroll-cue--hidden'}`} aria-hidden="true">
        <Box className="hero-editorial__scroll-line" />
        <Text>SCROLL</Text>
      </Box>
    </Box>
  )
}
