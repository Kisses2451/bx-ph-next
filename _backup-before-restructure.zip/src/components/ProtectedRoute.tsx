import {
  Alert,
  Box,
  Button,
  Flex,
  FormControl,
  FormErrorMessage,
  FormLabel,
  Heading,
  Input,
  Spinner,
  Stack,
  Text,
} from '@chakra-ui/react'
import { useState, type ReactNode } from 'react'
import { usePlayers } from '../context/PlayerContext'
import { signInWithEmail, supabase } from '../lib/supabase'

interface ProtectedRouteProps {
  children: ReactNode
}

export function ProtectedRoute({ children }: ProtectedRouteProps) {
  const { isAuthenticated, role, authLoading, authError, login, logout } = usePlayers()
  const [email, setEmail] = useState(process.env.NEXT_PUBLIC_ADMIN_EMAIL ?? '')
  const [password, setPassword] = useState('')
  const [formError, setFormError] = useState('')
  const [submitting, setSubmitting] = useState(false)

  if (authLoading) {
    return (
      <Flex minH="50vh" align="center" justify="center" direction="column" gap={4}>
        <Spinner size="lg" color="brand.500" />
        <Text>Checking admin session...</Text>
      </Flex>
    )
  }

  if (isAuthenticated && role === 'admin') {
    return children
  }

  if (isAuthenticated && role !== 'admin') {
    return (
      <Flex minH="50vh" align="center" justify="center" direction="column" gap={4}>
        <Alert status="warning" maxW="lg">You are signed in, but this account is not authorized for admin access.</Alert>
        <Button className="btn-primary" onClick={() => logout()} colorScheme="brand">Sign out</Button>
      </Flex>
    )
  }

  const handleSubmit = async (event: React.FormEvent<HTMLFormElement>) => {
    event.preventDefault()
    setSubmitting(true)
    setFormError('')

    const result = await signInWithEmail(email, password)

    if (!result.success) {
      setFormError(result.message ?? 'Authentication failed.')
      setSubmitting(false)
      return
    }

    const adminEmails = (process.env.NEXT_PUBLIC_ADMIN_EMAIL ?? '')
      .split(',')
      .map((value: string) => value.trim().toLowerCase())
      .filter(Boolean)

    const userEmail = (result.user?.email ?? email).toLowerCase()
    let isAdminUser = adminEmails.includes(userEmail)

    if (!isAdminUser && supabase && result.user?.id) {
      const { data, error } = await supabase
        .from('admin_users')
        .select('role')
        .eq('user_id', result.user.id)
        .maybeSingle()

      if (error && error.code !== 'PGRST116') {
        console.error('Admin authorization lookup failed:', error)
      }

      isAdminUser = data?.role === 'admin'
    }

    if (!isAdminUser) {
      setFormError('This account is not authorized for admin access.')
      setSubmitting(false)
      return
    }

    login('admin')
    setSubmitting(false)
  }

  return (
    <Flex minH="50vh" align="center" justify="center" px={4}>
      <Box w="full" maxW="lg" bg="var(--surface)" borderRadius="0" border="1px solid" borderColor="var(--border)" p={8}>
        <Stack spacing={5}>
          <Heading as="h1" size="lg">Admin access</Heading>
          <Text color="var(--text-muted)">Please sign in to continue.</Text>

          {(authError || formError) && (
            <Alert status="error">{authError ?? formError}</Alert>
          )}

          <form onSubmit={handleSubmit}>
            <Stack spacing={4}>
              <FormControl isInvalid={Boolean(formError)}>
                <FormLabel>Email</FormLabel>
                <Input type="email" value={email} onChange={(event) => setEmail(event.target.value)} />
              </FormControl>

              <FormControl isInvalid={Boolean(formError)}>
                <FormLabel>Password</FormLabel>
                <Input type="password" value={password} onChange={(event) => setPassword(event.target.value)} />
                {formError && <FormErrorMessage>{formError}</FormErrorMessage>}
              </FormControl>

              <Button type="submit" className="btn-primary" colorScheme="brand" isLoading={submitting}>
                Sign in
              </Button>
            </Stack>
          </form>
        </Stack>
      </Box>
    </Flex>
  )
}
