import { DeleteIcon, EditIcon, ViewIcon } from '@chakra-ui/icons'
import {
  Avatar,
  Badge,
  Box,
  Button,
  Card,
  CardBody,
  Divider,
  Flex,
  Grid,
  HStack,
  Image,
  SimpleGrid,
  Table,
  TableContainer,
  Tbody,
  Td,
  Text,
  Th,
  Thead,
  Tr,
} from '@chakra-ui/react'
import type { PlayerRecord } from '../types'

const placeholderAvatar = 'https://placehold.co/120x120/4b1d2d/ffffff?text=Player'

interface AdminTableProps {
  players: PlayerRecord[]
  onEdit: (player: PlayerRecord) => void
  onDelete: (playerId: string) => void
  onApprove: (playerId: string) => void
  onReject: (playerId: string) => void
  viewMode: 'table' | 'card'
}

function getStatusColor(status: string) {
  switch (status) {
    case 'Approved':
      return 'green'
    case 'Rejected':
      return 'red'
    case 'Interview':
      return 'purple'
    default:
      return 'yellow'
  }
}

export function AdminTable({ players, onEdit, onDelete, onApprove, onReject, viewMode }: AdminTableProps) {
  if (viewMode === 'card') {
    return (
      <SimpleGrid columns={{ base: 1, md: 2, xl: 3 }} spacing={4}>
        {players.map((player) => (
          <Card key={player.id} borderRadius="xl" border="1px solid" borderColor="gray.200" transition="transform 0.2s ease" _hover={{ transform: 'translateY(-4px)' }}>
            <CardBody>
              <Flex align="center" justify="space-between" mb={4}>
                <Avatar name={player.name} src={player.photoUrl || placeholderAvatar} size="md" />
                <Badge colorScheme={getStatusColor(player.status)}>{player.status}</Badge>
              </Flex>
              <Text fontWeight="bold" fontSize="lg">{player.name}</Text>
              <Badge colorScheme={player.department === 'Community' ? 'purple' : 'blue'}>{player.department}</Badge>
              <Text my={2} fontSize="sm">{player.email}</Text>
              <Text fontSize="sm" color="gray.500">Applied: {player.dateApplied}</Text>
              <Divider my={3} />
              <HStack spacing={2} justify="flex-end">
                <Button size="sm" leftIcon={<EditIcon />} onClick={() => onEdit(player)}>
                  Edit
                </Button>
                <Button size="sm" variant="outline" colorScheme="green" onClick={() => onApprove(player.id)}>
                  Approve
                </Button>
                <Button size="sm" variant="outline" colorScheme="red" onClick={() => onReject(player.id)}>
                  Reject
                </Button>
                <Button size="sm" variant="ghost" colorScheme="gray" onClick={() => onDelete(player.id)} aria-label={`Delete ${player.name}`}>
                  <DeleteIcon />
                </Button>
              </HStack>
            </CardBody>
          </Card>
        ))}
      </SimpleGrid>
    )
  }

  return (
    <TableContainer border="1px solid" borderColor="gray.200" borderRadius="xl" bg="white">
      <Table variant="simple">
        <Thead bg="gray.50">
          <Tr>
            <Th>Player</Th>
            <Th>Department</Th>
            <Th>Status</Th>
            <Th>Date</Th>
            <Th>Actions</Th>
          </Tr>
        </Thead>
        <Tbody>
          {players.map((player) => (
            <Tr key={player.id}>
              <Td>
                <Flex align="center" gap={3}>
                  <Image
                    src={player.photoUrl || placeholderAvatar}
                    alt={`${player.name} profile`}
                    borderRadius="full"
                    boxSize="42px"
                    objectFit="cover"
                    fallbackSrc={placeholderAvatar}
                  />
                  <Box>
                    <Text fontWeight="bold">{player.name}</Text>
                    <Text fontSize="sm" color="gray.500">{player.email}</Text>
                  </Box>
                </Flex>
              </Td>
              <Td><Badge colorScheme={player.department === 'Community' ? 'purple' : 'blue'}>{player.department}</Badge></Td>
              <Td>
                <Badge colorScheme={getStatusColor(player.status)}>{player.status}</Badge>
              </Td>
              <Td>{player.dateApplied}</Td>
              <Td>
                <Grid templateColumns="repeat(4, minmax(0, 1fr))" gap={2}>
                  <Button size="sm" aria-label={`Edit ${player.name}`} onClick={() => onEdit(player)}>
                    <EditIcon />
                  </Button>
                  <Button size="sm" aria-label={`Approve ${player.name}`} colorScheme="green" onClick={() => onApprove(player.id)}>
                    <ViewIcon />
                  </Button>
                  <Button size="sm" aria-label={`Reject ${player.name}`} colorScheme="red" onClick={() => onReject(player.id)}>
                    <DeleteIcon />
                  </Button>
                  <Button size="sm" variant="ghost" colorScheme="gray" onClick={() => onDelete(player.id)} aria-label={`Delete ${player.name}`}>
                    <DeleteIcon />
                  </Button>
                </Grid>
              </Td>
            </Tr>
          ))}
        </Tbody>
      </Table>
    </TableContainer>
  )
}
