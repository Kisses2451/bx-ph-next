import {
  Button,
  Divider,
  Image,
  Modal,
  ModalBody,
  ModalCloseButton,
  ModalContent,
  ModalFooter,
  ModalHeader,
  ModalOverlay,
  Stack,
  Text,
  useColorModeValue,
} from '@chakra-ui/react'
import type { ApplicationPayload } from '../types'

interface ConfirmationModalProps {
  isOpen: boolean
  onClose: () => void
  onConfirm: () => void
  payload: ApplicationPayload | null
}

const placeholder = 'https://placehold.co/300x300/4b1d2d/ffffff?text=Player+Photo'

export function ConfirmationModal({ isOpen, onClose, onConfirm, payload }: ConfirmationModalProps) {
  const modalBg = useColorModeValue('var(--surface)', 'var(--surface)')

  if (!payload) return null

  return (
    <Modal isOpen={isOpen} onClose={onClose} isCentered size="lg">
      <ModalOverlay />
      <ModalContent bg={modalBg} borderRadius="0" border="1px solid" borderColor="var(--border)">
        <ModalHeader>Confirm application</ModalHeader>
        <ModalCloseButton aria-label="Close confirmation" />
        <ModalBody>
          <Stack spacing={4}>
            <Image
              src={payload.photo ? URL.createObjectURL(payload.photo) : placeholder}
              alt={`${payload.name} profile preview`}
              maxH="260px"
              objectFit="cover"
              borderRadius="lg"
            />
            <Text><strong>Name:</strong> {payload.name}</Text>
            <Text><strong>Department:</strong> {payload.department}</Text>
            <Text><strong>Email:</strong> {payload.email}</Text>
          </Stack>
          <Divider my={4} />
          <Text fontSize="sm" color="gray.500">
            Please review the data before submitting. Once confirmed, this application will be sent for review.
          </Text>
        </ModalBody>

        <ModalFooter>
          <Button variant="ghost" onClick={onClose} mr={3}>Back</Button>
          <Button className="btn-primary" colorScheme="brand" onClick={onConfirm}>Submit application</Button>
        </ModalFooter>
      </ModalContent>
    </Modal>
  )
}
