'use client'

import { MoonIcon, SunIcon } from '@chakra-ui/icons'
import { Box, Button, Container, Flex, Heading, Link as ChakraLink, Menu, MenuButton, MenuItem, MenuList, Tooltip, useColorMode } from '@chakra-ui/react'
import type { ReactNode } from 'react'
import { useEffect, useState } from 'react'
import { usePlayers } from '../context/PlayerContext'
import { NavLink as RouterNavLink } from './NavLink'
import { GlobalSearch } from './GlobalSearch'

const bxLogo = '/bx-logo.png'

type IconName = 'dashboard' | 'home' | 'partners' | 'about' | 'logout'

type NavItem = {
  to: string
  label: string
  icon: IconName
}

const publicItems: NavItem[] = [
  { to: '/', label: 'Home', icon: 'home' },
  { to: '/partners', label: 'Partners', icon: 'partners' },
  { to: '/about', label: 'About Us', icon: 'about' },
]

function NavIcon({ name }: { name: IconName }) {
  const paths: Record<IconName, ReactNode> = {
    dashboard: <><rect x="4" y="4" width="6" height="6" rx="1" /><rect x="14" y="4" width="6" height="6" rx="1" /><rect x="4" y="14" width="6" height="6" rx="1" /><rect x="14" y="14" width="6" height="6" rx="1" /></>,
    home: <><path d="m4 10 8-6 8 6" /><path d="M6 9.5V20h12V9.5" /><path d="M10 20v-6h4v6" /></>,
    partners: <><path d="m9.5 14.5 5-5" /><path d="M7.5 8.5 5.5 6.5a3 3 0 0 0-4.2 4.2l3 3a3 3 0 0 0 4.2 0l1-1" /><path d="m16.5 15.5 2 2a3 3 0 0 0 4.2-4.2l-3-3a3 3 0 0 0-4.2 0l-1 1" /></>,
    about: <><circle cx="12" cy="12" r="8.5" /><path d="M12 11v5" /><path d="M12 8h.01" /></>,
    logout: <><path d="M10 5H6.5A1.5 1.5 0 0 0 5 6.5v11A1.5 1.5 0 0 0 6.5 19H10" /><path d="m14 8 4 4-4 4" /><path d="M18 12H9" /></>,
  }

  return <svg aria-hidden="true" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" width="20" height="20">{paths[name]}</svg>
}

function openJoinFlow(event: React.MouseEvent<HTMLElement>) {
  event.preventDefault()
  window.dispatchEvent(new CustomEvent('open-join-flow', { detail: event.currentTarget }))
}

function NavLinkItem({ item, iconOnly = false }: { item: NavItem; iconOnly?: boolean }) {
  return <Tooltip label={item.label} placement="bottom" hasArrow openDelay={350}>
    <ChakraLink
      className={`navbar-nav-link ${iconOnly ? 'navbar-nav-link--icon' : ''}`}
      as={RouterNavLink}
      href={item.to}
      aria-label={item.label}
      _hover={{ textDecoration: 'none' }}
    >
      <NavIcon name={item.icon} />
      <span className="nav-label">{item.label}</span>
    </ChakraLink>
  </Tooltip>
}

export function Navbar() {
  const { colorMode, toggleColorMode } = useColorMode()
  const { isAuthenticated, logout } = usePlayers()
  const [isScrolled, setIsScrolled] = useState(false)
  const pageItems: NavItem[] = isAuthenticated ? [{ to: '/admin', label: 'Admin Dashboard', icon: 'dashboard' }, ...publicItems] : publicItems
  const joinItem: NavItem = { to: '/join', label: 'Join Now', icon: 'about' }

  useEffect(() => {
    const onScroll = () => setIsScrolled(window.scrollY > 16)
    onScroll()
    window.addEventListener('scroll', onScroll, { passive: true })
    return () => window.removeEventListener('scroll', onScroll)
  }, [])

  return <Box as="header" className={`site-navbar ${isAuthenticated ? 'site-navbar--admin' : ''} ${isScrolled ? 'site-navbar--scrolled' : ''}`} position="sticky" top={0} zIndex={1000} width="100%" bg={colorMode === 'dark' ? 'rgba(10,10,10,0.9)' : 'rgba(255,255,255,0.94)'} backdropFilter="blur(12px)" borderBottom="1px solid" borderColor={colorMode === 'dark' ? 'whiteAlpha.200' : 'gray.200'}>
    <Container className="shared-container" maxW="none" px={0}>
      <Flex className="navbar-row" align="center" gap={4} wrap="nowrap">
        <ChakraLink className="navbar-brand" as={RouterNavLink} href="/" aria-label="Bloodlust Philippines home" _hover={{ textDecoration: 'none' }}>
          <Flex align="center" gap={3} minW={0}>
            <Box className="navbar-mark" w={10} h={10} display="flex" alignItems="center" justifyContent="center"><img src={bxLogo} alt="Bloodlust Philippines logo" /></Box>
            <Heading className="navbar-wordmark" as="h2" size="md" letterSpacing="wide" lineHeight="shorter" fontWeight="900">BLOODLUST PHILIPPINES</Heading>
          </Flex>
        </ChakraLink>

        <Box className="navbar-search"><GlobalSearch /></Box>

        <Box className="navbar-links" as="nav" aria-label="Primary navigation">
          {pageItems.map((item) => <NavLinkItem key={item.to} item={item} iconOnly={isAuthenticated} />)}
        </Box>

        {isAuthenticated ? <Tooltip label="Log out" placement="bottom" hasArrow openDelay={350}>
          <Button className="navbar-logout navbar-logout--icon" variant="ghost" onClick={logout} aria-label="Log out of admin dashboard"><NavIcon name="logout" /><span className="nav-label">Log out</span></Button>
        </Tooltip> : null}

        <Tooltip label={joinItem.label} placement="bottom" hasArrow openDelay={350}>
          <ChakraLink className="navbar-join" as={RouterNavLink} href={joinItem.to} aria-label={joinItem.label} onClick={openJoinFlow} _hover={{ textDecoration: 'none' }}>
            <span className="nav-label">Join Now</span><span aria-hidden="true" className="navbar-join-arrow">-&gt;</span>
          </ChakraLink>
        </Tooltip>

        <Menu placement="bottom-end" closeOnSelect onClose={() => undefined}>
          <Tooltip label="More navigation" placement="bottom" hasArrow>
            <MenuButton as={Button} className="navbar-more" variant="ghost" aria-label="More navigation"><span aria-hidden="true">...</span></MenuButton>
          </Tooltip>
          <MenuList className="navbar-more-list">
            {pageItems.map((item) => <MenuItem key={item.to} as={RouterNavLink} href={item.to} icon={<NavIcon name={item.icon} />}>{item.label}</MenuItem>)}
            {isAuthenticated ? <MenuItem onClick={logout} icon={<NavIcon name="logout" />}>Log out</MenuItem> : null}
          </MenuList>
        </Menu>

        <Button className="navbar-theme-toggle" onClick={toggleColorMode} variant="ghost" aria-label="Toggle dark mode">{colorMode === 'dark' ? <SunIcon /> : <MoonIcon />}</Button>
      </Flex>
    </Container>
  </Box>
}
