import { CloseButton, useColorModeValue } from '@chakra-ui/react'
import { Box, FormControl, FormHelperText, FormLabel, HStack, Input, Stack, Text } from '@chakra-ui/react'

interface DateRangeFilterProps {
  fromDate: string
  toDate: string
  onFromDateChange: (value: string) => void
  onToDateChange: (value: string) => void
  onClear: () => void
}

export function DateRangeFilter({
  fromDate,
  toDate,
  onFromDateChange,
  onToDateChange,
  onClear,
}: DateRangeFilterProps) {
  const invalidRange = Boolean(fromDate && toDate && new Date(fromDate) > new Date(toDate))
  const panelBg = useColorModeValue('white', 'gray.950')
  const panelBorder = useColorModeValue('gray.200', 'whiteAlpha.200')
  const inputBg = useColorModeValue('white', 'gray.900')
  const inputBorder = useColorModeValue('gray.200', 'whiteAlpha.300')
  const valueColor = useColorModeValue('gray.900', 'white')
  const labelColor = useColorModeValue('gray.700', 'gray.200')
  const placeholderColor = useColorModeValue('gray.500', 'gray.400')

  return (
    <Box bg={panelBg} borderRadius="xl" border="1px solid" borderColor={panelBorder} p={4}>
      <HStack justify="space-between" align="center" mb={3}>
        <Text fontSize="sm" fontWeight="bold">Date range</Text>
        {(fromDate || toDate) && <CloseButton aria-label="Clear date range" onClick={onClear} size="sm" />}
      </HStack>
      <Stack direction={{ base: 'column', md: 'row' }} spacing={4}>
        <FormControl>
          <FormLabel fontSize="sm" color={labelColor}>From</FormLabel>
          <Input
            type="date"
            aria-label="Filter from date"
            value={fromDate}
            onChange={(event) => onFromDateChange(event.target.value)}
            color={valueColor}
            bg={inputBg}
            borderColor={inputBorder}
            _placeholder={{ color: placeholderColor }}
            _focus={{ borderColor: 'brand.500', boxShadow: '0 0 0 1px rgba(128,0,0,0.35)' }}
            sx={{ caretColor: 'brand.500' }}
          />
        </FormControl>
        <FormControl>
          <FormLabel fontSize="sm" color={labelColor}>To</FormLabel>
          <Input
            type="date"
            aria-label="Filter to date"
            value={toDate}
            onChange={(event) => onToDateChange(event.target.value)}
            color={valueColor}
            bg={inputBg}
            borderColor={inputBorder}
            _placeholder={{ color: placeholderColor }}
            _focus={{ borderColor: 'brand.500', boxShadow: '0 0 0 1px rgba(128,0,0,0.35)' }}
            sx={{ caretColor: 'brand.500' }}
          />
        </FormControl>
      </Stack>
      {invalidRange && (
        <FormHelperText color="red.500" mt={2}>From date cannot be later than To date.</FormHelperText>
      )}
    </Box>
  )
}
