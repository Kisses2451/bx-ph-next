'use client'

import { SearchIcon } from '@chakra-ui/icons'
import { Box, Button, CloseButton, Input, InputGroup, InputLeftElement, Link, Stack, Text, useColorModeValue } from '@chakra-ui/react'
import { useEffect, useMemo, useRef, useState } from 'react'
import RouterLink from 'next/link'
import { usePathname } from 'next/navigation'

const siteIndex = [
  { label: 'Home', path: '/', keywords: ['home', 'updates', 'club', 'recruitment', 'news'] },
  { label: 'About Us', path: '/about', keywords: ['about', 'team', 'staff', 'club', 'mission'] },
  { label: 'Partners', path: '/partners', keywords: ['partners', 'sponsors', 'allies', 'brands'] },
  { label: 'Admin Dashboard', path: '/admin', keywords: ['admin', 'dashboard', 'management', 'players'] },
  { label: 'Join Now', path: '/join', keywords: ['join', 'apply', 'players', 'register', 'tryouts'] },
  { label: 'Events', path: '/', keywords: ['events', 'calendar', 'schedule', 'showcase'] },
  { label: 'Latest Updates', path: '/', keywords: ['updates', 'news', 'recruitment', 'academy', 'scouting'] },
] as const

export function GlobalSearch() {
  const [query, setQuery] = useState('')
  const [isExpanded, setIsExpanded] = useState(false)
  const searchRef = useRef<HTMLDivElement>(null)
  const pathname = usePathname()
  const resultBg = useColorModeValue('white', 'gray.900')
  const resultBorder = useColorModeValue('gray.200', 'whiteAlpha.300')
  const resultHover = useColorModeValue('gray.100', 'whiteAlpha.100')
  const fieldBg = useColorModeValue('white', 'gray.800')

  const results = useMemo(() => {
    const normalized = query.trim().toLowerCase()
    if (!normalized) return []
    return siteIndex.filter((item) => item.label.toLowerCase().includes(normalized) || item.keywords.some((keyword) => keyword.includes(normalized)))
  }, [query])

  useEffect(() => {
    setQuery('')
    setIsExpanded(false)
  }, [pathname])

  useEffect(() => {
    if (!isExpanded) return
    const handleKeyDown = (event: KeyboardEvent) => {
      if (event.key === 'Escape') setIsExpanded(false)
    }
    const handlePointerDown = (event: PointerEvent) => {
      if (!searchRef.current?.contains(event.target as Node)) setIsExpanded(false)
    }
    document.addEventListener('keydown', handleKeyDown)
    document.addEventListener('pointerdown', handlePointerDown)
    return () => {
      document.removeEventListener('keydown', handleKeyDown)
      document.removeEventListener('pointerdown', handlePointerDown)
    }
  }, [isExpanded])

  const searchField = <InputGroup>
    <InputLeftElement pointerEvents="none" h="40px" pl={3}><SearchIcon color="gray.400" /></InputLeftElement>
    <Input aria-label="Global website search" placeholder="Search website" value={query} onChange={(event) => setQuery(event.target.value)} bg={fieldBg} borderColor={resultBorder} _focus={{ borderColor: 'brand.500', boxShadow: '0 0 0 1px var(--chakra-colors-brand-500)' }} pl={10} pr={query ? 10 : 4} h="40px" />
    {query ? <InputRightClear onClear={() => setQuery('')} /> : null}
  </InputGroup>

  return <Box ref={searchRef} className={`global-search ${isExpanded ? 'global-search--expanded' : ''}`}>
    <Button className="global-search-toggle" variant="ghost" aria-label="Open website search" onClick={() => setIsExpanded(true)}><SearchIcon /></Button>
    <Box className="global-search-field">{searchField}</Box>
    {query && results.length > 0 ? <Box className="global-search-results" position="absolute" top="calc(100% + 8px)" left={0} right={0} bg={resultBg} border="1px solid" borderColor={resultBorder} borderRadius="lg" boxShadow="lg" p={2} zIndex={30}><Stack spacing={1}>{results.map((item) => <Link key={item.path + item.label} as={RouterLink} href={item.path} onClick={() => setQuery('')} display="block" px={3} py={2} borderRadius="md" _hover={{ bg: resultHover, textDecoration: 'none' }}><Text fontWeight="semibold">{item.label}</Text></Link>)}</Stack></Box> : null}
  </Box>
}

function InputRightClear({ onClear }: { onClear: () => void }) {
  return <Box position="absolute" right={1} top={0} h="40px" display="flex" alignItems="center"><CloseButton aria-label="Clear website search" size="sm" onClick={onClear} /></Box>
}
