import { Button, Link, Modal, ModalBody, ModalCloseButton, ModalContent, ModalFooter, ModalHeader, ModalOverlay, Badge, Stack, Text } from '@chakra-ui/react'
import { useEffect, useRef } from 'react'
import { useLatestUpdates, type LatestUpdateRecord } from '../hooks/useLatestUpdates'

interface LatestUpdateAnnouncementModalProps {
  update: LatestUpdateRecord
  isOpen: boolean
  keepSection: boolean
  onClose: () => void
}

function formatDate(value: string | null) {
  if (!value) return ''
  const date = new Date(value)
  if (Number.isNaN(date.getTime())) return ''
  return new Intl.DateTimeFormat('en-PH', { dateStyle: 'long' }).format(date)
}

export function LatestUpdateAnnouncementModal({ update, isOpen, keepSection, onClose }: LatestUpdateAnnouncementModalProps) {
  const continueRef = useRef<HTMLButtonElement>(null)
  const { latestUpdate } = useLatestUpdates()
  const descriptionId = 'latest-update-announcement-description'
  const announcement = latestUpdate ?? update

  useEffect(() => {
    if (isOpen) window.setTimeout(() => continueRef.current?.focus(), 0)
  }, [isOpen])

  const closeAndScroll = () => {
    onClose()
    window.setTimeout(() => document.getElementById('latest-updates')?.scrollIntoView({ behavior: 'smooth', block: 'start' }), 0)
  }

  return (
    <Modal isOpen={isOpen} onClose={onClose} isCentered motionPreset="scale" size="md" closeOnOverlayClick>
      <ModalOverlay />
      <ModalContent className="latest-update-announcement" role="dialog" aria-modal="true" aria-labelledby="latest-update-announcement-title" aria-describedby={announcement.description ? descriptionId : undefined}>
        <ModalHeader>
          <Text className="latest-update-announcement__eyebrow">LATEST UPDATE</Text>
          {announcement.tag ? <Badge className="latest-update-announcement__tag">{announcement.tag}</Badge> : null}
          <Text as="h2" id="latest-update-announcement-title" className="latest-update-announcement__title">{announcement.title}</Text>
          {formatDate(announcement.published_at) ? <Text className="latest-update-announcement__date">{formatDate(announcement.published_at)}</Text> : null}
        </ModalHeader>
        <ModalCloseButton aria-label="Close latest update" />
        <ModalBody>
          {announcement.description ? <Text id={descriptionId} className="latest-update-announcement__description">{announcement.description}</Text> : null}
        </ModalBody>
        <ModalFooter>
          <Stack direction={{ base: 'column-reverse', sm: 'row' }} align="center" w="100%" justify="space-between" spacing={4}>
            {keepSection ? <Link className="latest-update-announcement__link" onClick={closeAndScroll}>View all updates</Link> : <span />}
            <Button ref={continueRef} autoFocus className="btn-primary" onClick={onClose}>CONTINUE</Button>
          </Stack>
        </ModalFooter>
      </ModalContent>
    </Modal>
  )
}