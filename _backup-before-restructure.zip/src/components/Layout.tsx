'use client'

import { Box } from '@chakra-ui/react'
import type { ReactNode } from 'react'
import { Footer } from './Footer'
import { JoinFlowModal } from './JoinFlowModal'
import { Navbar } from './Navbar'

interface LayoutProps {
  children: ReactNode
}

export function Layout({ children }: LayoutProps) {
  return (
    <Box minH="100dvh" display="flex" flexDirection="column" bg="var(--bg)" width="100%">
      <Navbar />
      <Box as="main" flex="1" width="100%" minH={0}>
        {children}
      </Box>
      <Footer />
      <JoinFlowModal />
    </Box>
  )
}
