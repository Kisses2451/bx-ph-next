import { Text } from '@chakra-ui/react'
import type { SupabaseGame } from '../types/player'

export const STRIP_MODE: 'static' | 'off' = 'static'
const FALLBACK_ITEMS = ['CODM', 'HONOR OF KINGS', 'RECRUITMENT OPEN']

interface HomeMarqueeProps {
  games: SupabaseGame[]
  gamesLoading: boolean
  gamesError: boolean
}

export function HomeMarquee({ games, gamesLoading, gamesError }: HomeMarqueeProps) {
  if (STRIP_MODE === 'off') return null
  const items = gamesLoading || gamesError || games.length === 0
    ? FALLBACK_ITEMS
    : [...games.map((game) => game.title), 'RECRUITMENT OPEN']

  return (
    <div className="home-marquee">
      <ul className={`home-marquee__list${items.length > 3 ? ' home-marquee__list--columns' : ''}`} aria-label="Featured games and recruitment status" role="list">
        {items.map((item, index) => <li className={item === 'RECRUITMENT OPEN' ? 'home-marquee__item home-marquee__item--accent' : 'home-marquee__item'} key={`${item}-${index}`}><Text as="span">{item}</Text></li>)}
      </ul>
    </div>
  )
}