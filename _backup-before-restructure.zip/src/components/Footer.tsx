import { Box, Container, Flex, Text } from '@chakra-ui/react'
import { siteName } from '../config/site'

export function Footer() {
  return (
    <Box as="footer" className="site-footer" borderColor="var(--border)" width="100%">
      <Container className="shared-container" maxW="none" px={0} py={{ base: 8, md: 12 }}>
      <Text className="site-footer__watermark" aria-hidden="true">BX</Text>
        <Flex mt={8} pt={4} borderTop="1px solid" borderColor="var(--border)" justify="space-between" gap={3} direction={{ base: 'column', md: 'row' }}>
          <Text fontSize="sm" color="var(--text-muted)">© 2026 {siteName} Corporation</Text>
          <Text fontSize="sm" color="var(--text-muted)">Fuel the fight, Respect the grind</Text>
        </Flex>
      </Container>
    </Box>
  )
}
