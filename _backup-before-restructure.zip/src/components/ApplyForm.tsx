'use client'

import { ViewIcon } from '@chakra-ui/icons'
import {
  Alert,
  AlertIcon,
  Box,
  Button,
  Checkbox,
  FormControl,
  FormErrorMessage,
  FormLabel,
  Input,
  Select,
  Stack,
  Text,
  useColorModeValue,
  useToast,
} from '@chakra-ui/react'
import { zodResolver } from '@hookform/resolvers/zod'
import { useState } from 'react'
import { useForm } from 'react-hook-form'
import { useRouter } from 'next/navigation'
import { LAST_APPLICANT_KEY } from '../lib/applicant'
import { z } from 'zod'
import { uploadPlayerPhoto } from '../lib/supabase'
import type { ApplicationPayload } from '../types'
import { ConfirmationModal } from './ConfirmationModal'

const imageSchema = z
  .instanceof(File)
  .refine((file) => file.size <= 5 * 1024 * 1024, 'Image must be 5MB or smaller.')
  .refine((file) => ['image/png', 'image/jpeg', 'image/webp'].includes(file.type), 'Only JPG, PNG, and WEBP images are allowed.')

const applicationSchema = z.object({
  name: z.string().min(2, 'Name is required.'),
  department: z.enum(['Clan', 'Community'], { required_error: 'Please select a department.' }),
  email: z.string().email('Enter a valid email address.'),
  photo: z.any().optional(),
})

export type ApplyFormValues = z.infer<typeof applicationSchema>

export function ApplyForm() {
  const router = useRouter()
  const toast = useToast()
  const [isModalOpen, setIsModalOpen] = useState(false)
  const [pendingPayload, setPendingPayload] = useState<ApplicationPayload | null>(null)
  const [captchaChecked, setCaptchaChecked] = useState(false)
  const [rateLimitMessage, setRateLimitMessage] = useState('')
  const formSurface = useColorModeValue('var(--surface)', 'var(--surface)')
  const formBorder = useColorModeValue('var(--border)', 'var(--border)')

  const {
    register,
    handleSubmit,
    reset,
    setError,
    formState: { errors },
  } = useForm<ApplyFormValues>({
    resolver: zodResolver(applicationSchema),
    defaultValues: {
      name: '',
      department: 'Clan',
      email: '',
      photo: undefined,
    },
  })

  const validateRateLimit = () => {
    const lastAttempt = Number(window.localStorage.getItem('voltix-last-application') ?? '0')
    const now = Date.now()

    if (lastAttempt && now - lastAttempt < 30000) {
      setRateLimitMessage('Too many applications submitted in a short period. Please wait a few minutes and try again.')
      return false
    }

    return true
  }

  const openConfirmation = (values: ApplyFormValues) => {
    const photo = values.photo && values.photo[0] ? values.photo[0] : null

    if (photo && !imageSchema.safeParse(photo).success) {
      setError('photo', { message: 'Please upload a valid image under 2MB.' })
      return
    }

    if (!captchaChecked) {
      toast({ title: 'Captcha required', description: 'Please complete the verification before submitting.', status: 'warning', isClosable: true })
      return
    }

    if (!validateRateLimit()) {
      toast({ title: 'Rate limit reached', description: rateLimitMessage, status: 'error', isClosable: true })
      return
    }

    setPendingPayload({
      name: values.name,
          department: values.department,
      email: values.email,
      photo,
    })
    setIsModalOpen(true)
  }

  const onConfirmSubmit = async () => {
    if (!pendingPayload) return

    const photoUpload = pendingPayload.photo
      ? await uploadPlayerPhoto(pendingPayload.photo)
      : { success: true, publicUrl: '', message: 'No photo uploaded.' }

    if (!photoUpload.success) {
      toast({ title: 'Upload failed', description: photoUpload.message, status: 'error', isClosable: true })
      return
    }

    window.localStorage.setItem('voltix-last-application', String(Date.now()))
    reset()
    setIsModalOpen(false)
    setCaptchaChecked(false)
    setPendingPayload(null)

    try {
      window.sessionStorage.setItem(LAST_APPLICANT_KEY, JSON.stringify({
        ...pendingPayload,
        photoUrl: photoUpload.publicUrl || '',
      }))
    } catch {
      // Storage unavailable: the success page falls back to a generic message.
    }

    router.push('/apply/success')
  }

  return (
    <>
      <Box as="form" onSubmit={handleSubmit(openConfirmation)} noValidate bg={formSurface} border="1px solid" borderColor={formBorder} borderRadius="0" w="100%" maxW="760px" mx="auto" p={{ base: 5, md: 8 }}>
        <Stack spacing={5}>
          <Text fontSize="3xl" fontWeight="bold">Apply as a player</Text>

          {rateLimitMessage ? (
            <Alert status="warning" borderRadius="md">
              <AlertIcon />
              {rateLimitMessage}
            </Alert>
          ) : null}

          <FormControl isInvalid={Boolean(errors.name)}>
            <FormLabel htmlFor="name">Name</FormLabel>
            <Input id="name" aria-label="Player name" placeholder="Full name" {...register('name')} />
            <FormErrorMessage>{errors.name?.message}</FormErrorMessage>
          </FormControl>

          <FormControl isInvalid={Boolean(errors.department)}>
            <FormLabel htmlFor="department">Department</FormLabel>
            <Select id="department" aria-label="Player department" {...register('department')}>
              <option value="Clan">Clan</option>
              <option value="Community">Community</option>
            </Select>
            <FormErrorMessage>{errors.department?.message}</FormErrorMessage>
          </FormControl>

          <FormControl isInvalid={Boolean(errors.email)}>
            <FormLabel htmlFor="email">Email</FormLabel>
            <Input id="email" aria-label="Player email" type="email" placeholder="name@example.com" {...register('email')} />
            <FormErrorMessage>{errors.email?.message}</FormErrorMessage>
          </FormControl>

          <FormControl isInvalid={Boolean(errors.photo)}>
            <FormLabel htmlFor="photo">Upload photo</FormLabel>
            <Input id="photo" aria-label="Upload player photo" type="file" accept="image/png,image/jpeg,image/webp" {...register('photo')} />
            <Text fontSize="sm" color="gray.500" mt={2}>Accepted: JPG, PNG, or WEBP. Max size: 5MB.</Text>
            <FormErrorMessage>{String(errors.photo?.message ?? '')}</FormErrorMessage>
          </FormControl>

          <Box border="1px dashed" borderColor="gray.300" borderRadius="lg" p={4}>
            <Checkbox isChecked={captchaChecked} onChange={(event) => setCaptchaChecked(event.target.checked)} aria-label="Verify captcha">
              I am not a robot
            </Checkbox>
            <Text fontSize="sm" color="gray.500" mt={2}>Captcha placeholder for spam protection.</Text>
          </Box>

          <Stack direction={{ base: 'column', md: 'row' }} spacing={4}>
            <Button type="button" variant="outline" onClick={() => reset()}>
              Reset form
            </Button>
            <Button type="submit" className="btn-primary" leftIcon={<ViewIcon />} colorScheme="brand">
              Review application
            </Button>
          </Stack>
        </Stack>
      </Box>

      <ConfirmationModal
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        onConfirm={onConfirmSubmit}
        payload={pendingPayload}
      />
    </>
  )
}
