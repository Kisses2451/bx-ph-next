'use client'

import { CheckIcon, CloseIcon } from '@chakra-ui/icons'
import { Alert, AlertIcon, Badge, Box, Button, Checkbox, FormControl, FormErrorMessage, FormLabel, Heading, IconButton, Image, Input, Modal, ModalBody, ModalContent, ModalFooter, ModalHeader, ModalOverlay, Radio, RadioGroup, SimpleGrid, Stack, Text, useColorModeValue } from '@chakra-ui/react'
import { useEffect, useRef, useState } from 'react'
import { usePathname } from 'next/navigation'
import { supabase, uploadPlayerPhoto, validateUploadedImage } from '../lib/supabase'
import { DEPARTMENTS_BY_GAME } from '../types/player'
import { useConfirm } from './ConfirmDialog'

export type JoinFlowStep = 'notice' | 'form' | 'review' | 'success'
type MainGame = 'CODM' | 'HOK' | ''
type RegistrationSource = 'Online Recruitment' | 'LAN Event' | ''
type JoinForm = {
  mainGame: MainGame; privacyAccepted: boolean; eligibilityConfirmed: boolean
  firstName: string; lastName: string; contactNumber: string; email: string; dateOfBirth: string; contactLink: string
  registrationSource: RegistrationSource; department: 'Clan' | 'Community' | ''; inGameName: string; uid: string; playerId: string
  photo: File | null; honeypot: string
}

const initialForm: JoinForm = { mainGame: '', privacyAccepted: false, eligibilityConfirmed: false, firstName: '', lastName: '', contactNumber: '', email: '', dateOfBirth: '', contactLink: '', registrationSource: '', department: '', inGameName: '', uid: '', playerId: '', photo: null, honeypot: '' }
const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/
const phonePattern = /^(09\d{9}|\+639\d{9})$/
const socialPattern = /^https?:\/\/(www\.)?(facebook\.com|fb\.com|instagram\.com)\/.+/i

function validate(form: JoinForm) {
  const errors: Record<string, string> = {}
  if (!form.firstName.trim()) errors.firstName = 'First name is required.'
  if (!form.lastName.trim()) errors.lastName = 'Last name is required.'
  if (!phonePattern.test(form.contactNumber.trim())) errors.contactNumber = 'Use 09XXXXXXXXX or +639XXXXXXXXX.'
  if (!emailPattern.test(form.email.trim())) errors.email = 'Enter a valid email address.'
  if (!form.dateOfBirth || Number.isNaN(new Date(form.dateOfBirth).getTime()) || new Date(form.dateOfBirth) >= new Date()) errors.dateOfBirth = 'Enter a valid past date.'
  if (!socialPattern.test(form.contactLink.trim())) errors.contactLink = 'Use a Facebook, fb.com, or Instagram URL.'
  if (!form.registrationSource) errors.registrationSource = 'Choose a registration source.'
  if (!form.inGameName.trim()) errors.inGameName = 'In Game Name is required.'
  if (!form.uid.trim()) errors.uid = 'Unique ID is required.'
  const allowedDepartments = form.mainGame ? DEPARTMENTS_BY_GAME[form.mainGame] : []
  if (!form.department || !allowedDepartments.includes(form.department as never)) errors.department = 'Choose a department.'
  if (form.mainGame === 'CODM' && !form.playerId.trim()) errors.playerId = 'Player ID is required.'
  if (!form.photo) errors.photo = 'Upload a profile picture.'
  if (form.photo && !validateUploadedImage(form.photo).valid) errors.photo = validateUploadedImage(form.photo).message
  return errors
}

export function JoinFlowModal() {
  const pathname = usePathname()
  const [step, setStep] = useState<JoinFlowStep>('notice')
  const [isOpen, setIsOpen] = useState(pathname === '/join' || pathname === '/apply')
  const [form, setForm] = useState<JoinForm>(initialForm)
  const [errors, setErrors] = useState<Record<string, string>>({})
  const [submitError, setSubmitError] = useState('')
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [photoPreview, setPhotoPreview] = useState('')
  const confirm = useConfirm()
  const lastTrigger = useRef<HTMLElement | null>(null)
  const fileInputRef = useRef<HTMLInputElement | null>(null)
  const panelBorder = useColorModeValue('var(--border)', 'var(--border)')
  const tileBg = useColorModeValue('var(--surface-2)', 'var(--surface-2)')

  useEffect(() => {
    const open = (event: Event) => {
      lastTrigger.current = (event as CustomEvent<HTMLElement>).detail ?? null
      setStep('notice'); setIsOpen(true)
    }
    window.addEventListener('open-join-flow', open)
    return () => window.removeEventListener('open-join-flow', open)
  }, [])

  useEffect(() => {
    if (!isOpen) return
    const previousOverflow = document.body.style.overflow
    document.body.style.overflow = 'hidden'
    return () => { document.body.style.overflow = previousOverflow }
  }, [isOpen])

  useEffect(() => {
    if (!form.photo) { setPhotoPreview(''); return }
    const url = URL.createObjectURL(form.photo)
    setPhotoPreview(url)
    return () => URL.revokeObjectURL(url)
  }, [form.photo])

  const resetAndClose = () => {
    setIsOpen(false); setStep('notice'); setForm(initialForm); setErrors({}); setSubmitError(''); setIsSubmitting(false)
    window.setTimeout(() => lastTrigger.current?.focus(), 0)
  }

  const close = async () => {
    const hasData = Object.entries(form).some(([key, value]) => key !== 'privacyAccepted' && key !== 'eligibilityConfirmed' && Boolean(value))
    if (hasData && step !== 'success') {
      const shouldDiscard = await confirm({
        title: 'Discard this application?',
        message: "Your answers and selected photo will be lost. This can't be undone.",
        confirmLabel: 'Discard application',
        cancelLabel: 'Keep editing',
        tone: 'danger',
      })
      if (!shouldDiscard) return
    }
    resetAndClose()
  }

  const update = (key: keyof JoinForm, value: string | boolean | File | null) => {
    const nextForm = { ...form, [key]: value } as JoinForm
    setForm(nextForm)
    setErrors(current => ({ ...current, [key]: validate(nextForm)[key as string] ?? '' }))
  }

  const selectGame = (game: MainGame) => {
    setForm(current => ({ ...current, mainGame: game, department: game === 'HOK' ? DEPARTMENTS_BY_GAME.HOK[0] : '', playerId: '' }))
    setErrors({})
  }

  const review = () => {
    const nextErrors = validate(form)
    setErrors(nextErrors)
    const firstError = Object.keys(nextErrors)[0]
    if (firstError) { document.getElementById(firstError)?.focus(); return }
    setStep('review')
  }

  const submit = async () => {
    if (form.honeypot) return
    setIsSubmitting(true); setSubmitError('')
    let photoPath: string | undefined
    try {
      const upload = form.photo ? await uploadPlayerPhoto(form.photo) : { success: true, publicUrl: '', message: '' }
      if (!upload.success) throw new Error(upload.message)
      photoPath = upload.path
      if (supabase) {
        const { error } = await supabase.from('applications').insert({
          main_game: form.mainGame, first_name: form.firstName.trim(), last_name: form.lastName.trim(), contact_number: form.contactNumber.trim(), email: form.email.trim(), date_of_birth: form.dateOfBirth, contact_link: form.contactLink.trim(), registration_source: form.registrationSource, department: form.department || 'Clan', in_game_name: form.inGameName.trim(), uid: form.uid.trim(), player_id: form.mainGame === 'CODM' ? form.playerId.trim() : null, photo_path: photoPath ?? null, status: 'pending',
        })
        if (error) {
          if (photoPath) await supabase.storage.from(process.env.NEXT_PUBLIC_SUPABASE_STORAGE_BUCKET ?? 'player-photos').remove([photoPath])
          throw new Error(error.message)
        }
      }
      setStep('success')
    } catch (error) {
      console.error('Application submission failed:', error instanceof Error ? error.message : 'Unknown submission error')
      setSubmitError(error instanceof Error ? error.message : 'Unable to submit your application. Please try again.')
    } finally { setIsSubmitting(false) }
  }

  const formField = (key: keyof JoinForm, label: string, type = 'text', placeholder = '') => (
    <FormControl isInvalid={Boolean(errors[key])} isRequired>
      <FormLabel htmlFor={key}>{label}</FormLabel>
      <Input id={key} type={type} value={String(form[key] ?? '')} placeholder={placeholder} onChange={event => update(key, event.target.value)} onBlur={() => setErrors(current => ({ ...current, [key]: validate(form)[key as string] ?? '' }))} />
      <FormErrorMessage>{errors[key]}</FormErrorMessage>
    </FormControl>
  )

  return <Modal isOpen={isOpen} onClose={close} size={step === 'form' ? '6xl' : 'xl'} isCentered closeOnOverlayClick={false} scrollBehavior="inside" motionPreset="slideInBottom">
    <ModalOverlay />
    <ModalContent className={`join-flow-modal join-flow-modal--${step}`} bg="var(--surface)" border="1px solid" borderColor={panelBorder} borderRadius="0" role="dialog" aria-modal="true" aria-labelledby="join-flow-title">
      <ModalHeader borderBottom="1px solid" borderColor={panelBorder} pr={12}>
        <Text className="editorial-eyebrow">BLOODLUST PHILIPPINES MEMBERSHIP</Text>
        <Heading id="join-flow-title" as="h2" mt={2} fontSize={{ base: '2xl', md: '4xl' }}>{step === 'notice' ? <>Before you <Box as="span" color="accent.500">apply.</Box></> : step === 'form' ? 'Application form' : step === 'review' ? 'Review your application' : 'Application received'}</Heading>
      </ModalHeader>
      <IconButton icon={<CloseIcon />} aria-label="Close application flow" onClick={close} position="absolute" right={4} top={4} variant="ghost" />

      {step === 'notice' && <><ModalBody><Stack spacing={5}>
        <Box border="1px solid" borderColor={panelBorder} p={5}><Text className="editorial-eyebrow">DATA PRIVACY NOTICE</Text><Text mt={3}>By checking the box, I consent to the collection and processing of my personal information for membership registration, identification, and internal records, in compliance with the Data Privacy Act of 2012 (RA 10173). My data will not be shared without consent unless required by law.</Text></Box>
        <Box border="1px solid" borderColor="brand.500" bg="rgba(122,20,32,0.12)" p={5}><Text className="editorial-eyebrow">ELIGIBILITY DECLARATION  </Text><Text mt={3}>
        By checking the box, I declare that all information I provide will be true and accurate. I understand that any false or misleading details will result in the denial, suspension, or termination of my membership.
I declare that all information I have provided in this form is true, accurate, and complete to the best of my knowledge. I understand that providing false or misleading information may result in the denial, suspension, or termination of my membership in the organization.  </Text></Box>
        <FormControl as="fieldset" isRequired><FormLabel>Main game</FormLabel><RadioGroup value={form.mainGame} onChange={value => selectGame(value as MainGame)}><SimpleGrid columns={{ base: 1, sm: 2 }} gap={3}>{(['CODM', 'HOK'] as const).map(game => <Box key={game} as="label" border="1px solid" borderColor={form.mainGame === game ? 'brand.500' : panelBorder} bg={form.mainGame === game ? 'brand.900' : tileBg} p={4} cursor="pointer" tabIndex={0} onKeyDown={(event: React.KeyboardEvent<HTMLLabelElement>) => { if (event.key === 'Enter' || event.key === ' ') { event.preventDefault(); selectGame(game) } }}><Radio value={game}>{game === 'CODM' ? 'Call of Duty Mobile (CODM)' : 'Honor of Kings (HOK)'}</Radio>{form.mainGame === game && <CheckIcon color="accent.500" float="right" />}</Box>)}</SimpleGrid></RadioGroup></FormControl>
        <Checkbox isChecked={form.privacyAccepted} onChange={event => update('privacyAccepted', event.target.checked)}>I have read and agree to the Data Privacy Notice.</Checkbox>
        <Checkbox isChecked={form.eligibilityConfirmed} onChange={event => update('eligibilityConfirmed', event.target.checked)}>I confirm that I meet all eligibility requirements.</Checkbox>
      </Stack></ModalBody><ModalFooter display="block"><Button className="btn-primary" width="full" colorScheme="brand" isDisabled={!form.mainGame || !form.privacyAccepted || !form.eligibilityConfirmed} onClick={() => setStep('form')}>CONTINUE TO APPLICATION</Button>{(!form.mainGame || !form.privacyAccepted || !form.eligibilityConfirmed) && <Text mt={2} fontSize="sm" color="var(--text-muted)">Select a main game and complete both confirmations to continue.</Text>}</ModalFooter></>}

      {step === 'form' && <><ModalBody className="join-flow-form-body"><SimpleGrid columns={{ base: 1, lg: 2 }} gap={8}>
        <Stack spacing={4}><Heading as="h3" size="md">Basic information</Heading><SimpleGrid columns={{ base: 1, sm: 2 }} gap={4}>{formField('firstName', 'First name')}{formField('lastName', 'Last name')}</SimpleGrid>{formField('contactNumber', 'Contact number', 'tel', '09XXXXXXXXX')}{formField('email', 'Email address', 'email')}{formField('dateOfBirth', 'Date of birth', 'date')}{formField('contactLink', 'Contact link', 'url', 'https://facebook.com/...')}<FormControl isInvalid={Boolean(errors.registrationSource)} isRequired><FormLabel>From where did you register?</FormLabel><RadioGroup value={form.registrationSource} onChange={value => update('registrationSource', value)}><Stack direction={{ base: 'column', sm: 'row' }}><Radio value="Online Recruitment">Online Recruitment</Radio><Radio value="LAN Event">LAN Event</Radio></Stack></RadioGroup><FormErrorMessage>{errors.registrationSource}</FormErrorMessage></FormControl></Stack>
        <Stack spacing={4}><Heading as="h3" size="md">Gaming information - {form.mainGame}</Heading>{form.mainGame && <FormControl isInvalid={Boolean(errors.department)} isRequired><FormLabel>Which department are you applying for?</FormLabel><RadioGroup value={form.department} onChange={value => update('department', value)}><Stack direction={{ base: 'column', sm: 'row' }}>{DEPARTMENTS_BY_GAME[form.mainGame].map((department) => <Box key={department} as="label" border="1px solid" borderColor={form.department === department ? 'brand.500' : panelBorder} bg={form.department === department ? 'brand.900' : tileBg} p={3} cursor="pointer" tabIndex={0}><Radio value={department}>{department}</Radio></Box>)}</Stack></RadioGroup>{form.mainGame === 'HOK' ? <Text fontSize="sm" color="var(--text-muted)">Only Clan is open for Honor of Kings right now.</Text> : null}<FormErrorMessage>{errors.department}</FormErrorMessage></FormControl>}{formField('inGameName', 'In Game Name (IGN)')}{formField('uid', 'Unique ID')}{form.mainGame === 'CODM' && <>{formField('playerId', 'Player ID')}<Text fontSize="sm" color="var(--text-muted)">CODM &gt; Settings &gt; User Settings</Text></>}<FormControl isInvalid={Boolean(errors.photo)} isRequired={form.mainGame === 'CODM'}><FormLabel htmlFor="photo">Upload picture{form.mainGame === 'HOK' ? ' (optional)' : ''}</FormLabel><Input ref={fileInputRef} id="photo" type="file" accept="image/jpeg,image/png,image/webp" onChange={event => update('photo', event.target.files?.[0] ?? null)} />{form.mainGame === 'CODM' && <Box border="1px solid" borderColor="brand.500" bg="rgba(122,20,32,0.12)" p={3} mt={2}><Text fontSize="sm" fontWeight="bold">MUST READ</Text><Text fontSize="sm">White background, half-body photo, no selfies.</Text></Box>}{photoPreview && <Stack direction="row" align="center" mt={3}><Image src={photoPreview} alt="Selected application photo preview" boxSize="88px" objectFit="cover" /><Button size="sm" variant="outline" onClick={() => { update('photo', null); if (fileInputRef.current) fileInputRef.current.value = '' }}>Remove</Button></Stack>}<Text fontSize="sm" color="var(--text-muted)" mt={2}>Accepted: JPG, PNG, or WEBP. Max size: 5MB.</Text><FormErrorMessage>{errors.photo}</FormErrorMessage></FormControl><Input aria-hidden="true" tabIndex={-1} position="absolute" left="-10000px" name="website" value={form.honeypot} onChange={event => update('honeypot', event.target.value)} /></Stack>
      </SimpleGrid></ModalBody><ModalFooter justifyContent="space-between" position="sticky" bottom={0} bg="var(--surface)" borderTop="1px solid" borderColor={panelBorder}><Button variant="outline" onClick={() => setStep('notice')}>Back</Button><Button className="btn-primary" colorScheme="brand" onClick={review}>Review application</Button></ModalFooter></>}

      {step === 'review' && <><ModalBody><Stack spacing={5}><Badge alignSelf="flex-start" colorScheme="brand">{form.mainGame}</Badge><Text>Please check that all information is accurate before submitting.</Text>{submitError && <Alert status="error"><AlertIcon />{submitError}</Alert>}<SimpleGrid columns={{ base: 1, md: 2 }} gap={4}><Box bg={tileBg} p={5}><Heading as="h3" size="sm">Basic information</Heading><Text mt={3}>Name: {form.firstName} {form.lastName}</Text><Text>Email: {form.email}</Text><Text>Contact: {form.contactNumber}</Text><Text>Date of birth: {form.dateOfBirth}</Text><Text>Contact link: {form.contactLink}</Text><Text>Registration: {form.registrationSource}</Text></Box><Box bg={tileBg} p={5}><Heading as="h3" size="sm">Gaming information</Heading><Text mt={3}>Main game: {form.mainGame}</Text><Text>Department: {form.department}</Text><Text>IGN: {form.inGameName}</Text><Text>UID: {form.uid}</Text>{form.mainGame === 'CODM' && <><Text>Player ID: {form.playerId}</Text></>}{photoPreview && <Image src={photoPreview} alt="Application photo preview" maxH="140px" objectFit="contain" mt={3} />}</Box></SimpleGrid></Stack></ModalBody><ModalFooter justifyContent="space-between"><Button variant="outline" onClick={() => setStep('form')}>Edit information</Button><Button className="btn-primary" colorScheme="brand" isLoading={isSubmitting} isDisabled={isSubmitting} onClick={submit}>Confirm &amp; submit</Button></ModalFooter></>}

      {step === 'success' && <ModalBody><Stack align="center" spacing={5} py={8}><Heading as="h3" size="md">Thank you for applying.</Heading><Text>Your application has been received for review.</Text><Button className="btn-primary" colorScheme="brand" onClick={resetAndClose}>Close</Button></Stack></ModalBody>}
    </ModalContent>
  </Modal>
}