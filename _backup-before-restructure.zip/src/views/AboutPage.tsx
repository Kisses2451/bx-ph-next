'use client'

import { Box, Container, Heading, Image, SimpleGrid, Stack, Text, useColorModeValue } from '@chakra-ui/react'
import { useEffect, useRef, useState, type CSSProperties } from 'react'
import { NumberedCard } from '../components/about/NumberedCard'
import { SectionHeader } from '../components/about/SectionHeader'
import { Reveal } from '../components/Reveal'
import { aboutPageContent } from '../data/siteContent'
import { supabase } from '../lib/supabase'
import { usePublicStats } from '../hooks/usePublicStats'

const bxLogo = '/bx-logo.png'

type TimelineEvent = { id: string; year: number; month: number | null; title: string; description: string | null; is_visible: boolean; created_at: string }

function sortTimelineEvents(a: TimelineEvent, b: TimelineEvent) {
  return a.year - b.year || (a.month ?? 0) - (b.month ?? 0) || a.created_at.localeCompare(b.created_at)
}

const aboutPillars = [
  { number: '01', title: 'Recruit', description: 'We identify and develop talent through focused scouting, evaluation, and a structured player pathway.' },
  { number: '02', title: 'Develop', description: 'We build a performance culture where training, feedback, and growth habits support long-term opportunity.' },
  { number: '03', title: 'Compete', description: 'We create competitive environments that turn readiness into results for players, staff, and partners.' },
]

const missionVisionCards = [
  { number: '01', label: 'MISSION', title: 'Empowering Players', description: 'To build a strong, supportive esports community that empowers players, members and creators through growth, exposure, and partnerships. Bloodlust Philippines nurtures competitive and creative talents in a positive and inclusive environment.' },
  { number: '02', label: 'VISION', title: 'Forging Legacy', description: 'To make Bloodlust Philippines a respected name in global esports — promoting excellence, unity, and sportsmanship across multiple game titles and creating a thriving ecosystem for all gamers.' },
]

function PhilippineFlag() {
  return <svg aria-hidden="true" viewBox="0 0 28 18" width="28" height="18"><path fill="#0b4ea2" d="M0 0h28v9H0z" /><path fill="#c8102e" d="M0 9h28v9H0z" /><path fill="#fff" d="m0 0 15 9L0 18z" /><circle cx="4.2" cy="9" r="1.5" fill="#f7c843" /><path fill="#f7c843" d="m3.9 3 .4 1.2h1.3l-1 .8.4 1.2-1.1-.7-1.1.7.4-1.2-1-.8h1.3z" /><path fill="#f7c843" d="m3.9 12 .4 1.2h1.3l-1 .8.4 1.2-1.1-.7-1.1.7.4-1.2-1-.8h1.3z" /></svg>
}

function AnimatedStat({ value, staticValue }: { value: string; staticValue: boolean }) {
  const [display, setDisplay] = useState(value)
  const ref = useRef<HTMLDivElement>(null)

  useEffect(() => {
    setDisplay(value)
    if (staticValue || !ref.current || value === '—' || value === 'PH') return
    const reduceMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches
    let started = false
    const startAnimation = () => {
      if (started) return
      started = true
      if (reduceMotion) { setDisplay(value); return }
      const target = Number.parseInt(value, 10)
      const suffix = value.replace(String(target), '')
      const start = performance.now()
      const animate = (now: number) => {
        const progress = Math.min((now - start) / 700, 1)
        setDisplay(`${Math.round(target * (1 - Math.pow(1 - progress, 3)))}${suffix}`)
        if (progress < 1) requestAnimationFrame(animate)
      }
      requestAnimationFrame(animate)
    }
    let observer: IntersectionObserver | null = null
    try {
      observer = new IntersectionObserver(([entry]) => {
        if (!entry.isIntersecting) return
        observer?.disconnect()
        startAnimation()
      }, { threshold: 0.45 })
      observer.observe(ref.current)
    } catch {
      startAnimation()
    }
    const initialCheck = window.setTimeout(() => {
      const rect = ref.current?.getBoundingClientRect()
      if (rect && rect.top < window.innerHeight * 0.9 && rect.bottom > 0) startAnimation()
    }, 120)
    return () => { observer?.disconnect(); window.clearTimeout(initialCheck); started = true }
  }, [staticValue, value])

  return <Box ref={ref} className="about-stat-value">{value === 'PH' ? <PhilippineFlag /> : display}</Box>
}

export function AboutPage() {
  const surface2 = useColorModeValue('var(--surface-2)', 'var(--surface-2)')
  const muted = useColorModeValue('var(--text-muted)', 'var(--text-muted)')
  const text = useColorModeValue('var(--text)', 'var(--text)')
  const border = useColorModeValue('var(--border)', 'var(--border)')
  const [timelineEvents, setTimelineEvents] = useState<TimelineEvent[]>([])
  const [timelineLoading, setTimelineLoading] = useState(true)
  const [timelineError, setTimelineError] = useState(false)
  const { stats: publicStats, isLoading: statsLoading, error: statsError } = usePublicStats()

  useEffect(() => {
    const sections = document.querySelectorAll<HTMLElement>('.about-reveal')
    const observer = new IntersectionObserver((entries) => entries.forEach((entry) => {
      if (entry.isIntersecting) entry.target.classList.add('is-visible')
    }), { threshold: 0.12 })
    sections.forEach((section) => observer.observe(section))
    return () => observer.disconnect()
  }, [])

  useEffect(() => {
    let ignore = false
    if (!supabase) { setTimelineLoading(false); return }
    supabase.from('timeline_events').select('id,year,month,title,description,is_visible,created_at').eq('is_visible', true).order('year', { ascending: true }).order('month', { ascending: true, nullsFirst: true }).order('created_at', { ascending: true }).then(({ data, error }) => {
      if (ignore) return
      if (error) {
        console.error('Timeline load failed:', error)
        setTimelineError(true)
      } else {
        setTimelineEvents(((data ?? []) as TimelineEvent[]).sort(sortTimelineEvents))
      }
      setTimelineLoading(false)
    })
    return () => { ignore = true }
  }, [])

  const timelineMostRecentId = timelineEvents[timelineEvents.length - 1]?.id

  const stats = aboutPageContent.stats.map((stat) => stat.label === 'ACTIVE GAME TITLES'
    ? { ...stat, value: publicStats.games === null ? '—' : String(publicStats.games), static: false }
    : stat.label === 'MEMBERS'
      ? { ...stat, value: publicStats.members === null ? '—' : String(publicStats.members), static: false }
      : stat)

  return <Container className="shared-container about-page" maxW="none" px={0}>
  <Stack spacing={{ base: 10, md: 14 }} align="stretch">
  <Box className="about-major-section about-intro-section">
  <Reveal variant="mask-line"><Box className="about-header about-reveal"><SectionHeader subLabel={aboutPageContent.header.eyebrow} headingPartOne={aboutPageContent.header.headingPrimary} headingPartTwo={aboutPageContent.header.headingAccent} intro={aboutPageContent.header.intro} centered /></Box></Reveal>
  <Reveal variant="scale-in"><Box className="about-stats about-reveal" bg={surface2} borderTop="1px solid" borderBottom="1px solid" borderColor={border} minH="150px"><SimpleGrid columns={{ base: 2, md: 4 }}>{stats.map((stat, index) => <Box key={stat.label} className="about-stat" borderColor="rgba(122, 20, 32, 0.32)" style={{ '--i': index } as CSSProperties}><AnimatedStat value={statsError && !statsLoading && !stat.static ? '—' : stat.value} staticValue={statsLoading || stat.static} /><Text className="about-stat-label" color={muted}>{stat.label}</Text>{stat.todo ? <Text className="about-todo" srOnly>{stat.todo}</Text> : null}</Box>)}</SimpleGrid>{statsError && !statsLoading ? <Text className="about-stats-error" color={muted}>Live stats unavailable right now.</Text> : null}</Box></Reveal>
  </Box>
  <Reveal variant="slide-right"><Box className="about-major-section about-story about-reveal"><Box className="about-story-grid"><Box className="about-story-copy" borderLeft="1px solid" borderColor="brand.500" pl={{ base: 5, md: 8 }}><Text className="about-story-rail" aria-hidden="true">{aboutPageContent.story.railLabel}</Text><Text className="editorial-eyebrow">{aboutPageContent.story.eyebrow}</Text><Heading as="h2" className="about-story-heading" color={text}><Box as="span" display="block">{aboutPageContent.story.headingPrimary}</Box><Box as="span" display="block" color="brand.400">{aboutPageContent.story.headingSecondary}</Box></Heading><Stack spacing={5} color={muted} maxW="65ch"><Text>{aboutPageContent.story.paragraphs[0]}</Text><Text>{aboutPageContent.story.paragraphs[1]}</Text></Stack><Box className="about-game-chips" aria-label="Active game titles">{aboutPageContent.story.games.map((game) => <Box key={game.label} className="about-game-chip" title={game.todo}><Box className="about-game-mark" aria-hidden="true">{game.label === 'CODM' ? 'C' : game.label === 'POINT BLANK' ? 'P' : 'H'}</Box><Text>{game.label}</Text></Box>)}</Box></Box><Box className="about-logo-frame" border="1px solid" borderColor={border} bg={surface2}><Image src={bxLogo} alt="Bloodlust Philippines logo" objectFit="contain" p={{ base: 6, md: 10 }} w="100%" h="100%" /></Box></Box></Box></Reveal>
  <Reveal variant="slide-left"><Box className="about-major-section about-mission-vision"><SectionHeader subLabel="WHO WE ARE" headingPartOne="MISSION" headingPartTwo="& VISION" intro="" headingLevel="h3" showUnderline /><SimpleGrid mt={{ base: 8, md: 10 }} columns={{ base: 1, md: 2 }} spacing={5} alignItems="stretch">{missionVisionCards.map((card) => <NumberedCard key={card.number} number={card.number} label={card.label} title={card.title} description={card.description} watermark />)}</SimpleGrid></Box></Reveal>
  <Box className="about-major-section about-journey-section">
  {timelineError ? <Text className="about-timeline-error" color={muted}>Timeline unavailable right now</Text> : !timelineLoading && timelineEvents.length > 0 ? <Box className="about-timeline about-reveal"><SectionHeader subLabel="OUR JOURNEY" headingPartOne="KEY" headingPartTwo="MILESTONES" intro="" headingLevel="h3" /><Box className="about-timeline-track"><ol>{timelineEvents.map((item) => <li key={item.id} className={item.id === timelineMostRecentId ? 'about-timeline-item about-timeline-item--latest' : 'about-timeline-item'}><Box className="about-timeline-node" aria-hidden="true" />{item.id === timelineMostRecentId ? <Text className="about-timeline-latest">LATEST</Text> : null}<time dateTime={`${item.year}-${item.month ? String(item.month).padStart(2, '0') : '01'}`}>{item.month ? `${new Date(2000, item.month - 1).toLocaleString('en', { month: 'short' }).toUpperCase()} ` : ''}{item.year}</time><Heading as="h4" size="md">{item.title}</Heading>{item.description ? <Text color={muted}>{item.description}</Text> : null}</li>)}</ol></Box></Box> : timelineLoading ? <Box className="about-timeline about-reveal"><SectionHeader subLabel="OUR JOURNEY" headingPartOne="KEY" headingPartTwo="MILESTONES" intro="" headingLevel="h3" /><Stack mt={6} spacing={4}>{[1, 2, 3].map((item) => <Box key={item} h="88px" borderRadius="md" bg={surface2} aria-hidden="true" />)}</Stack></Box> : null}
  <Box w="100%"><SimpleGrid columns={{ base: 1, md: 3 }} spacing={5} justifyContent="start" alignItems="stretch">{aboutPillars.map((pillar) => <NumberedCard key={pillar.number} number={pillar.number} title={pillar.title} description={pillar.description} />)}</SimpleGrid></Box>
  </Box>
  </Stack>
  </Container>
}
