'use client'

import { AddIcon, ChevronDownIcon, ChevronUpIcon, LockIcon } from '@chakra-ui/icons'
import {
  Badge,
  Box,
  Button,
  Card,
  CardBody,
  Container,
  Divider,
  Flex,
  FormControl,
  FormErrorMessage,
  FormLabel,
  Heading,
  HStack,
  Input,
  Image,
  Link,
  Modal,
  ModalBody,
  ModalCloseButton,
  ModalContent,
  ModalFooter,
  ModalHeader,
  ModalOverlay,
  Select,
  SimpleGrid,
  Stack,
  Switch,
  Tab,
  TabList,
  TabPanel,
  TabPanels,
  Tabs,
  Table,
  TableContainer,
  Tbody,
  Td,
  Text,
  Textarea,
  useColorModeValue,
  Th,
  Thead,
  Tr,
  useToast,
} from '@chakra-ui/react'
import { useEffect, useMemo, useState } from 'react'
import { usePathname, useRouter, useSearchParams } from 'next/navigation'
import { ActionIconButton, ApproveActionIcon, DeleteActionIcon, EditActionIcon, RejectActionIcon } from '../components/ActionIconButton'
import { DashboardControls, type PlayerDatePreset } from '../components/DashboardControls'
import { ImageUrlField } from '../components/ImageUrlField'
import { GameLogoField } from '../components/GameLogoField'
import { ViewToggle } from '../components/ViewToggle'
import { useConfirm } from '../components/ConfirmDialog'
import type { NormalizedLogo } from '../lib/images'
import { normalizeLogoToSquare } from '../lib/images'
import { usePlayers } from '../context/PlayerContext'
import { useAdminPartners, PARTNERS_UPDATED_EVENT } from '../hooks/usePartners'
import { signInWithEmail, supabase, uploadPartnerLogo, uploadPlayerPhoto } from '../lib/supabase'
import { DEPARTMENTS_BY_GAME, type EventItem, type GameItem, type PartnerItem, type StaffMember, type SupabaseEvent, type SupabaseGame, type SupabasePlayer, type SupabaseStaff, type PlayerGame, type PlayerStatusValue, type SupabasePartner } from '../types/player'

const defaultPlayerForm = { id: '', first_name: '', last_name: '', email: '', contact_number: '', date_of_birth: '', contact_link: '', registration_source: 'Online Recruitment', main_game: 'CODM' as PlayerGame, department: 'Clan', in_game_name: '', uid: '', player_id: '', status: 'pending' as PlayerStatusValue, photo_path: '', photo_drive_url: '' }

const defaultGameForm: Omit<GameItem, 'id'> & { id?: string } = {
  id: '',
  title: '',
  genre: '',
  status: 'Active',
  description: '',
  image: '',
  imageUrl: '',
  featured: true,
}

type AdminGame = SupabaseGame & { is_visible: boolean; sort_order: number }
type AdminEvent = SupabaseEvent
type AdminStaff = SupabaseStaff

const defaultEventForm: Omit<EventItem, 'id'> & { id?: string; is_visible: boolean; sort_order: number } = {
  id: '',
  title: '',
  date: new Date().toISOString().slice(0, 10),
  location: '',
  description: '',
  image: '',
  imageUrl: '',
  is_visible: true,
  sort_order: 0,
}

const defaultPartnerForm: Omit<PartnerItem, 'id'> & { id?: string } = {
  id: '',
  name: '',
  category: '',
  website: '',
  description: '',
  logo: '',
  imageUrl: '',
}

const defaultStaffForm: Omit<StaffMember, 'id'> & { id?: string } = {
  id: '',
  name: '',
  role: '',
  bio: '',
  image: '',
  imageUrl: '',
}

const defaultUpdateForm = {
  id: '',
  title: '',
  tag: 'Recruitment',
  detail: '',
  published_at: new Date().toISOString().slice(0, 16),
  is_visible: true,
  sort_order: 0,
}

const defaultTimelineForm = {
  id: '', year: new Date().getFullYear(), month: null as number | null, title: '', description: '', is_visible: true,
}

type TimelineEvent = { id: string; year: number; month: number | null; title: string; description: string | null; is_visible: boolean; created_at?: string; updated_at?: string }
type AdminLatestUpdate = { id: string; tag: string | null; title: string; description: string | null; published_at: string | null; is_visible: boolean; sort_order: number; created_at?: string; updated_at?: string }

function sortTimelineEvents(a: TimelineEvent, b: TimelineEvent) {
  return a.year - b.year || (a.month ?? 0) - (b.month ?? 0) || String(a.created_at ?? '').localeCompare(String(b.created_at ?? ''))
}

type AdminTab = 'players' | 'latest-updates' | 'games' | 'partners' | 'events' | 'timeline' | 'staffs'
type EntryKind = 'player' | 'update' | 'game' | 'partner' | 'event' | 'staff' | 'timeline'
type ViewMode = 'table' | 'card'
type ModalMode = 'view' | 'add' | 'edit'

type ModalState = {
  kind: EntryKind
  mode: ModalMode
  item: Record<string, any>
}

type ConfirmAction = {
  title: string
  description: string
  confirmLabel: string
  onConfirm: () => void
}

type FormErrors = Record<string, string>
type PlayerCounts = { total: number; approved: number; pending: number }

const PLAYER_SELECT = 'id,full_name,first_name,last_name,email,main_game,department,in_game_name,uid,status,photo_path,photo_drive_url,created_at'

function sanitizePlayerSearch(value: string) {
  return value.trim().replace(/[%,()\\]/g, '')
}

function manilaDate(value: Date) {
  return new Intl.DateTimeFormat('en-CA', { timeZone: 'Asia/Manila', year: 'numeric', month: '2-digit', day: '2-digit' }).format(value)
}

function playerInitials(player: SupabasePlayer) {
  return `${player.first_name?.[0] ?? ''}${player.last_name?.[0] ?? ''}`.toUpperCase() || '?'
}

function mapSupabaseError(error: { code?: string; message?: string }) {
  if (error.code === '23505') return 'This UID is already registered for that game.'
  if (error.code === '42501') return 'Admin permission required.'
  if (error.code === '23514') return error.message?.match(/\(([^)]+)\)/)?.[1] ? `Invalid value for ${error.message.match(/\(([^)]+)\)/)?.[1]}.` : 'A field value is outside the allowed limits.'
  return error.message || 'Something went wrong. Please try again.'
}

function mapLatestUpdateError(error: { code?: string; message?: string }) {
  if (error.code === '23505') return 'This update conflicts with an existing record.'
  if (error.code === '42501') return 'Admin permission required.'
  if (error.code === '23514') return 'A field value is outside the allowed limits.'
  return error.message || 'Something went wrong. Please try again.'
}

const tabOrder: AdminTab[] = ['players', 'latest-updates', 'games', 'partners', 'events', 'timeline', 'staffs']
const routeMap: Record<AdminTab, string> = {
  players: '/admin/players',
  'latest-updates': '/admin/latest-updates',
  games: '/admin/games',
  partners: '/admin/partners',
  events: '/admin/events',
  timeline: '/admin?tab=timeline',
  staffs: '/admin/staffs',
}

function createEmptyItem(kind: EntryKind): Record<string, any> {
  switch (kind) {
    case 'player':
      return { ...defaultPlayerForm, id: '' }
    case 'update':
      return { ...defaultUpdateForm, id: '' }
    case 'game':
      return { ...defaultGameForm, id: '' }
    case 'partner':
      return { ...defaultPartnerForm, id: '' }
    case 'event':
      return { ...defaultEventForm, id: '' }
    case 'staff':
      return { ...defaultStaffForm, id: '' }
    case 'timeline':
      return { ...defaultTimelineForm }
    default:
      return {}
  }
}

function itemIsDirty(current: Record<string, any>, original: Record<string, any>) {
  return JSON.stringify(current) !== JSON.stringify(original)
}

function readValue(source: Record<string, any>, key: string) {
  return source[key] ?? ''
}

function gameStoragePath(url: string | null | undefined) {
  if (!url) return null
  try {
    const path = new URL(url).pathname.split('/site-media/')[1]
    return path?.startsWith('games/') ? path : null
  } catch {
    return null
  }
}

function partnerStoragePath(url: string | null | undefined) {
  if (!url) return null
  try {
    const path = new URL(url).pathname.split('/site-media/')[1]
    return path?.startsWith('partners/') ? path : null
  } catch {
    return null
  }
}

function eventStoragePath(url: string | null | undefined) {
  if (!url) return null
  try {
    const path = new URL(url).pathname.split('/site-media/')[1]
    return path?.startsWith('events/') ? path : null
  } catch {
    return null
  }
}

function staffStoragePath(url: string | null | undefined) {
  if (!url) return null
  try {
    const path = new URL(url).pathname.split('/site-media/')[1]
    return path?.startsWith('staff/') ? path : null
  } catch {
    return null
  }
}

export function AdminPage() {
  const {
    role,
    isAuthenticated,
    login,
    logout,
  } = usePlayers()
  const { partners, isLoading: partnersLoading, error: partnersError, retry: retryPartners, refresh: refreshPartners } = useAdminPartners()

  const pathname = usePathname() ?? '/admin'
  const searchParams = useSearchParams()
  const router = useRouter()
  const toast = useToast()
  const modalSurface = useColorModeValue('white', 'gray.900')
  const modalBorder = useColorModeValue('gray.200', 'whiteAlpha.200')
  const modalSoftBg = useColorModeValue('gray.50', 'gray.800')
  const modalMuted = useColorModeValue('gray.600', 'gray.300')
  const summarySurface = useColorModeValue('white', 'gray.900')
  const summaryTile = useColorModeValue('gray.50', 'gray.800')
  const summaryText = useColorModeValue('gray.900', 'gray.100')
  const summaryMuted = useColorModeValue('gray.600', 'gray.300')
  const summaryBorder = useColorModeValue('gray.200', 'whiteAlpha.200')

  const currentTab = useMemo<AdminTab>(() => {
    const queryTab = searchParams?.get('tab')
    if (queryTab === 'timeline') return 'timeline'
    const segment = pathname.split('/').filter(Boolean).pop() ?? 'players'
    if (segment === 'games') return 'games'
    if (segment === 'latest-updates') return 'latest-updates'
    if (segment === 'partners') return 'partners'
    if (segment === 'events') return 'events'
    if (segment === 'staffs') return 'staffs'
    return 'players'
  }, [pathname, searchParams])

  const [viewMode, setViewMode] = useState<Record<AdminTab, ViewMode>>({
    players: 'table',
    'latest-updates': 'table',
    games: 'table',
    partners: 'table',
    events: 'table',
    timeline: 'table',
    staffs: 'table',
  })
  const [timelineEvents, setTimelineEvents] = useState<TimelineEvent[]>([])
  const [timelineLoading, setTimelineLoading] = useState(false)
  const [timelineError, setTimelineError] = useState('')
  const [timelineSaving, setTimelineSaving] = useState(false)
  const [adminEvents, setAdminEvents] = useState<AdminEvent[]>([])
  const [eventsLoading, setEventsLoading] = useState(false)
  const [adminLatestUpdates, setAdminLatestUpdates] = useState<AdminLatestUpdate[]>([])
  const [latestUpdatesLoading, setLatestUpdatesLoading] = useState(false)
  const [adminStaff, setAdminStaff] = useState<AdminStaff[]>([])
  const [staffLoading, setStaffLoading] = useState(false)
  const [staffImageFile, setStaffImageFile] = useState<File | null>(null)
  const [adminGames, setAdminGames] = useState<AdminGame[]>([])
  const [gamesLoading, setGamesLoading] = useState(false)
  const [gameSaving, setGameSaving] = useState(false)
  const [gameLogoProcessing, setGameLogoProcessing] = useState(false)
  const [gameLogoInfo, setGameLogoInfo] = useState<{ size: number; warning?: string } | null>(null)
  const [gameLogoFile, setGameLogoFile] = useState<File | null>(null)
  const [searchTerm, setSearchTerm] = useState('')
  const [departmentFilter, setDepartmentFilter] = useState('all')
  const [statusFilter, setStatusFilter] = useState('all')
  const [datePreset, setDatePreset] = useState<PlayerDatePreset>('all')
  const [fromDate, setFromDate] = useState('')
  const [toDate, setToDate] = useState('')
  const [playerRows, setPlayerRows] = useState<SupabasePlayer[]>([])
  const [playerLoading, setPlayerLoading] = useState(false)
  const [playerError, setPlayerError] = useState('')
  const [playerCounts, setPlayerCounts] = useState<PlayerCounts>({ total: 0, approved: 0, pending: 0 })
  const [playerPage, setPlayerPage] = useState(1)
  const [playerTotal, setPlayerTotal] = useState(0)
  const [playerPhotoUrls, setPlayerPhotoUrls] = useState<Record<string, string>>({})
  const [playerGameFilter, setPlayerGameFilter] = useState('all')
  const [playerSearchDebounced, setPlayerSearchDebounced] = useState('')
  const playerPageSize = 25

  useEffect(() => {
    const timer = window.setTimeout(() => setPlayerSearchDebounced(sanitizePlayerSearch(searchTerm)), 300)
    return () => window.clearTimeout(timer)
  }, [searchTerm])

  useEffect(() => {
    setPlayerPage(1)
  }, [playerSearchDebounced, departmentFilter, statusFilter, playerGameFilter, datePreset, fromDate, toDate])

  const playerDateRange = useMemo(() => {
    const today = manilaDate(new Date())
    const shift = (date: string, days: number) => {
      const next = new Date(`${date}T00:00:00Z`)
      next.setUTCDate(next.getUTCDate() + days)
      return next.toISOString().slice(0, 10)
    }
    if (datePreset === '7') return { from: shift(today, -6), to: today }
    if (datePreset === '30') return { from: shift(today, -29), to: today }
    if (datePreset === 'custom') return { from: fromDate, to: toDate }
    return { from: '', to: '' }
  }, [datePreset, fromDate, toDate])

  const loadPlayers = async () => {
    if (!supabase || !isAuthenticated || role !== 'admin') return
    setPlayerLoading(true)
    setPlayerError('')
    let query = supabase.from('players').select(PLAYER_SELECT, { count: 'exact' }).order('created_at', { ascending: false }).range((playerPage - 1) * playerPageSize, playerPage * playerPageSize - 1)
    if (playerSearchDebounced) query = query.or(`full_name.ilike.%${playerSearchDebounced}%,email.ilike.%${playerSearchDebounced}%,in_game_name.ilike.%${playerSearchDebounced}%,uid.ilike.%${playerSearchDebounced}%`)
    if (departmentFilter !== 'all') query = query.eq('department', departmentFilter)
    if (statusFilter !== 'all') query = query.eq('status', statusFilter)
    if (playerGameFilter !== 'all') query = query.eq('main_game', playerGameFilter)
    if (playerDateRange.from) query = query.gte('created_at', `${playerDateRange.from}T00:00:00+08:00`)
    if (playerDateRange.to) {
      const exclusiveEnd = new Date(`${playerDateRange.to}T00:00:00+08:00`)
      exclusiveEnd.setDate(exclusiveEnd.getDate() + 1)
      query = query.lt('created_at', exclusiveEnd.toISOString())
    }
    const { data, error, count } = await query
    if (error) {
      console.error('Players load failed:', error)
      setPlayerRows([])
      setPlayerTotal(0)
      setPlayerError(error.code === '42501' ? 'Admin permission required.' : 'Players are unavailable right now.')
      setPlayerLoading(false)
      return
    }
    const rows = (data ?? []) as unknown as SupabasePlayer[]
    setPlayerRows(rows)
    setPlayerTotal(count ?? 0)
    const paths = rows.map((row) => row.photo_path).filter((path): path is string => Boolean(path && !playerPhotoUrls[path]))
    if (paths.length) {
      const signed = await supabase.storage.from('player-photos').createSignedUrls(paths, 3600)
      if (!signed.error) setPlayerPhotoUrls((current) => ({ ...current, ...Object.fromEntries(paths.map((path, index) => [path, signed.data?.[index]?.signedUrl]).filter((entry): entry is [string, string] => Boolean(entry[1]))) }))
    }
    setPlayerLoading(false)
  }

  const loadPlayerCounts = async () => {
    if (!supabase || !isAuthenticated || role !== 'admin') return
    const [total, approved, pending] = await Promise.all([
      supabase.from('players').select('id', { count: 'exact', head: true }),
      supabase.from('players').select('id', { count: 'exact', head: true }).eq('status', 'approved'),
      supabase.from('players').select('id', { count: 'exact', head: true }).eq('status', 'pending'),
    ])
    const error = total.error || approved.error || pending.error
    if (error) {
      console.error('Player counts load failed:', error)
      return
    }
    setPlayerCounts({ total: total.count ?? 0, approved: approved.count ?? 0, pending: pending.count ?? 0 })
  }

  useEffect(() => { void loadPlayers() }, [isAuthenticated, role, playerPage, playerSearchDebounced, departmentFilter, statusFilter, playerGameFilter, playerDateRange])
  useEffect(() => { void loadPlayerCounts() }, [isAuthenticated, role])

  useEffect(() => {
    if (!isAuthenticated || !supabase) return
    let ignore = false
    setTimelineLoading(true)
    supabase.from('timeline_events').select('*').order('year', { ascending: true }).order('month', { ascending: true, nullsFirst: true }).order('created_at', { ascending: true }).then(({ data, error }) => {
      if (ignore) return
      if (error) {
        console.error('Timeline load failed:', error)
        setTimelineError('Timeline unavailable right now')
        setTimelineEvents([])
      } else {
        setTimelineError('')
        setTimelineEvents((data ?? []) as TimelineEvent[])
      }
      setTimelineLoading(false)
    })
    return () => { ignore = true }
  }, [isAuthenticated])

  const loadAdminGames = async () => {
    if (!supabase) return
    setGamesLoading(true)
    const { data, error } = await supabase.from('games').select('id,title,tag,description,image_url,is_visible,sort_order,created_at,updated_at').order('sort_order').order('created_at')
    if (error) {
      console.error('Games load failed:', error)
      toast({ title: 'Unable to load games', description: error.message, status: 'error', isClosable: true })
    } else setAdminGames((data ?? []) as AdminGame[])
    setGamesLoading(false)
  }

  useEffect(() => { if (isAuthenticated) void loadAdminGames() }, [isAuthenticated])

  const loadAdminEvents = async () => {
    if (!supabase || !isAuthenticated || role !== 'admin') return
    setEventsLoading(true)
    const { data, error } = await supabase.from('events').select('id,title,event_date,location,description,image_url,is_visible,sort_order,created_at,updated_at').order('event_date', { ascending: true }).order('sort_order', { ascending: true })
    if (error) {
      console.error('Events load failed:', error)
      setAdminEvents([])
      toast({ title: 'Unable to load events', description: mapSupabaseError(error), status: 'error', isClosable: true })
    } else setAdminEvents((data ?? []) as AdminEvent[])
    setEventsLoading(false)
  }

  useEffect(() => { void loadAdminEvents() }, [isAuthenticated, role])

  const loadAdminLatestUpdates = async () => {
    if (!supabase || !isAuthenticated || role !== 'admin') return
    setLatestUpdatesLoading(true)
    const { data, error } = await supabase.from('latest_updates').select('id,tag,title,description,published_at,is_visible,sort_order,created_at,updated_at').order('published_at', { ascending: false }).order('sort_order', { ascending: true })
    if (error) {
      console.error('Latest updates load failed:', error)
      setAdminLatestUpdates([])
      toast({ title: 'Unable to load latest updates', description: mapLatestUpdateError(error), status: 'error', isClosable: true })
    } else setAdminLatestUpdates((data ?? []) as AdminLatestUpdate[])
    setLatestUpdatesLoading(false)
  }

  useEffect(() => { void loadAdminLatestUpdates() }, [isAuthenticated, role])

  const loadAdminStaff = async () => {
    if (!supabase || !isAuthenticated || role !== 'admin') return
    setStaffLoading(true)
    const { data, error } = await supabase.from('staff').select('id,full_name,role_title,bio,photo_url,is_visible,sort_order,created_at,updated_at').order('sort_order', { ascending: true }).order('created_at', { ascending: true })
    if (error) {
      console.error('Staff load failed:', error)
      setAdminStaff([])
      toast({ title: 'Unable to load staff', description: mapSupabaseError(error), status: 'error', isClosable: true })
    } else setAdminStaff((data ?? []) as AdminStaff[])
    setStaffLoading(false)
  }

  useEffect(() => { void loadAdminStaff() }, [isAuthenticated, role])

  const [email, setEmail] = useState('admin@voltixfc.com')
  const [password, setPassword] = useState('demo-admin')
  const [modalState, setModalState] = useState<ModalState | null>(null)
  const [modalDraft, setModalDraft] = useState<Record<string, any> | null>(null)
  const [formErrors, setFormErrors] = useState<FormErrors>({})
  const [isImageUploading, setIsImageUploading] = useState(false)
  const [partnerUploadedPath, setPartnerUploadedPath] = useState<string | null>(null)
  const [partnerSaving, setPartnerSaving] = useState(false)
  const [partnerProcessing, setPartnerProcessing] = useState(false)
  const [eventImageFile, setEventImageFile] = useState<File | null>(null)
  const [partnerLogoInfo, setPartnerLogoInfo] = useState<{ size: number; warning?: string } | null>(null)
  const [confirmAction, setConfirmAction] = useState<ConfirmAction | null>(null)
  const confirm = useConfirm()

  useEffect(() => {
    if (!confirmAction) return
    const action = confirmAction
    let cancelled = false
    void confirm({
      title: action.title,
      message: action.description,
      confirmLabel: action.confirmLabel,
      cancelLabel: 'Cancel',
      tone: 'danger',
    }).then((confirmed) => {
      if (cancelled) return
      setConfirmAction(null)
      if (confirmed) void action.onConfirm()
    })
    return () => { cancelled = true }
  }, [confirm, confirmAction])

  const hasInvalidDateRange = datePreset === 'custom' && Boolean(fromDate && toDate && fromDate > toDate)

  const handleClearFilters = () => {
    setSearchTerm('')
    setDepartmentFilter('all')
    setStatusFilter('all')
    setPlayerGameFilter('all')
    setDatePreset('all')
    setFromDate('')
    setToDate('')
  }

  const handleTabChange = (tab: AdminTab) => {
    router.push(routeMap[tab])
  }

  const openModal = (kind: EntryKind, item: Record<string, any> | null, mode: ModalMode) => {
    const baseItem = item && kind === 'staff'
      ? { ...item, name: item.name ?? item.full_name ?? '', role: item.role ?? item.role_title ?? '', bio: item.bio ?? '', imageUrl: item.imageUrl ?? item.photo_url ?? '', image: item.image ?? item.photo_url ?? '' }
      : item && kind === 'update'
      ? { ...item, detail: item.detail ?? item.description ?? '', published_at: item.published_at ? String(item.published_at).slice(0, 16) : defaultUpdateForm.published_at }
      : item && kind === 'partner'
      ? { ...item, website: item.website ?? item.website_url ?? '', logo: item.logo ?? item.logo_url ?? '', imageUrl: item.imageUrl ?? item.logo_url ?? '' }
      : item ? { ...item } : createEmptyItem(kind)
    setModalState({ kind, mode, item: baseItem })
    setModalDraft(baseItem)
    setFormErrors({})
    if (kind === 'game') setGameLogoFile(null)
    if (kind === 'event') setEventImageFile(null)
    if (kind === 'staff') setStaffImageFile(null)
  }

  const closeModal = () => {
    setModalState(null)
    setModalDraft(null)
    setFormErrors({})
    setEventImageFile(null)
    setStaffImageFile(null)
  }

  const handleModalClose = () => {
    if (modalState && modalDraft && modalState.mode !== 'view' && itemIsDirty(modalDraft, modalState.item)) {
      setConfirmAction({
        title: 'Discard unsaved changes?',
        description: 'You have unsaved changes in this form. Are you sure you want to close it?',
        confirmLabel: 'Discard',
        onConfirm: () => {
          closeModal()
          setConfirmAction(null)
        },
      })
      return
    }
    closeModal()
  }

  const validateEntry = (kind: EntryKind, draft: Record<string, any>) => {
    const errors: FormErrors = {}

    if (kind === 'player') {
      if (!readValue(draft, 'first_name').trim()) errors.first_name = 'First name is required.'
      if (!readValue(draft, 'last_name').trim()) errors.last_name = 'Last name is required.'
      if (!readValue(draft, 'email').trim()) errors.email = 'Email is required.'
      if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(readValue(draft, 'email').trim())) errors.email = 'Enter a valid email.'
      if (readValue(draft, 'contact_number') && !/^(09\d{9}|\+639\d{9})$/.test(readValue(draft, 'contact_number').trim())) errors.contact_number = 'Use 09XXXXXXXXX or +639XXXXXXXXX.'
      if (readValue(draft, 'contact_link') && !/^https?:\/\/(www\.)?(facebook\.com|fb\.com|instagram\.com)\/.+/i.test(readValue(draft, 'contact_link').trim())) errors.contact_link = 'Use a Facebook, fb.com, or Instagram URL.'
      if (!['CODM', 'HOK'].includes(readValue(draft, 'main_game'))) errors.main_game = 'Choose CODM or HOK.'
      const allowedDepartments = DEPARTMENTS_BY_GAME[readValue(draft, 'main_game') as PlayerGame] ?? []
      if (!allowedDepartments.includes(readValue(draft, 'department') as never)) errors.department = 'Department is required.'
      if (!readValue(draft, 'in_game_name').trim()) errors.in_game_name = 'IGN is required.'
      if (!readValue(draft, 'uid').trim()) errors.uid = 'UID is required.'
    }

    if (kind === 'update') {
      if (!readValue(draft, 'title').trim()) errors.title = 'Title is required.'
      if (!readValue(draft, 'detail').trim()) errors.detail = 'Detail is required.'
      if (readValue(draft, 'tag').trim().length > 40) errors.tag = 'Tag must be 40 characters or fewer.'
      if (readValue(draft, 'title').trim().length > 120) errors.title = 'Title must be 120 characters or fewer.'
      if (readValue(draft, 'detail').trim().length > 400) errors.detail = 'Description must be 400 characters or fewer.'
      if (!readValue(draft, 'published_at').trim() || Number.isNaN(new Date(readValue(draft, 'published_at')).getTime())) errors.published_at = 'Published date is required.'
      if (!Number.isInteger(Number(draft.sort_order))) errors.sort_order = 'Sort order must be a whole number.'
    }

    if (kind === 'game') {
      if (!readValue(draft, 'title').trim()) errors.title = 'Title is required.'
      if (readValue(draft, 'title').trim().length > 60) errors.title = 'Name must be 60 characters or fewer.'
      if (!readValue(draft, 'tag').trim()) errors.tag = 'Genre is required.'
      if (readValue(draft, 'tag').trim().length > 40) errors.tag = 'Genre must be 40 characters or fewer.'
      if (readValue(draft, 'description').trim().length > 400) errors.description = 'Information must be 400 characters or fewer.'
      if (!readValue(draft, 'image_url') && !readValue(draft, 'imageUrl') && !readValue(draft, 'image') && !gameLogoFile) errors.image = 'A game logo is required.'
      if (Boolean(draft.is_visible ?? true) && !readValue(draft, 'image_url') && !readValue(draft, 'imageUrl') && !readValue(draft, 'image') && !gameLogoFile) errors.image = 'A visible game must have a logo.'
    }

    if (kind === 'partner') {
      if (!readValue(draft, 'name').trim()) errors.name = 'Name is required.'
      if (readValue(draft, 'name').trim().length > 120) errors.name = 'Name must be 120 characters or fewer.'
      if (readValue(draft, 'category').trim().length > 40) errors.category = 'Category must be 40 characters or fewer.'
      if (readValue(draft, 'description').trim().length > 400) errors.description = 'Description must be 400 characters or fewer.'
      if (readValue(draft, 'website').trim() && !/^https?:\/\//i.test(readValue(draft, 'website').trim())) errors.website = 'Website must start with http:// or https://.'
      if (readValue(draft, 'website').trim().length > 300) errors.website = 'Website must be 300 characters or fewer.'
      if (Boolean(draft.is_visible ?? true) && !readValue(draft, 'logo') && !readValue(draft, 'imageUrl')) errors.logo = 'A visible partner must have a logo.'
    }

    if (kind === 'event') {
      if (!readValue(draft, 'title').trim()) errors.title = 'Title is required.'
      if (!readValue(draft, 'date').trim()) errors.date = 'Date is required.'
      if (readValue(draft, 'title').trim().length > 120) errors.title = 'Title must be 120 characters or fewer.'
      if (readValue(draft, 'location').trim().length > 120) errors.location = 'Location must be 120 characters or fewer.'
      if (readValue(draft, 'description').trim().length > 400) errors.description = 'Description must be 400 characters or fewer.'
      if (readValue(draft, 'imageUrl').trim().length > 500) errors.image = 'Image URL must be 500 characters or fewer.'
      if (!Number.isInteger(Number(draft.sort_order))) errors.sort_order = 'Sort order must be a whole number.'
    }

    if (kind === 'staff') {
      if (!readValue(draft, 'name').trim()) errors.name = 'Name is required.'
      if (readValue(draft, 'name').trim().length > 120) errors.name = 'Name must be 120 characters or fewer.'
      if (readValue(draft, 'role').trim().length > 80) errors.role = 'Role must be 80 characters or fewer.'
      if (readValue(draft, 'bio').trim().length > 400) errors.bio = 'Bio must be 400 characters or fewer.'
      if (readValue(draft, 'imageUrl').trim().length > 500) errors.image = 'Photo URL must be 500 characters or fewer.'
      if (!Number.isInteger(Number(draft.sort_order))) errors.sort_order = 'Sort order must be a whole number.'
    }

    if (kind === 'timeline') {
      const year = Number(draft.year)
      if (!Number.isInteger(year) || year < 1990 || year > new Date().getFullYear() + 1) errors.year = `Enter a year from 1990 to ${new Date().getFullYear() + 1}.`
      if (!readValue(draft, 'title').trim()) errors.title = 'Title is required.'
      if (readValue(draft, 'title').trim().length > 80) errors.title = 'Title must be 80 characters or fewer.'
      if (readValue(draft, 'description').trim().length > 300) errors.description = 'Description must be 300 characters or fewer.'
    }

    return errors
  }

  const handleSaveModal = () => {
    if (!modalState || !modalDraft) return
    const errors = validateEntry(modalState.kind, modalDraft)
    if (Object.keys(errors).length > 0) {
      setFormErrors(errors)
      return
    }

    setConfirmAction({
      title: modalState.mode === 'add' ? 'Are you sure you want to add this entry?' : 'Are you sure you want to save these changes?',
      description: modalState.mode === 'add'
        ? 'This will create a new item in the dashboard.'
        : 'This change will be applied to the current record.',
      confirmLabel: 'Confirm',
      onConfirm: async () => {
        const draft = { ...modalDraft }
        if (modalState.kind === 'player') {
          if (!supabase) return
          const payload = {
            first_name: readValue(draft, 'first_name').trim(),
            last_name: readValue(draft, 'last_name').trim(),
            email: readValue(draft, 'email').trim(),
            contact_number: readValue(draft, 'contact_number').trim() || null,
            date_of_birth: readValue(draft, 'date_of_birth') || null,
            contact_link: readValue(draft, 'contact_link').trim() || null,
            registration_source: readValue(draft, 'registration_source'),
            main_game: readValue(draft, 'main_game'),
            department: readValue(draft, 'department') || 'Clan',
            in_game_name: readValue(draft, 'in_game_name').trim(),
            uid: readValue(draft, 'uid').trim(),
            player_id: readValue(draft, 'player_id').trim() || null,
            status: readValue(draft, 'status'),
          }
          const result = modalState.mode === 'add'
            ? await supabase.from('players').insert(payload)
            : await supabase.from('players').update(payload).eq('id', draft.id)
          if (result.error) {
            console.error('Player save failed:', result.error)
            toast({ title: 'Unable to save player', description: mapSupabaseError(result.error), status: 'error', isClosable: true })
            return
          }
          await loadPlayers()
          await loadPlayerCounts()
          toast({ title: modalState.mode === 'add' ? 'Player added' : 'Player updated', description: `${payload.first_name} ${payload.last_name} was saved.`, status: 'success', isClosable: true })
        }

        if (modalState.kind === 'update') {
          if (!supabase) return
          const payload = { tag: readValue(draft, 'tag').trim() || null, title: readValue(draft, 'title').trim(), description: readValue(draft, 'detail').trim() || null, published_at: new Date(readValue(draft, 'published_at')).toISOString(), is_visible: Boolean(draft.is_visible ?? true), sort_order: Number(draft.sort_order ?? 0) }
          const result = modalState.mode === 'add'
            ? await supabase.from('latest_updates').insert(payload).select().single()
            : await supabase.from('latest_updates').update(payload).eq('id', draft.id).select().single()
          if (result.error) {
            toast({ title: 'Unable to save latest update', description: mapLatestUpdateError(result.error), status: 'error', isClosable: true })
            return
          }
          await loadAdminLatestUpdates()
          window.dispatchEvent(new Event('latest-updates-updated'))
          toast({ title: modalState.mode === 'add' ? 'Update added' : 'Update saved', description: `${payload.title} was saved.`, status: 'success', isClosable: true })
        }

        if (modalState.kind === 'game') {
          if (!supabase) return
          setGameSaving(true)
          const oldUrl = readValue(draft, 'image_url') || readValue(draft, 'imageUrl') || readValue(draft, 'image')
          let imageUrl = oldUrl || null
          let uploadedPath: string | null = null
          if (gameLogoFile) {
            setGameLogoProcessing(true)
            let normalized: NormalizedLogo
            try { normalized = await normalizeLogoToSquare(gameLogoFile) } catch (error) { toast({ title: 'Unable to process logo', description: error instanceof Error ? error.message : 'Unable to process the logo.', status: 'error', isClosable: true }); setGameLogoProcessing(false); setGameSaving(false); return }
            setGameLogoInfo({ size: normalized.blob.size, warning: normalized.warning })
            const extension = normalized.format
            uploadedPath = `games/${crypto.randomUUID()}.${extension}`
            const uploadResult = await supabase.storage.from('site-media').upload(uploadedPath, normalized.blob, { contentType: normalized.blob.type, cacheControl: '3600', upsert: false })
            if (uploadResult.error) {
              console.error('Game logo upload failed:', uploadResult.error)
              toast({ title: 'Unable to upload logo', description: uploadResult.error.message, status: 'error', isClosable: true })
              setGameSaving(false)
              setGameLogoProcessing(false)
              return
            }
            imageUrl = supabase.storage.from('site-media').getPublicUrl(uploadedPath).data.publicUrl
          }
          const payload = { title: readValue(draft, 'title').trim(), tag: readValue(draft, 'tag').trim(), description: readValue(draft, 'description').trim() || null, image_url: imageUrl, is_visible: Boolean(draft.is_visible ?? true), sort_order: modalState.mode === 'add' ? Math.max(-1, ...adminGames.map((item) => item.sort_order)) + 1 : Number(draft.sort_order ?? 0) }
          const result = modalState.mode === 'add'
            ? await supabase.from('games').insert(payload).select().single()
            : await supabase.from('games').update(payload).eq('id', draft.id).select().single()
          if (result.error) {
            if (uploadedPath) await supabase.storage.from('site-media').remove([uploadedPath])
            console.error('Game save failed:', result.error)
            toast({ title: 'Unable to save game', description: result.error.message, status: 'error', isClosable: true })
            setGameSaving(false)
            return
          }
          if (gameLogoFile && modalState.mode === 'edit') {
            const oldPath = gameStoragePath(oldUrl)
            if (oldPath) await supabase.storage.from('site-media').remove([oldPath])
          }
          await loadAdminGames()
          window.dispatchEvent(new Event('games-updated'))
          toast({ title: modalState.mode === 'add' ? 'Game added' : 'Game updated', description: `${payload.title} was saved.`, status: 'success', isClosable: true })
          setGameSaving(false)
          setGameLogoProcessing(false)
        }

        if (modalState.kind === 'partner') {
          if (!supabase) return
          setPartnerSaving(true)
          const name = readValue(draft, 'name').trim()
          const category = readValue(draft, 'category').trim() || null
          const description = readValue(draft, 'description').trim() || null
          const websiteUrl = readValue(draft, 'website').trim() || null
          const logoUrl = readValue(draft, 'logo') || readValue(draft, 'imageUrl') || null
          const basePayload = { name, category, description, website_url: websiteUrl, logo_url: logoUrl, is_visible: Boolean(draft.is_visible ?? true) }
          const originalPartner = modalState.item
          const changedPayload = Object.fromEntries(Object.entries(basePayload).filter(([key, value]) => {
            const originalKey = key === 'website_url' ? 'website_url' : key
            return modalState.mode === 'add' || value !== (originalPartner[originalKey] ?? null)
          }))
          const result = modalState.mode === 'add'
            ? await supabase.from('partners').insert({ ...basePayload, sort_order: Math.max(-1, ...partners.map((item) => item.sort_order)) + 1 }).select().single()
            : await supabase.from('partners').update(changedPayload).eq('id', draft.id).select().single()
          if (result.error) {
            if (partnerUploadedPath) await supabase.storage.from('site-media').remove([partnerUploadedPath])
            console.error('Partner save failed:', result.error)
            toast({ title: 'Unable to save partner', description: mapSupabaseError(result.error), status: 'error', isClosable: true })
            setPartnerSaving(false)
            return
          }
          const oldPath = partnerStoragePath(readValue(modalState.item, 'logo_url') || readValue(modalState.item, 'logo') || readValue(modalState.item, 'imageUrl'))
          if (oldPath && oldPath !== partnerUploadedPath && oldPath !== partnerStoragePath(logoUrl)) await supabase.storage.from('site-media').remove([oldPath])
          await refreshPartners()
          window.dispatchEvent(new Event(PARTNERS_UPDATED_EVENT))
          toast({ title: modalState.mode === 'add' ? 'Partner added' : 'Partner updated', description: `${name} was saved.`, status: 'success', isClosable: true })
          setPartnerUploadedPath(null)
          setPartnerSaving(false)
        }

        if (modalState.kind === 'event') {
          if (!supabase) return
          setIsImageUploading(Boolean(eventImageFile))
          const oldUrl = readValue(draft, 'image_url') || readValue(draft, 'imageUrl') || readValue(draft, 'image')
          let imageUrl = oldUrl || null
          let uploadedPath: string | null = null
          if (eventImageFile) {
            let normalized: NormalizedLogo
            try { normalized = await normalizeLogoToSquare(eventImageFile) } catch (error) { toast({ title: 'Unable to process event image', description: error instanceof Error ? error.message : 'Unable to process the event image.', status: 'error', isClosable: true }); setIsImageUploading(false); return }
            uploadedPath = `events/${crypto.randomUUID()}.${normalized.format}`
            const uploadResult = await supabase.storage.from('site-media').upload(uploadedPath, normalized.blob, { contentType: normalized.blob.type, cacheControl: '3600', upsert: false })
            if (uploadResult.error) { toast({ title: 'Unable to upload event image', description: mapSupabaseError(uploadResult.error), status: 'error', isClosable: true }); setIsImageUploading(false); return }
            imageUrl = supabase.storage.from('site-media').getPublicUrl(uploadedPath).data.publicUrl
          }
          const payload = { title: readValue(draft, 'title').trim(), event_date: readValue(draft, 'date'), location: readValue(draft, 'location').trim() || null, description: readValue(draft, 'description').trim() || null, image_url: imageUrl, is_visible: Boolean(draft.is_visible ?? true), sort_order: Number(draft.sort_order ?? 0) }
          const result = modalState.mode === 'add'
            ? await supabase.from('events').insert(payload).select().single()
            : await supabase.from('events').update(payload).eq('id', draft.id).select().single()
          if (result.error) {
            if (uploadedPath) await supabase.storage.from('site-media').remove([uploadedPath])
            toast({ title: 'Unable to save event', description: mapSupabaseError(result.error), status: 'error', isClosable: true })
            setIsImageUploading(false)
            return
          }
          const oldPath = eventStoragePath(oldUrl)
          if (oldPath && oldPath !== uploadedPath) await supabase.storage.from('site-media').remove([oldPath])
          await loadAdminEvents()
          window.dispatchEvent(new Event('events-updated'))
          toast({ title: modalState.mode === 'add' ? 'Event added' : 'Event updated', description: `${payload.title} was saved.`, status: 'success', isClosable: true })
          setIsImageUploading(false)
        }

        if (modalState.kind === 'staff') {
          if (!supabase) return
          setIsImageUploading(Boolean(staffImageFile))
          const oldUrl = readValue(draft, 'photo_url') || readValue(draft, 'imageUrl') || readValue(draft, 'image')
          let photoUrl = oldUrl || null
          let uploadedPath: string | null = null
          if (staffImageFile) {
            let normalized: NormalizedLogo
            try { normalized = await normalizeLogoToSquare(staffImageFile) } catch (error) { toast({ title: 'Unable to process staff photo', description: error instanceof Error ? error.message : 'Unable to process the staff photo.', status: 'error', isClosable: true }); setIsImageUploading(false); return }
            uploadedPath = `staff/${crypto.randomUUID()}.${normalized.format}`
            const uploadResult = await supabase.storage.from('site-media').upload(uploadedPath, normalized.blob, { contentType: normalized.blob.type, cacheControl: '3600', upsert: false })
            if (uploadResult.error) { toast({ title: 'Unable to upload staff photo', description: mapSupabaseError(uploadResult.error), status: 'error', isClosable: true }); setIsImageUploading(false); return }
            photoUrl = supabase.storage.from('site-media').getPublicUrl(uploadedPath).data.publicUrl
          }
          const payload = { full_name: readValue(draft, 'name').trim(), role_title: readValue(draft, 'role').trim() || null, bio: readValue(draft, 'bio').trim() || null, photo_url: photoUrl, is_visible: Boolean(draft.is_visible ?? true), sort_order: Number(draft.sort_order ?? 0) }
          const result = modalState.mode === 'add'
            ? await supabase.from('staff').insert(payload).select().single()
            : await supabase.from('staff').update(payload).eq('id', draft.id).select().single()
          if (result.error) {
            if (uploadedPath) await supabase.storage.from('site-media').remove([uploadedPath])
            toast({ title: 'Unable to save staff member', description: mapSupabaseError(result.error), status: 'error', isClosable: true })
            setIsImageUploading(false)
            return
          }
          const oldPath = staffStoragePath(oldUrl)
          if (oldPath && oldPath !== uploadedPath) await supabase.storage.from('site-media').remove([oldPath])
          await loadAdminStaff()
          setIsImageUploading(false)
          toast({ title: modalState.mode === 'add' ? 'Staff member added' : 'Staff member updated', description: `${payload.full_name} was saved.`, status: 'success', isClosable: true })
        }

        if (modalState.kind === 'timeline' && supabase) {
          setTimelineSaving(true)
          const payload = { year: Number(draft.year), month: draft.month ? Number(draft.month) : null, title: readValue(draft, 'title').trim(), description: readValue(draft, 'description').trim() || null, is_visible: Boolean(draft.is_visible) }
          const result = modalState.mode === 'add'
            ? await supabase.from('timeline_events').insert(payload).select().single()
            : await supabase.from('timeline_events').update(payload).eq('id', draft.id).select().single()
          if (result.error) {
            console.error('Timeline save failed:', result.error)
            toast({ title: 'Unable to save milestone', description: result.error.message, status: 'error', isClosable: true })
            setTimelineSaving(false)
            return
          }
          setTimelineEvents((current) => modalState.mode === 'add' ? [...current, result.data as TimelineEvent].sort(sortTimelineEvents) : current.map((item) => item.id === draft.id ? result.data as TimelineEvent : item).sort(sortTimelineEvents))
          toast({ title: modalState.mode === 'add' ? 'Milestone added' : 'Milestone updated', status: 'success', isClosable: true })
          setTimelineSaving(false)
        }

        closeModal()
        setGameLogoFile(null)
        setConfirmAction(null)
      },
    })
  }

  const handleDeleteEntry = (kind: EntryKind, id: string) => {
    const gameName = kind === 'game' ? adminGames.find((item) => item.id === id)?.title ?? 'this game' : ''
    setConfirmAction({
      title: kind === 'timeline' ? 'Delete this milestone? This cannot be undone.' : kind === 'game' ? `Delete ${gameName}? This can't be undone.` : kind === 'partner' ? `Delete ${partners.find((item) => item.id === id)?.name ?? 'partner'}?` : 'Are you sure you want to delete this entry? This cannot be undone.',
      description: kind === 'timeline' ? 'You can hide a milestone instead by turning off Visible on website.' : kind === 'game' ? 'You can hide it instead.' : kind === 'partner' ? "This can't be undone. You can hide it instead." : 'This action removes the record immediately from the dashboard.',
      confirmLabel: 'Delete',
      onConfirm: async () => {
        if (kind === 'player') {
          if (!supabase) return
          const { error } = await supabase.from('players').delete().eq('id', id)
          if (error) {
            console.error('Player delete failed:', error)
            toast({ title: 'Unable to delete player', description: mapSupabaseError(error), status: 'error', isClosable: true })
            return
          }
          await loadPlayers()
          await loadPlayerCounts()
          toast({ title: 'Player deleted', description: 'The player record was removed.', status: 'info', isClosable: true })
        }
        if (kind === 'update') {
          if (!supabase) return
          const { error } = await supabase.from('latest_updates').delete().eq('id', id)
          if (error) {
            toast({ title: 'Unable to delete latest update', description: mapLatestUpdateError(error), status: 'error', isClosable: true })
            return
          }
          await loadAdminLatestUpdates()
          window.dispatchEvent(new Event('latest-updates-updated'))
          toast({ title: 'Update deleted', description: 'The entry was removed from the feed.', status: 'info', isClosable: true })
        }
        if (kind === 'game') {
          if (!supabase) return
          const game = adminGames.find((item) => item.id === id)
          const { error } = await supabase.from('games').delete().eq('id', id)
          if (error) {
            console.error('Game delete failed:', error)
            toast({ title: 'Unable to delete game', description: error.message, status: 'error', isClosable: true })
            return
          }
          const logoPath = gameStoragePath(game?.image_url)
          if (logoPath) await supabase.storage.from('site-media').remove([logoPath])
          await loadAdminGames()
          window.dispatchEvent(new Event('games-updated'))
          toast({ title: 'Game deleted', description: 'The game item was removed.', status: 'info', isClosable: true })
        }
        if (kind === 'partner') {
          if (!supabase) return
          const partner = partners.find((item) => item.id === id)
          const { error } = await supabase.from('partners').delete().eq('id', id)
          if (error) {
            console.error('Partner delete failed:', error)
            toast({ title: 'Unable to delete partner', description: mapSupabaseError(error), status: 'error', isClosable: true })
            return
          }
          const oldPath = partnerStoragePath(partner?.logo_url)
          if (oldPath) await supabase.storage.from('site-media').remove([oldPath])
          await refreshPartners()
          window.dispatchEvent(new Event(PARTNERS_UPDATED_EVENT))
          toast({ title: 'Partner deleted', description: 'The partner was removed.', status: 'info', isClosable: true })
        }
        if (kind === 'event') {
          if (!supabase) return
          const event = adminEvents.find((item) => item.id === id)
          const { error } = await supabase.from('events').delete().eq('id', id)
          if (error) {
            toast({ title: 'Unable to delete event', description: mapSupabaseError(error), status: 'error', isClosable: true })
            return
          }
          const imagePath = eventStoragePath(event?.image_url)
          if (imagePath) await supabase.storage.from('site-media').remove([imagePath])
          await loadAdminEvents()
          window.dispatchEvent(new Event('events-updated'))
          toast({ title: 'Event deleted', description: 'The event was removed.', status: 'info', isClosable: true })
        }
        if (kind === 'staff') {
          if (!supabase) return
          const staff = adminStaff.find((item) => item.id === id)
          const { error } = await supabase.from('staff').delete().eq('id', id)
          if (error) {
            toast({ title: 'Unable to delete staff member', description: mapSupabaseError(error), status: 'error', isClosable: true })
            return
          }
          const photoPath = staffStoragePath(staff?.photo_url)
          if (photoPath) await supabase.storage.from('site-media').remove([photoPath])
          await loadAdminStaff()
          toast({ title: 'Staff removed', description: 'The staff record was removed.', status: 'info', isClosable: true })
        }
        if (kind === 'timeline' && supabase) {
          const { error } = await supabase.from('timeline_events').delete().eq('id', id)
          if (error) {
            console.error('Timeline delete failed:', error)
            toast({ title: 'Unable to delete milestone', description: error.message, status: 'error', isClosable: true })
            return
          }
          setTimelineEvents((current) => current.filter((item) => item.id !== id))
          toast({ title: 'Milestone deleted', status: 'info', isClosable: true })
        }
        setConfirmAction(null)
      },
    })
  }

  const handlePlayerApprove = (playerId: string, action: 'approve' | 'reject') => {
    setConfirmAction({
      title: action === 'approve' ? 'Approve player?' : 'Reject player?',
      description: action === 'approve'
        ? 'Are you sure you want to approve this application?'
        : 'Are you sure you want to reject this application?',
      confirmLabel: action === 'approve' ? 'Approve' : 'Reject',
      onConfirm: async () => {
        if (!supabase) return
        const player = playerRows.find((item) => item.id === playerId)
        const { error } = await supabase.from('players').update({ status: action === 'approve' ? 'approved' : 'rejected' }).eq('id', playerId)
        if (error) {
          console.error('Player status update failed:', error)
          toast({ title: 'Unable to update player', description: mapSupabaseError(error), status: 'error', isClosable: true })
          return
        }
        await loadPlayers()
        await loadPlayerCounts()
        toast({ title: action === 'approve' ? 'Application approved' : 'Application rejected', description: `${player?.full_name ?? 'Player'} was ${action === 'approve' ? 'approved' : 'rejected'}.`, status: action === 'approve' ? 'success' : 'warning', isClosable: true })
        setConfirmAction(null)
      },
    })
  }

  const moveGame = async (item: AdminGame, direction: 'up' | 'down') => {
    if (!supabase) return
    const index = adminGames.findIndex((game) => game.id === item.id)
    const neighbor = adminGames[index + (direction === 'up' ? -1 : 1)]
    if (!neighbor) return
    const first = await supabase.from('games').update({ sort_order: neighbor.sort_order }).eq('id', item.id)
    const second = await supabase.from('games').update({ sort_order: item.sort_order }).eq('id', neighbor.id)
    if (first.error || second.error) {
      const error = first.error || second.error
      console.error('Game reorder failed:', error)
      toast({ title: 'Unable to reorder games', description: error?.message, status: 'error', isClosable: true })
      return
    }
    await loadAdminGames()
    window.dispatchEvent(new Event('games-updated'))
  }

  const renderModalForm = () => {
    if (!modalState || !modalDraft) return null

    const fieldError = (key: string) => formErrors[key]

    const updateField = (key: string, value: string) => {
      setModalDraft((current) => ({ ...current, [key]: value }))
      setFormErrors((current) => ({ ...current, [key]: '' }))
    }

    const handleImageUpload = async (file: File | null) => {
      if (!file) {
        const imageKey = modalState.kind === 'player' ? 'photoUrl' : 'imageUrl'
        updateField(imageKey, '')
        if (modalState.kind === 'partner') updateField('logo', '')
        if (modalState.kind === 'event') setEventImageFile(null)
        if (modalState.kind === 'staff') setStaffImageFile(null)
        return
      }

      if (!['image/jpeg', 'image/png', 'image/webp'].includes(file.type)) {
        setFormErrors((current) => ({ ...current, image: 'Only JPG, PNG, and WEBP images are allowed.' }))
        return
      }

      if (file.size > (modalState.kind === 'partner' ? 10 : 5) * 1024 * 1024) {
        setFormErrors((current) => ({ ...current, image: modalState.kind === 'partner' ? 'Logo files must be 10 MB or smaller.' : 'Image must be 5MB or smaller.' }))
        return
      }

      if (modalState.kind === 'event') {
        setEventImageFile(file)
        setIsImageUploading(false)
        setFormErrors((current) => ({ ...current, image: '' }))
        return
      }

      if (modalState.kind === 'staff') {
        setStaffImageFile(file)
        setIsImageUploading(false)
        setFormErrors((current) => ({ ...current, image: '' }))
        return
      }

      if (modalState.kind === 'partner') setPartnerProcessing(true)
      setIsImageUploading(true)
      setFormErrors((current) => ({ ...current, image: '' }))

      const result = modalState.kind === 'partner' ? await uploadPartnerLogo(file) : await uploadPlayerPhoto(file)
      setIsImageUploading(false)
      if (modalState.kind === 'partner') setPartnerProcessing(false)

      if (!result.success || !result.publicUrl) {
        setFormErrors((current) => ({ ...current, image: result.message }))
        return
      }

      const key = modalState.kind === 'player' ? 'photoUrl' : 'imageUrl'
      updateField(key, result.publicUrl)
      if (modalState.kind === 'partner') {
        updateField('logo', result.publicUrl)
        setPartnerUploadedPath(result.path ?? null)
        if (modalState.kind === 'partner' && 'normalized' in result) {
          const normalized = result.normalized as NormalizedLogo | undefined
          if (normalized) setPartnerLogoInfo({ size: normalized.blob.size, warning: normalized.warning })
        }
      }
    }

    const getImageValue = () => {
      const source = modalState.kind === 'player'
        ? readValue(modalDraft, 'photoUrl') || readValue(modalDraft, 'imageUrl')
        : readValue(modalDraft, 'image_url') || readValue(modalDraft, 'imageUrl') || readValue(modalDraft, 'logo') || readValue(modalDraft, 'image')

      return typeof source === 'string' ? source : ''
    }

    const previewTitle = (() => {
      if (modalState.kind === 'player') return readValue(modalDraft, 'name') || 'Player'
      if (modalState.kind === 'update') return readValue(modalDraft, 'title') || 'Update'
      if (modalState.kind === 'game') return readValue(modalDraft, 'title') || 'Game'
      if (modalState.kind === 'partner') return readValue(modalDraft, 'name') || 'Partner'
      if (modalState.kind === 'event') return readValue(modalDraft, 'title') || 'Event'
      if (modalState.kind === 'timeline') return readValue(modalDraft, 'title') || 'Milestone'
      return readValue(modalDraft, 'name') || 'Staff member'
    })()

    const renderFieldSet = () => {
      switch (modalState.kind) {
        case 'player':
          return (
            <Stack spacing={4}>
              <SimpleGrid columns={{ base: 1, md: 2 }} spacing={4}>
                <FormControl isInvalid={Boolean(fieldError('first_name'))}>
                  <FormLabel>First name</FormLabel>
                  <Input value={readValue(modalDraft, 'first_name')} onChange={(e) => updateField('first_name', e.target.value)} />
                  <FormErrorMessage>{fieldError('first_name')}</FormErrorMessage>
                </FormControl>
                <FormControl isInvalid={Boolean(fieldError('last_name'))}>
                  <FormLabel>Last name</FormLabel>
                  <Input value={readValue(modalDraft, 'last_name')} onChange={(e) => updateField('last_name', e.target.value)} />
                  <FormErrorMessage>{fieldError('last_name')}</FormErrorMessage>
                </FormControl>
                <FormControl isInvalid={Boolean(fieldError('email'))}>
                  <FormLabel>Email</FormLabel>
                  <Input type="email" value={readValue(modalDraft, 'email')} onChange={(e) => updateField('email', e.target.value)} />
                  <FormErrorMessage>{fieldError('email')}</FormErrorMessage>
                </FormControl>
                <FormControl>
                  <FormLabel>Phone</FormLabel>
                  <Input value={readValue(modalDraft, 'contact_number')} onChange={(e) => updateField('contact_number', e.target.value)} />
                  <FormErrorMessage>{fieldError('contact_number')}</FormErrorMessage>
                </FormControl>
                <FormControl>
                  <FormLabel>Date of birth</FormLabel>
                  <Input type="date" value={readValue(modalDraft, 'date_of_birth')} onChange={(e) => updateField('date_of_birth', e.target.value)} />
                </FormControl>
                <FormControl isInvalid={Boolean(fieldError('contact_link'))}>
                  <FormLabel>Contact link</FormLabel>
                  <Input value={readValue(modalDraft, 'contact_link')} onChange={(e) => updateField('contact_link', e.target.value)} />
                  <FormErrorMessage>{fieldError('contact_link')}</FormErrorMessage>
                </FormControl>
                <FormControl><FormLabel>Registration source</FormLabel><Select value={readValue(modalDraft, 'registration_source')} onChange={(e) => updateField('registration_source', e.target.value)}><option>Online Recruitment</option><option>LAN Event</option></Select></FormControl>
                <FormControl isInvalid={Boolean(fieldError('main_game'))}><FormLabel>Main game</FormLabel><Select value={readValue(modalDraft, 'main_game')} onChange={(e) => { const mainGame = e.target.value as PlayerGame; const allowed = DEPARTMENTS_BY_GAME[mainGame]; updateField('main_game', mainGame); if (!allowed.includes(readValue(modalDraft, 'department') as never)) updateField('department', allowed[0]) }}><option value="CODM">CODM</option><option value="HOK">HOK</option></Select><FormErrorMessage>{fieldError('main_game')}</FormErrorMessage></FormControl>
                <FormControl isRequired><FormLabel>Department</FormLabel><Select value={readValue(modalDraft, 'department') || 'Clan'} onChange={(e) => updateField('department', e.target.value)}>{DEPARTMENTS_BY_GAME[readValue(modalDraft, 'main_game') as PlayerGame].map((department) => <option key={department} value={department}>{department}</option>)}</Select></FormControl>
                <FormControl><FormLabel>In-game name</FormLabel><Input maxLength={40} value={readValue(modalDraft, 'in_game_name')} onChange={(e) => updateField('in_game_name', e.target.value)} /><Text fontSize="xs" color={modalMuted} textAlign="right">{readValue(modalDraft, 'in_game_name').length}/40</Text></FormControl>
                <FormControl isInvalid={Boolean(fieldError('uid'))}><FormLabel>UID</FormLabel><Input maxLength={40} value={readValue(modalDraft, 'uid')} onChange={(e) => updateField('uid', e.target.value)} /><FormErrorMessage>{fieldError('uid')}</FormErrorMessage></FormControl>
                {readValue(modalDraft, 'main_game') === 'CODM' ? <FormControl><FormLabel>Player ID</FormLabel><Input maxLength={40} value={readValue(modalDraft, 'player_id')} onChange={(e) => updateField('player_id', e.target.value)} /></FormControl> : null}
                <FormControl><FormLabel>Status</FormLabel><Select value={readValue(modalDraft, 'status')} onChange={(e) => updateField('status', e.target.value)}><option value="pending">Pending</option><option value="approved">Approved</option><option value="rejected">Rejected</option></Select></FormControl>
              </SimpleGrid>
            </Stack>
          )
        case 'update':
          return (
            <Stack spacing={4}>
              <SimpleGrid columns={{ base: 1, md: 2 }} spacing={4}>
                <FormControl isInvalid={Boolean(fieldError('title'))} gridColumn={{ base: 'auto', md: '1 / -1' }}>
                  <FormLabel>Title</FormLabel>
                  <Input maxLength={120} value={readValue(modalDraft, 'title')} onChange={(e) => updateField('title', e.target.value)} />
                  <FormErrorMessage>{fieldError('title')}</FormErrorMessage>
                </FormControl>
                <FormControl isInvalid={Boolean(fieldError('tag'))}>
                  <FormLabel>Tag</FormLabel>
                  <Input maxLength={40} value={readValue(modalDraft, 'tag')} onChange={(e) => updateField('tag', e.target.value)} />
                  <FormErrorMessage>{fieldError('tag')}</FormErrorMessage>
                </FormControl>
                <FormControl isInvalid={Boolean(fieldError('published_at'))}>
                  <FormLabel>Published at</FormLabel>
                  <Input type="datetime-local" value={readValue(modalDraft, 'published_at')} onChange={(e) => updateField('published_at', e.target.value)} />
                  <FormErrorMessage>{fieldError('published_at')}</FormErrorMessage>
                </FormControl>
                <FormControl display="flex" alignItems="center" gap={3} pt={8}>
                  <Switch isChecked={Boolean(modalDraft.is_visible ?? true)} onChange={(e) => setModalDraft((current) => ({ ...current, is_visible: e.target.checked }))} />
                  <FormLabel mb={0}>Visible on website</FormLabel>
                </FormControl>
                <FormControl isInvalid={Boolean(fieldError('sort_order'))}>
                  <FormLabel>Sort order</FormLabel>
                  <Input type="number" value={readValue(modalDraft, 'sort_order')} onChange={(e) => updateField('sort_order', e.target.value)} />
                  <FormErrorMessage>{fieldError('sort_order')}</FormErrorMessage>
                </FormControl>
              </SimpleGrid>
              <FormControl isInvalid={Boolean(fieldError('detail'))}>
                <FormLabel>Detail</FormLabel>
                <Textarea maxLength={400} value={readValue(modalDraft, 'detail')} onChange={(e) => updateField('detail', e.target.value)} />
                <Text fontSize="sm" color="gray.500" textAlign="right">{readValue(modalDraft, 'detail').length}/400</Text>
                <FormErrorMessage>{fieldError('detail')}</FormErrorMessage>
              </FormControl>
              <ImageUrlField
                label="Image upload"
                value={getImageValue()}
                onChange={(value) => updateField('imageUrl', value)}
                allowUpload
                isUploading={isImageUploading}
                error={fieldError('image')}
                onFileChange={handleImageUpload}
                entityType="latestUpdate"
              />
            </Stack>
          )
        case 'game':
          return (
            <Stack spacing={4}>
              <GameLogoField value={readValue(modalDraft, 'image_url') || getImageValue()} file={gameLogoFile} error={fieldError('image')} onChange={(file) => { setGameLogoInfo(null); setGameLogoFile(file) }} onRemove={() => { setGameLogoInfo(null); setGameLogoFile(null); updateField('image_url', '') }} />
              <Text fontSize="sm" color={modalMuted}>Any size is accepted. We convert it to a square 800x800 image automatically.</Text>
              {gameLogoInfo ? <Text fontSize="sm" color={modalMuted}>Converted: 800x800, {(gameLogoInfo.size / 1024).toFixed(1)} KB{gameLogoInfo.warning ? ` - ${gameLogoInfo.warning}` : ''}</Text> : null}
              <SimpleGrid columns={{ base: 1, md: 2 }} spacing={4}>
                <FormControl isInvalid={Boolean(fieldError('title'))} gridColumn={{ base: 'auto', md: '1 / -1' }}>
                  <FormLabel>Game name</FormLabel>
                  <Input maxLength={60} value={readValue(modalDraft, 'title')} onChange={(e) => updateField('title', e.target.value)} />
                  <FormErrorMessage>{fieldError('title')}</FormErrorMessage>
                </FormControl>
                <FormControl isInvalid={Boolean(fieldError('tag'))}>
                  <FormLabel>Genre</FormLabel>
                  <Input maxLength={40} list="game-genre-suggestions" value={readValue(modalDraft, 'tag') || readValue(modalDraft, 'genre')} onChange={(e) => updateField('tag', e.target.value)} />
                  <datalist id="game-genre-suggestions"><option value="FPS" /><option value="MOBA" /><option value="Battle Royale" /><option value="MMORPG" /><option value="Sports" /><option value="Strategy" /><option value="Fighting" /><option value="Racing" /></datalist>
                  <FormErrorMessage>{fieldError('tag')}</FormErrorMessage>
                </FormControl>
                <FormControl display="flex" alignItems="center" gap={3} pt={8}>
                  <Switch isChecked={Boolean(modalDraft.is_visible ?? true)} onChange={(e) => setModalDraft((current) => ({ ...current, is_visible: e.target.checked }))} />
                  <FormLabel mb={0}>Visible on website</FormLabel>
                </FormControl>
              </SimpleGrid>
              <FormControl isInvalid={Boolean(fieldError('description'))}>
                <FormLabel>Information shown when visitors click the logo</FormLabel>
                <Textarea maxLength={400} value={readValue(modalDraft, 'description')} onChange={(e) => updateField('description', e.target.value)} />
                <Text fontSize="sm" color="gray.500" textAlign="right">{readValue(modalDraft, 'description').length}/400</Text>
                <FormErrorMessage>{fieldError('description')}</FormErrorMessage>
              </FormControl>
            </Stack>
          )
        case 'partner':
          return (
            <Stack spacing={4}>
              <SimpleGrid columns={{ base: 1, md: 2 }} spacing={4}>
                <FormControl isInvalid={Boolean(fieldError('name'))}>
                  <FormLabel>Name</FormLabel>
                  <Input maxLength={120} value={readValue(modalDraft, 'name')} onChange={(e) => updateField('name', e.target.value)} />
                  <FormErrorMessage>{fieldError('name')}</FormErrorMessage>
                </FormControl>
                <FormControl isInvalid={Boolean(fieldError('category'))}>
                  <FormLabel>Category</FormLabel>
                  <Input maxLength={40} list="partner-category-suggestions" value={readValue(modalDraft, 'category')} onChange={(e) => updateField('category', e.target.value)} />
                  <datalist id="partner-category-suggestions"><option value="Sponsor" /><option value="Community Partner" /><option value="Media Partner" /><option value="Tournament Partner" /></datalist>
                  <FormErrorMessage>{fieldError('category')}</FormErrorMessage>
                </FormControl>
              </SimpleGrid>
              <FormControl>
                <FormLabel>Website</FormLabel>
                <Input maxLength={300} value={readValue(modalDraft, 'website')} onChange={(e) => updateField('website', e.target.value)} />
                <FormErrorMessage>{fieldError('website')}</FormErrorMessage>
              </FormControl>
              <FormControl>
                <FormLabel>Description</FormLabel>
                <Textarea maxLength={400} value={readValue(modalDraft, 'description')} onChange={(e) => updateField('description', e.target.value)} />
                <Text fontSize="sm" color="gray.500" textAlign="right">{readValue(modalDraft, 'description').length}/400</Text>
              </FormControl>
              <ImageUrlField
                label="Image upload"
                value={getImageValue()}
                onChange={(value) => updateField('imageUrl', value)}
                allowUpload
                isUploading={isImageUploading}
                error={fieldError('image')}
                onFileChange={handleImageUpload}
                entityType="partner"
                maxSizeMB={10}
              />
              <Text fontSize="sm" color={modalMuted}>Any size is accepted. We convert it to a square 800x800 image automatically.</Text>
              {partnerLogoInfo ? <Text fontSize="sm" color={modalMuted}>Converted: 800x800, {(partnerLogoInfo.size / 1024).toFixed(1)} KB{partnerLogoInfo.warning ? ` - ${partnerLogoInfo.warning}` : ''}</Text> : null}
              <FormControl display="flex" alignItems="center" justifyContent="space-between">
                <FormLabel mb={0}>Visible on website</FormLabel>
                <Switch isChecked={Boolean(modalDraft.is_visible ?? true)} onChange={(e) => setModalDraft((current) => ({ ...current, is_visible: e.target.checked }))} />
              </FormControl>
            </Stack>
          )
        case 'event':
          return (
            <Stack spacing={4}>
              <SimpleGrid columns={{ base: 1, md: 2 }} spacing={4}>
                <FormControl isInvalid={Boolean(fieldError('title'))} gridColumn={{ base: 'auto', md: '1 / -1' }}>
                  <FormLabel>Title</FormLabel>
                  <Input value={readValue(modalDraft, 'title')} onChange={(e) => updateField('title', e.target.value)} />
                  <FormErrorMessage>{fieldError('title')}</FormErrorMessage>
                </FormControl>
                <FormControl isInvalid={Boolean(fieldError('date'))}>
                  <FormLabel>Date</FormLabel>
                  <Input type="date" value={readValue(modalDraft, 'date')} onChange={(e) => updateField('date', e.target.value)} />
                  <FormErrorMessage>{fieldError('date')}</FormErrorMessage>
                </FormControl>
                <FormControl isInvalid={Boolean(fieldError('location'))}>
                  <FormLabel>Location</FormLabel>
                  <Input maxLength={120} value={readValue(modalDraft, 'location')} onChange={(e) => updateField('location', e.target.value)} />
                  <FormErrorMessage>{fieldError('location')}</FormErrorMessage>
                </FormControl>
                <FormControl display="flex" alignItems="center" gap={3} pt={8}>
                  <Switch isChecked={Boolean(modalDraft.is_visible ?? true)} onChange={(e) => setModalDraft((current) => ({ ...current, is_visible: e.target.checked }))} />
                  <FormLabel mb={0}>Visible on website</FormLabel>
                </FormControl>
                <FormControl isInvalid={Boolean(fieldError('sort_order'))}>
                  <FormLabel>Sort order</FormLabel>
                  <Input type="number" value={readValue(modalDraft, 'sort_order')} onChange={(e) => updateField('sort_order', e.target.value)} />
                  <FormErrorMessage>{fieldError('sort_order')}</FormErrorMessage>
                </FormControl>
              </SimpleGrid>
              <FormControl isInvalid={Boolean(fieldError('description'))}>
                <FormLabel>Description</FormLabel>
                <Textarea maxLength={400} value={readValue(modalDraft, 'description')} onChange={(e) => updateField('description', e.target.value)} />
                <Text fontSize="sm" color="gray.500" textAlign="right">{readValue(modalDraft, 'description').length}/400</Text>
                <FormErrorMessage>{fieldError('description')}</FormErrorMessage>
              </FormControl>
              <ImageUrlField
                label="Image upload"
                value={getImageValue()}
                onChange={(value) => updateField('imageUrl', value)}
                allowUpload
                isUploading={isImageUploading}
                error={fieldError('image')}
                onFileChange={handleImageUpload}
                entityType="event"
              />
            </Stack>
          )
        case 'staff':
          return (
            <Stack spacing={4}>
              <SimpleGrid columns={{ base: 1, md: 2 }} spacing={4}>
                <FormControl isInvalid={Boolean(fieldError('name'))}>
                  <FormLabel>Name</FormLabel>
                  <Input maxLength={120} value={readValue(modalDraft, 'name')} onChange={(e) => updateField('name', e.target.value)} />
                  <FormErrorMessage>{fieldError('name')}</FormErrorMessage>
                </FormControl>
                <FormControl isInvalid={Boolean(fieldError('role'))}>
                  <FormLabel>Role</FormLabel>
                  <Input maxLength={80} value={readValue(modalDraft, 'role')} onChange={(e) => updateField('role', e.target.value)} />
                  <FormErrorMessage>{fieldError('role')}</FormErrorMessage>
                </FormControl>
                <FormControl display="flex" alignItems="center" gap={3} pt={8}>
                  <Switch isChecked={Boolean(modalDraft.is_visible ?? true)} onChange={(e) => setModalDraft((current) => ({ ...current, is_visible: e.target.checked }))} />
                  <FormLabel mb={0}>Visible on website</FormLabel>
                </FormControl>
                <FormControl isInvalid={Boolean(fieldError('sort_order'))}>
                  <FormLabel>Sort order</FormLabel>
                  <Input type="number" value={readValue(modalDraft, 'sort_order')} onChange={(e) => updateField('sort_order', e.target.value)} />
                  <FormErrorMessage>{fieldError('sort_order')}</FormErrorMessage>
                </FormControl>
              </SimpleGrid>
              <FormControl isInvalid={Boolean(fieldError('bio'))}>
                <FormLabel>Bio</FormLabel>
                <Textarea maxLength={400} value={readValue(modalDraft, 'bio')} onChange={(e) => updateField('bio', e.target.value)} />
                <Text fontSize="sm" color="gray.500" textAlign="right">{readValue(modalDraft, 'bio').length}/400</Text>
                <FormErrorMessage>{fieldError('bio')}</FormErrorMessage>
              </FormControl>
              <ImageUrlField
                label="Image upload"
                value={getImageValue()}
                onChange={(value) => updateField('imageUrl', value)}
                allowUpload
                isUploading={isImageUploading}
                error={fieldError('image')}
                onFileChange={handleImageUpload}
                entityType="staff"
              />
            </Stack>
          )
        case 'timeline':
          return (
            <Stack spacing={4}>
              <SimpleGrid columns={{ base: 1, sm: 2 }} spacing={4}>
                <FormControl isInvalid={Boolean(fieldError('year'))} isRequired>
                  <FormLabel>Year</FormLabel>
                  <Input type="number" min={1990} max={new Date().getFullYear() + 1} value={readValue(modalDraft, 'year')} onChange={(e) => updateField('year', e.target.value)} />
                  <FormErrorMessage>{fieldError('year')}</FormErrorMessage>
                </FormControl>
                <FormControl>
                  <FormLabel>Month</FormLabel>
                  <Select value={readValue(modalDraft, 'month')} onChange={(e) => updateField('month', e.target.value)}>
                    <option value="">None</option>
                    {['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'].map((month, index) => <option key={month} value={index + 1}>{month}</option>)}
                  </Select>
                </FormControl>
              </SimpleGrid>
              <FormControl isInvalid={Boolean(fieldError('title'))} isRequired>
                <FormLabel>Title</FormLabel>
                <Input maxLength={80} value={readValue(modalDraft, 'title')} onChange={(e) => updateField('title', e.target.value)} />
                <Text fontSize="xs" color={modalMuted} textAlign="right">{readValue(modalDraft, 'title').length}/80</Text>
                <FormErrorMessage>{fieldError('title')}</FormErrorMessage>
              </FormControl>
              <FormControl isInvalid={Boolean(fieldError('description'))}>
                <FormLabel>Description</FormLabel>
                <Textarea maxLength={300} value={readValue(modalDraft, 'description')} onChange={(e) => updateField('description', e.target.value)} />
                <Text fontSize="xs" color={modalMuted} textAlign="right">{readValue(modalDraft, 'description').length}/300</Text>
                <FormErrorMessage>{fieldError('description')}</FormErrorMessage>
              </FormControl>
              <FormControl display="flex" alignItems="center" justifyContent="space-between">
                <FormLabel mb={0}>Visible on website</FormLabel>
                <Switch isChecked={readValue(modalDraft, 'is_visible') === true || readValue(modalDraft, 'is_visible') === 'true'} onChange={(e) => updateField('is_visible', String(e.target.checked))} />
              </FormControl>
            </Stack>
          )
        default:
          return null
      }
    }

    const imageValue = getImageValue()

    return (
      <Box display="grid" gridTemplateColumns={{ base: '1fr', lg: 'minmax(220px, 280px) minmax(0, 1fr)' }} gap={6} alignItems="start">
        <Box borderRadius="xl" border="1px solid" borderColor={modalBorder} bg={modalSoftBg} p={4}>
          <Text fontSize="xs" letterSpacing="wide" textTransform="uppercase" color={modalMuted} fontWeight="bold">Preview</Text>
          <Box mt={3} borderRadius="xl" border="1px solid" borderColor={modalBorder} bg={modalSurface} overflow="hidden" minH="180px" display="flex" alignItems="center" justifyContent="center">
            {imageValue ? (
              <Box width="220px" maxW="100%" aspectRatio={modalState.kind === 'partner' ? '3 / 2' : undefined} display="flex" alignItems="center" justifyContent="center" bg={modalState.kind === 'partner' ? 'var(--surface-2)' : undefined}><Image src={imageValue} alt={`${previewTitle} preview`} objectFit={modalState.kind === 'partner' ? 'contain' : 'cover'} maxW={modalState.kind === 'partner' ? '70%' : '100%'} maxH={modalState.kind === 'partner' ? '60%' : '220px'} w={modalState.kind === 'partner' ? '160px' : '100%'} h={modalState.kind === 'partner' ? '96px' : '220px'} /></Box>
            ) : (
              <Text color={modalMuted} fontWeight="medium" px={4} textAlign="center">{previewTitle}</Text>
            )}
          </Box>
          <Text mt={3} fontSize="xs" color={modalMuted}>
            {modalState.kind === 'player' ? 'Player avatar' : modalState.kind === 'staff' ? 'Staff portrait' : 'Media image'}
          </Text>
        </Box>

        <Box>{renderFieldSet()}</Box>
      </Box>
    )
  }

  const renderEntryDetails = (kind: EntryKind, item: Record<string, any>) => {
    const detailMap = {
      player: [
        ['Name', item.full_name || `${item.first_name ?? ''} ${item.last_name ?? ''}`.trim()],
        ['Email', item.email],
        ['Game', item.main_game],
        ['Department', item.department],
        ['IGN', item.in_game_name],
        ['UID', item.uid],
        ['Status', item.status],
      ],
      update: [
        ['Title', item.title],
        ['Tag', item.tag],
        ['Detail', item.detail],
      ],
      game: [
        ['Title', item.title],
        ['Genre', item.genre],
        ['Status', item.status],
        ['Description', item.description],
      ],
      partner: [
        ['Name', item.name],
        ['Category', item.category],
        ['Website', item.website ?? item.website_url],
        ['Description', item.description],
      ],
      event: [
        ['Title', item.title],
        ['Date', item.date],
        ['Location', item.location],
        ['Description', item.description],
      ],
      timeline: [
        ['Year', item.year],
        ['Month', item.month ? new Date(2000, item.month - 1).toLocaleString('en', { month: 'long' }) : 'None'],
        ['Title', item.title],
        ['Description', item.description || 'No description provided.'],
        ['Visible', item.is_visible ? 'Yes' : 'No'],
      ],
      staff: [
        ['Name', item.name],
        ['Role', item.role],
        ['Bio', item.bio],
      ],
    } as const

    const summaryTitle = item.full_name || item.name || item.title || item.category || 'Entry'
    const summaryText = kind === 'player'
      ? item.department || item.main_game || 'Player'
      : kind === 'staff'
        ? item.role || 'Staff member'
        : kind === 'partner'
          ? item.category || 'Partner'
          : kind === 'event'
            ? item.date || 'Event'
            : kind === 'game'
              ? item.genre || 'Game'
              : item.tag || 'Update'

    return (
      <Box display="grid" gridTemplateColumns={{ base: '1fr', md: 'minmax(180px, 220px) minmax(0, 1fr)' }} gap={4} alignItems="start">
        <Box borderRadius="xl" border="1px solid" borderColor={modalBorder} bg={modalSoftBg} p={4}>
          <Text fontSize="xs" letterSpacing="wide" textTransform="uppercase" color={modalMuted} fontWeight="bold">Summary</Text>
          <Text fontSize="lg" fontWeight="bold" mt={3}>{summaryTitle}</Text>
          <Text color={modalMuted} mt={2}>{summaryText}</Text>
        </Box>

        <Box borderRadius="xl" border="1px solid" borderColor={modalBorder} bg={modalSurface} p={4}>
          <Stack spacing={3}>
            {detailMap[kind].map(([label, value]) => (
              <Box key={label} display="grid" gridTemplateColumns={{ base: '1fr', sm: '130px minmax(0, 1fr)' }} gap={{ base: 1, sm: 4 }} alignItems="start">
                <Text fontWeight="bold" color={modalMuted}>{label}:</Text>
                <Text whiteSpace="pre-wrap">{String(value ?? '—')}</Text>
              </Box>
            ))}
          </Stack>
        </Box>
      </Box>
    )
  }

  const renderPlayersTable = () => (
    <TableContainer border="1px solid" borderColor="gray.200" borderRadius="xl" bg="white">
      <Table variant="simple">
        <Thead bg="gray.50">
          <Tr>
            <Th>Player</Th>
            <Th>Game</Th>
            <Th>Department</Th>
            <Th>IGN / UID</Th>
            <Th>Status</Th>
            <Th>Date</Th>
            <Th>Actions</Th>
          </Tr>
        </Thead>
        <Tbody>
          {playerRows.map((player) => (
            <Tr key={player.id} onClick={() => openModal('player', { ...player, photoUrl: player.photo_path ? playerPhotoUrls[player.photo_path] : '' }, 'view')} _hover={{ bg: 'gray.50' }} cursor="pointer">
              <Td>
                <Flex align="center" gap={3}>
                  {player.photo_path && playerPhotoUrls[player.photo_path] ? <Image src={playerPhotoUrls[player.photo_path]} alt={`${player.full_name || 'Player'} photo`} boxSize="36px" borderRadius="full" objectFit="cover" /> : <Box borderRadius="full" bg="brand.50" color="brand.500" px={2} py={1} fontSize="xs" fontWeight="bold">{playerInitials(player)}</Box>}
                  <Box>
                    <Text fontWeight="bold">{player.full_name || `${player.first_name} ${player.last_name}`}</Text>
                    <Text fontSize="sm" color="gray.500">{player.email}</Text>
                    {!player.photo_path && player.photo_drive_url ? <Text as="a" href={player.photo_drive_url} target="_blank" rel="noreferrer" fontSize="xs" color="brand.500" onClick={(event) => event.stopPropagation()}>Open legacy photo</Text> : null}
                  </Box>
                </Flex>
              </Td>
              <Td>{player.main_game}</Td>
              <Td><Badge colorScheme={player.department === 'Community' ? 'purple' : 'blue'}>{player.department || '—'}</Badge></Td>
              <Td>{player.in_game_name || '—'} / {player.uid || '—'}</Td>
              <Td><Badge colorScheme={player.status === 'approved' ? 'green' : player.status === 'rejected' ? 'red' : 'yellow'}>{player.status}</Badge></Td>
              <Td>{new Date(player.created_at).toLocaleDateString()}</Td>
              <Td>
                <HStack spacing={2} onClick={(event) => event.stopPropagation()}>
                  <ActionIconButton label="Edit player" icon={<EditActionIcon />} onClick={() => openModal('player', player, 'edit')} />
                  <ActionIconButton label="Approve player" colorScheme="green" icon={<ApproveActionIcon />} onClick={() => handlePlayerApprove(player.id, 'approve')} />
                  <ActionIconButton label="Reject player" colorScheme="red" icon={<RejectActionIcon />} onClick={() => handlePlayerApprove(player.id, 'reject')} />
                  <ActionIconButton label="Delete player" colorScheme="gray" variant="ghost" icon={<DeleteActionIcon />} onClick={() => handleDeleteEntry('player', player.id)} />
                </HStack>
              </Td>
            </Tr>
          ))}
        </Tbody>
      </Table>
    </TableContainer>
  )

  const renderPlayersCards = () => (
    <SimpleGrid columns={{ base: 1, md: 2, xl: 3 }} spacing={4}>
      {playerRows.map((player) => (
        <Card key={player.id} borderRadius="xl" border="1px solid" borderColor="gray.200" onClick={() => openModal('player', { ...player, photoUrl: player.photo_path ? playerPhotoUrls[player.photo_path] : '' }, 'view')} _hover={{ boxShadow: 'md' }} cursor="pointer">
          <CardBody>
            <Flex align="center" justify="space-between" mb={4}>
              {player.photo_path && playerPhotoUrls[player.photo_path] ? <Image src={playerPhotoUrls[player.photo_path]} alt={`${player.full_name || 'Player'} photo`} boxSize="48px" borderRadius="full" objectFit="cover" /> : <Box borderRadius="full" bg="brand.50" color="brand.500" px={3} py={2} fontWeight="bold">{playerInitials(player)}</Box>}
              <Badge colorScheme={player.status === 'approved' ? 'green' : player.status === 'rejected' ? 'red' : 'yellow'}>{player.status}</Badge>
            </Flex>
            <Text fontWeight="bold" fontSize="lg">{player.full_name || `${player.first_name} ${player.last_name}`}</Text>
            <Text color="gray.500">{player.main_game} · <Badge colorScheme={player.department === 'Community' ? 'purple' : 'blue'}>{player.department || '—'}</Badge></Text>
            <Text my={2} fontSize="sm">{player.in_game_name || '—'} · {player.uid || '—'}</Text>
            <Text my={2} fontSize="sm">{player.email}</Text>
            <Text fontSize="sm" color="gray.500">Applied: {new Date(player.created_at).toLocaleDateString()}</Text>
            {!player.photo_path && player.photo_drive_url ? <Text as="a" href={player.photo_drive_url} target="_blank" rel="noreferrer" fontSize="sm" color="brand.500" onClick={(event) => event.stopPropagation()}>Open legacy photo</Text> : null}
            <Divider my={3} />
            <HStack spacing={2} flexWrap="wrap" onClick={(event) => event.stopPropagation()}>
              <ActionIconButton label="Edit player" icon={<EditActionIcon />} onClick={() => openModal('player', player, 'edit')} />
              <ActionIconButton label="Approve player" colorScheme="green" icon={<ApproveActionIcon />} onClick={() => handlePlayerApprove(player.id, 'approve')} />
              <ActionIconButton label="Reject player" colorScheme="red" icon={<RejectActionIcon />} onClick={() => handlePlayerApprove(player.id, 'reject')} />
              <ActionIconButton label="Delete player" icon={<DeleteActionIcon />} onClick={() => handleDeleteEntry('player', player.id)} />
            </HStack>
          </CardBody>
        </Card>
      ))}
    </SimpleGrid>
  )

  const renderLatestUpdateTable = () => (
    <TableContainer border="1px solid" borderColor="gray.200" borderRadius="xl" bg="white">
      <Table variant="simple">
        <Thead bg="gray.50"><Tr><Th>Title</Th><Th>Tag</Th><Th>Summary</Th><Th>Visible</Th><Th>Actions</Th></Tr></Thead>
        <Tbody>
          {adminLatestUpdates.map((item) => (
            <Tr key={item.id} onClick={() => openModal('update', item, 'view')} _hover={{ bg: 'gray.50' }} cursor="pointer">
              <Td>{item.title}</Td>
              <Td>{item.tag ?? '—'}</Td>
              <Td>{item.description ?? '—'}</Td>
              <Td><Switch isChecked={item.is_visible} onChange={async () => { if (!supabase) return; const { error } = await supabase.from('latest_updates').update({ is_visible: !item.is_visible }).eq('id', item.id); if (error) toast({ title: 'Unable to update visibility', description: mapLatestUpdateError(error), status: 'error', isClosable: true }); else { await loadAdminLatestUpdates(); window.dispatchEvent(new Event('latest-updates-updated')) } }} aria-label={`Toggle ${item.title} visibility`} /></Td>
              <Td>
                <HStack onClick={(event) => event.stopPropagation()}>
                  <ActionIconButton label="Edit update" icon={<EditActionIcon />} onClick={() => openModal('update', item, 'edit')} />
                  <ActionIconButton label="Delete update" icon={<DeleteActionIcon />} onClick={() => handleDeleteEntry('update', item.id)} />
                </HStack>
              </Td>
            </Tr>
          ))}
        </Tbody>
      </Table>
    </TableContainer>
  )

  const renderLatestUpdateCards = () => (
    <SimpleGrid columns={{ base: 1, md: 2, xl: 3 }} spacing={4}>
      {adminLatestUpdates.map((item) => (
        <Card key={item.id} borderRadius="xl" border="1px solid" borderColor="gray.200" onClick={() => openModal('update', item, 'view')} _hover={{ boxShadow: 'md' }} cursor="pointer">
          <CardBody>
            <Text fontWeight="bold" fontSize="lg">{item.title}</Text>
            <Badge colorScheme="blue" mt={2}>{item.tag}</Badge>
            <Text mt={3}>{item.description ?? '—'}</Text>
            <Divider my={3} />
            <HStack onClick={(event) => event.stopPropagation()}>
              <ActionIconButton label="Edit update" icon={<EditActionIcon />} onClick={() => openModal('update', item, 'edit')} />
              <ActionIconButton label="Delete update" icon={<DeleteActionIcon />} onClick={() => handleDeleteEntry('update', item.id)} />
            </HStack>
          </CardBody>
        </Card>
      ))}
    </SimpleGrid>
  )

  const renderGameTable = () => (
    gamesLoading ? <Stack spacing={3}>{[1, 2, 3].map((item) => <Box key={item} h="56px" bg={modalSoftBg} borderRadius="md" />)}</Stack> : adminGames.length === 0 ? <Box border="1px dashed" borderColor="gray.300" borderRadius="xl" p={8} textAlign="center"><Text fontWeight="bold">No games yet</Text><Button mt={3} className="btn-primary" onClick={() => openModal('game', null, 'add')}>Add Game</Button></Box> : <TableContainer border="1px solid" borderColor="gray.200" borderRadius="xl" bg="white">
      <Table variant="simple">
        <Thead bg="gray.50"><Tr><Th>Logo</Th><Th>Name</Th><Th>Genre</Th><Th>Visible</Th><Th>Order</Th><Th>Actions</Th></Tr></Thead>
        <Tbody>
          {adminGames.map((item, index) => (
            <Tr key={item.id} onClick={() => openModal('game', item, 'view')} _hover={{ bg: 'gray.50' }} cursor="pointer">
              <Td><Image src={item.image_url || undefined} alt={`${item.title} logo`} width="48px" height="32px" objectFit="contain" fallback={<Box width="48px" height="32px" display="grid" placeItems="center" color="gray.500" fontWeight="bold">{item.title.slice(0, 2).toUpperCase()}</Box>} />{!item.image_url ? <Badge mt={1} colorScheme="orange">No logo</Badge> : null}{item.image_url && !/\/games\/[^/]+\.(webp|png)(?:\?|$)/i.test(item.image_url) ? <Text fontSize="xs" color="gray.500">Re-upload to make square</Text> : null}</Td>
              <Td>{item.title}</Td>
              <Td>{item.tag || '—'}</Td>
              <Td><Switch isChecked={item.is_visible} onChange={async () => { if (!supabase) return; const { error } = await supabase.from('games').update({ is_visible: !item.is_visible }).eq('id', item.id); if (error) { console.error('Game visibility update failed:', error); toast({ title: 'Unable to update visibility', description: error.message, status: 'error', isClosable: true }) } else { await loadAdminGames(); window.dispatchEvent(new Event('games-updated')) } }} aria-label={`Toggle ${item.title} visibility`} /></Td>
              <Td><HStack><ActionIconButton label="Move game up" icon={<ChevronUpIcon />} onClick={() => void moveGame(item, 'up')} isDisabled={index === 0} /><ActionIconButton label="Move game down" icon={<ChevronDownIcon />} onClick={() => void moveGame(item, 'down')} isDisabled={index === adminGames.length - 1} /></HStack></Td>
              <Td>
                <HStack onClick={(event) => event.stopPropagation()}>
                  <ActionIconButton label="Edit game" icon={<EditActionIcon />} onClick={() => openModal('game', item, 'edit')} />
                  <ActionIconButton label="Delete game" icon={<DeleteActionIcon />} onClick={() => handleDeleteEntry('game', item.id)} />
                </HStack>
              </Td>
            </Tr>
          ))}
        </Tbody>
      </Table>
    </TableContainer>
  )

  const renderGameCards = () => (
    <SimpleGrid columns={{ base: 1, md: 2, xl: 3 }} spacing={4}>
      {adminGames.map((item) => (
        <Card key={item.id} borderRadius="xl" border="1px solid" borderColor="gray.200" onClick={() => openModal('game', item, 'view')} _hover={{ boxShadow: 'md' }} cursor="pointer">
          <CardBody>
            <Image src={item.image_url || undefined} alt={`${item.title} logo`} width="48px" height="32px" objectFit="contain" fallback={<Box width="48px" height="32px" display="grid" placeItems="center" color="gray.500" fontWeight="bold">{item.title.slice(0, 2).toUpperCase()}</Box>} />
            {!item.image_url ? <Badge mt={1} colorScheme="orange">No logo</Badge> : null}
            <Text fontWeight="bold" fontSize="lg">{item.title}</Text>
            <Text color="gray.500">{item.tag}</Text>
            <Badge mt={2} colorScheme={item.is_visible ? 'green' : 'gray'}>{item.is_visible ? 'Visible' : 'Hidden'}</Badge>
            <Text mt={3}>{item.description || '—'}</Text>
            <Divider my={3} />
            <HStack onClick={(event) => event.stopPropagation()}>
              <ActionIconButton label="Edit game" icon={<EditActionIcon />} onClick={() => openModal('game', item, 'edit')} />
              <ActionIconButton label="Delete game" icon={<DeleteActionIcon />} onClick={() => handleDeleteEntry('game', item.id)} />
            </HStack>
          </CardBody>
        </Card>
      ))}
    </SimpleGrid>
  )

  const renderPartnerTable = () => (
    <TableContainer border="1px solid" borderColor="gray.200" borderRadius="xl" bg="white">
      <Table variant="simple">
        <Thead bg="gray.50"><Tr><Th>Logo</Th><Th>Name</Th><Th>Category</Th><Th>Website</Th><Th>Visible</Th><Th>Order</Th><Th>Actions</Th></Tr></Thead>
        <Tbody>
          {partners.map((item, index) => (
            <Tr key={item.id} onClick={() => openModal('partner', item, 'view')} _hover={{ bg: 'gray.50' }} cursor="pointer">
              <Td><Image src={item.logo_url || undefined} alt={`${item.name} logo`} width="48px" height="32px" objectFit="contain" fallback={<Box width="48px" height="32px" display="grid" placeItems="center" color="gray.500" fontWeight="bold">{item.name.slice(0, 2).toUpperCase()}</Box>} />{!item.logo_url ? <Badge mt={1} colorScheme="orange">No logo</Badge> : null}{item.logo_url && !/\/partners\/[^/]+\.(webp|png)(?:\?|$)/i.test(item.logo_url) ? <Text fontSize="xs" color="gray.500">Re-upload to make square</Text> : null}</Td>
              <Td>{item.name}</Td>
              <Td>{item.category}</Td>
              <Td>{item.website_url ? <Link href={item.website_url} isExternal rel="noopener noreferrer" onClick={(event) => event.stopPropagation()}>{item.website_url}</Link> : '—'}</Td>
              <Td><Switch isChecked={item.is_visible} onChange={() => void updatePartnerVisibility(item)} aria-label={`Toggle ${item.name} visibility`} /></Td>
              <Td><HStack><ActionIconButton label="Move partner up" icon={<ChevronUpIcon />} onClick={() => void movePartner(item, 'up')} isDisabled={index === 0} /><ActionIconButton label="Move partner down" icon={<ChevronDownIcon />} onClick={() => void movePartner(item, 'down')} isDisabled={index === partners.length - 1} /></HStack></Td>
              <Td>
                <HStack onClick={(event) => event.stopPropagation()}>
                  <ActionIconButton label="Edit partner" icon={<EditActionIcon />} onClick={() => openModal('partner', item, 'edit')} />
                  <ActionIconButton label="Delete partner" icon={<DeleteActionIcon />} onClick={() => handleDeleteEntry('partner', item.id)} />
                </HStack>
              </Td>
            </Tr>
          ))}
        </Tbody>
      </Table>
    </TableContainer>
  )

  const renderPartnerCards = () => (
    <SimpleGrid columns={{ base: 1, md: 2, xl: 3 }} spacing={4}>
      {partners.map((item) => (
        <Card key={item.id} borderRadius="xl" border="1px solid" borderColor="gray.200" onClick={() => openModal('partner', item, 'view')} _hover={{ boxShadow: 'md' }} cursor="pointer">
          <CardBody>
            <Image src={item.logo_url || undefined} alt={`${item.name} logo`} width="48px" height="32px" objectFit="contain" fallback={<Box width="48px" height="32px" display="grid" placeItems="center" color="gray.500" fontWeight="bold">{item.name.slice(0, 2).toUpperCase()}</Box>} />
            {!item.logo_url ? <Badge mt={1} colorScheme="orange">No logo</Badge> : null}
            <Text fontWeight="bold" fontSize="lg">{item.name}</Text>
            <Text color="gray.500">{item.category}</Text>
            <Badge mt={2} colorScheme={item.is_visible ? 'green' : 'gray'}>{item.is_visible ? 'Visible' : 'Hidden'}</Badge>
            <Text mt={3}>{item.description}</Text>
            {item.website_url ? <Link mt={2} fontSize="sm" color="brand.500" href={item.website_url} isExternal rel="noopener noreferrer">{item.website_url}</Link> : <Text mt={2} fontSize="sm">No website</Text>}
            <Divider my={3} />
            <HStack onClick={(event) => event.stopPropagation()}>
              <ActionIconButton label="Edit partner" icon={<EditActionIcon />} onClick={() => openModal('partner', item, 'edit')} />
              <ActionIconButton label="Delete partner" icon={<DeleteActionIcon />} onClick={() => handleDeleteEntry('partner', item.id)} />
            </HStack>
          </CardBody>
        </Card>
      ))}
    </SimpleGrid>
  )

  const updatePartnerVisibility = async (item: SupabasePartner) => {
    if (!supabase) return
    const { error } = await supabase.from('partners').update({ is_visible: !item.is_visible }).eq('id', item.id)
    if (error) { console.error('Partner visibility update failed:', error); toast({ title: 'Unable to update visibility', description: mapSupabaseError(error), status: 'error', isClosable: true }); return }
    await refreshPartners()
    window.dispatchEvent(new Event(PARTNERS_UPDATED_EVENT))
  }

  const movePartner = async (item: SupabasePartner, direction: 'up' | 'down') => {
    if (!supabase) return
    const index = partners.findIndex((partner) => partner.id === item.id)
    const neighbor = partners[index + (direction === 'up' ? -1 : 1)]
    if (!neighbor) return
    const first = await supabase.from('partners').update({ sort_order: neighbor.sort_order }).eq('id', item.id)
    const second = await supabase.from('partners').update({ sort_order: item.sort_order }).eq('id', neighbor.id)
    if (first.error || second.error) { const error = first.error || second.error; console.error('Partner reorder failed:', error); toast({ title: 'Unable to reorder partners', description: mapSupabaseError(error ?? {}), status: 'error', isClosable: true }); return }
    await refreshPartners()
    window.dispatchEvent(new Event(PARTNERS_UPDATED_EVENT))
  }

  const renderEventTable = () => (
    <TableContainer border="1px solid" borderColor="gray.200" borderRadius="xl" bg="white">
      <Table variant="simple">
        <Thead bg="gray.50"><Tr><Th>Title</Th><Th>Date</Th><Th>Location</Th><Th>Visible</Th><Th>Actions</Th></Tr></Thead>
        <Tbody>
          {adminEvents.map((item) => (
            <Tr key={item.id} onClick={() => openModal('event', item, 'view')} _hover={{ bg: 'gray.50' }} cursor="pointer">
              <Td>{item.title}</Td>
              <Td>{item.event_date}</Td>
              <Td>{item.location ?? '—'}</Td>
              <Td><Switch isChecked={item.is_visible} onChange={async () => { if (!supabase) return; const { error } = await supabase.from('events').update({ is_visible: !item.is_visible }).eq('id', item.id); if (error) toast({ title: 'Unable to update visibility', description: mapSupabaseError(error), status: 'error', isClosable: true }); else { await loadAdminEvents(); window.dispatchEvent(new Event('events-updated')) } }} aria-label={`Toggle ${item.title} visibility`} /></Td>
              <Td>
                <HStack onClick={(event) => event.stopPropagation()}>
                  <ActionIconButton label="Edit event" icon={<EditActionIcon />} onClick={() => openModal('event', item, 'edit')} />
                  <ActionIconButton label="Delete event" icon={<DeleteActionIcon />} onClick={() => handleDeleteEntry('event', item.id)} />
                </HStack>
              </Td>
            </Tr>
          ))}
        </Tbody>
      </Table>
    </TableContainer>
  )

  const renderEventCards = () => (
    <SimpleGrid columns={{ base: 1, md: 2, xl: 3 }} spacing={4}>
      {adminEvents.map((item) => (
        <Card key={item.id} borderRadius="xl" border="1px solid" borderColor="gray.200" onClick={() => openModal('event', item, 'view')} _hover={{ boxShadow: 'md' }} cursor="pointer">
          <CardBody>
            <Text fontWeight="bold" fontSize="lg">{item.title}</Text>
            <Text color="gray.500">{item.event_date} • {item.location ?? 'Location to be announced'}</Text>
            <Text mt={3}>{item.description ?? '—'}</Text>
            <Divider my={3} />
            <HStack onClick={(event) => event.stopPropagation()}>
              <ActionIconButton label="Edit event" icon={<EditActionIcon />} onClick={() => openModal('event', item, 'edit')} />
              <ActionIconButton label="Delete event" icon={<DeleteActionIcon />} onClick={() => handleDeleteEntry('event', item.id)} />
            </HStack>
          </CardBody>
        </Card>
      ))}
    </SimpleGrid>
  )

  const updateTimelineVisibility = async (item: TimelineEvent) => {
    if (!supabase) return
    const nextVisible = !item.is_visible
    const { error } = await supabase.from('timeline_events').update({ is_visible: nextVisible }).eq('id', item.id)
    if (error) {
      console.error('Timeline visibility update failed:', error)
      toast({ title: 'Unable to update visibility', description: error.message, status: 'error', isClosable: true })
      return
    }
    setTimelineEvents((current) => current.map((event) => event.id === item.id ? { ...event, is_visible: nextVisible } : event))
  }

  const renderTimelineTable = () => {
    if (timelineLoading) return <Stack spacing={3}>{[1, 2, 3].map((item) => <Box key={item} h="56px" bg={modalSoftBg} borderRadius="md" />)}</Stack>
    if (timelineError) return <Text color={modalMuted}>{timelineError}</Text>
    if (timelineEvents.length === 0) return <Box border="1px dashed" borderColor="gray.300" borderRadius="xl" p={8} textAlign="center"><Text fontWeight="bold">No milestones yet</Text><Button className="btn-primary" mt={3} onClick={() => openModal('timeline', null, 'add')}>Add Milestone</Button></Box>
    return <TableContainer border="1px solid" borderColor="gray.200" borderRadius="xl" bg="white"><Table variant="simple"><Thead bg="gray.50"><Tr><Th>Year</Th><Th>Month</Th><Th>Title</Th><Th>Description</Th><Th>Visible</Th><Th>Actions</Th></Tr></Thead><Tbody>{timelineEvents.map((item) => <Tr key={item.id}><Td>{item.year}</Td><Td>{item.month ? new Date(2000, item.month - 1).toLocaleString('en', { month: 'short' }) : '—'}</Td><Td fontWeight="bold">{item.title}</Td><Td maxW="280px" isTruncated>{item.description || '—'}</Td><Td><HStack><Badge colorScheme={item.is_visible ? 'green' : 'gray'}>{item.is_visible ? 'Visible' : 'Hidden'}</Badge><Switch isChecked={item.is_visible} onChange={() => void updateTimelineVisibility(item)} aria-label={`Toggle ${item.title} visibility`} /></HStack></Td><Td><HStack><ActionIconButton label="Edit milestone" icon={<EditActionIcon />} onClick={() => openModal('timeline', item, 'edit')} /><ActionIconButton label="Delete milestone" icon={<DeleteActionIcon />} onClick={() => handleDeleteEntry('timeline', item.id)} /></HStack></Td></Tr>)}</Tbody></Table></TableContainer>
  }

  const renderStaffTable = () => (
    <TableContainer border="1px solid" borderColor="gray.200" borderRadius="xl" bg="white">
      <Table variant="simple">
        <Thead bg="gray.50"><Tr><Th>Name</Th><Th>Role</Th><Th>Bio</Th><Th>Visible</Th><Th>Actions</Th></Tr></Thead>
        <Tbody>
          {adminStaff.map((item) => (
            <Tr key={item.id} onClick={() => openModal('staff', item, 'view')} _hover={{ bg: 'gray.50' }} cursor="pointer">
              <Td>{item.full_name}</Td>
              <Td>{item.role_title ?? '—'}</Td>
              <Td>{item.bio ?? '—'}</Td>
              <Td><Switch isChecked={item.is_visible} onChange={async () => { if (!supabase) return; const { error } = await supabase.from('staff').update({ is_visible: !item.is_visible }).eq('id', item.id); if (error) toast({ title: 'Unable to update visibility', description: mapSupabaseError(error), status: 'error', isClosable: true }); else await loadAdminStaff() }} aria-label={`Toggle ${item.full_name} visibility`} /></Td>
              <Td>
                <HStack onClick={(event) => event.stopPropagation()}>
                  <ActionIconButton label="Edit staff" icon={<EditActionIcon />} onClick={() => openModal('staff', item, 'edit')} />
                  <ActionIconButton label="Delete staff" icon={<DeleteActionIcon />} onClick={() => handleDeleteEntry('staff', item.id)} />
                </HStack>
              </Td>
            </Tr>
          ))}
        </Tbody>
      </Table>
    </TableContainer>
  )

  const renderStaffCards = () => (
    <SimpleGrid columns={{ base: 1, md: 2, xl: 3 }} spacing={4}>
      {adminStaff.map((item) => (
        <Card key={item.id} borderRadius="xl" border="1px solid" borderColor="gray.200" onClick={() => openModal('staff', item, 'view')} _hover={{ boxShadow: 'md' }} cursor="pointer">
          <CardBody>
            <Text fontWeight="bold" fontSize="lg">{item.full_name}</Text>
            <Text color="gray.500">{item.role_title ?? '—'}</Text>
            <Text mt={3}>{item.bio ?? '—'}</Text>
            <Divider my={3} />
            <HStack onClick={(event) => event.stopPropagation()}>
              <ActionIconButton label="Edit staff" icon={<EditActionIcon />} onClick={() => openModal('staff', item, 'edit')} />
              <ActionIconButton label="Delete staff" icon={<DeleteActionIcon />} onClick={() => handleDeleteEntry('staff', item.id)} />
            </HStack>
          </CardBody>
        </Card>
      ))}
    </SimpleGrid>
  )

  if (!isAuthenticated) {
    return (
      <Container className="shared-container" maxW="none" px={0} py={12}>
        <Box maxW="lg" mx="auto" bg="white" borderRadius="2xl" border="1px solid" borderColor="gray.200" p={8}>
          <Stack spacing={5}>
            <Flex align="center" gap={3}>
              <Box bg="brand.50" p={3} borderRadius="xl"><LockIcon color="brand.500" /></Box>
              <Heading as="h2" size="lg">Admin access</Heading>
            </Flex>
            <form onSubmit={async (event) => {
              event.preventDefault()
              const result = await signInWithEmail(email, password)
              if (result.success) {
                login();
                toast({ title: 'Admin access granted', description: result.message, status: 'success', isClosable: true })
                return
              }
              toast({ title: 'Authentication failed', description: result.message, status: 'error', isClosable: true })
            }}>
              <Stack spacing={4}>
                <FormControl>
                  <FormLabel>Email</FormLabel>
                  <Input type="email" value={email} onChange={(event) => setEmail(event.target.value)} />
                </FormControl>
                <FormControl>
                  <FormLabel>Password</FormLabel>
                  <Input type="password" value={password} onChange={(event) => setPassword(event.target.value)} />
                </FormControl>
                <Button type="submit" className="btn-primary" colorScheme="brand" width="full">Sign In</Button>
              </Stack>
            </form>
          </Stack>
        </Box>
      </Container>
    )
  }

  return (
    <Container className="admin-shell shared-container" maxW="none" px={0} py={{ base: 8, xl: 12 }}>
      <Stack spacing={8}>
        <Flex direction={{ base: 'column', md: 'row' }} align={{ base: 'stretch', md: 'center' }} justify="space-between" gap={4}>
          <Box>
            <Text fontSize="sm" letterSpacing="2px" textTransform="uppercase" color="brand.500" fontWeight="bold">Admin dashboard</Text>
            <Heading as="h1" size="lg" mt={2}>Management Center</Heading>
          </Box>
          <Button variant="outline" onClick={logout}>Sign out</Button>
        </Flex>

        <Tabs index={tabOrder.indexOf(currentTab)} onChange={(index) => handleTabChange(tabOrder[index])} variant="soft-rounded" colorScheme="brand">
          <TabList flexWrap="wrap" gap={2}>
            <Tab>Players</Tab>
            <Tab>Latest Updates</Tab>
            <Tab>Games</Tab>
            <Tab>Partners</Tab>
            <Tab>Events</Tab>
            <Tab>Timeline</Tab>
            <Tab>Staffs</Tab>
          </TabList>

          <TabPanels mt={6}>
            <TabPanel p={0}>
              <Stack spacing={6}>
                {role !== 'admin' ? <Box border="1px dashed" borderColor="gray.300" borderRadius="xl" p={8} textAlign="center"><Text fontWeight="bold">Sign in as an admin to view players</Text></Box> : null}
                <Box className="admin-summary" bg={summarySurface} borderRadius="xl" border="1px solid" borderColor={summaryBorder} p={5}>
                  <Heading as="h3" size="md" mb={4} color="accent.500">Summary Findings</Heading>
                  <SimpleGrid columns={{ base: 1, md: 3 }} spacing={4}>
                    <Box bg={summaryTile} borderRadius="xl" p={5} textAlign="center"><Text fontSize="sm" color={summaryMuted}>Total players</Text><Heading as="h4" size="lg" mt={2} color={summaryText}>{playerCounts.total}</Heading></Box>
                    <Box bg={summaryTile} borderRadius="xl" p={5} textAlign="center"><Text fontSize="sm" color={summaryMuted}>Approved</Text><Heading as="h4" size="lg" mt={2} color={summaryText}>{playerCounts.approved}</Heading></Box>
                    <Box bg={summaryTile} borderRadius="xl" p={5} textAlign="center"><Text fontSize="sm" color={summaryMuted}>Pending</Text><Heading as="h4" size="lg" mt={2} color={summaryText}>{playerCounts.pending}</Heading></Box>
                  </SimpleGrid>
                </Box>

                <DashboardControls
                    searchTerm={searchTerm}
                    setSearchTerm={setSearchTerm}
                    departmentFilter={departmentFilter}
                    setDepartmentFilter={setDepartmentFilter}
                    statusFilter={statusFilter}
                    setStatusFilter={setStatusFilter}
                    gameFilter={playerGameFilter}
                    setGameFilter={setPlayerGameFilter}
                    datePreset={datePreset}
                    setDatePreset={setDatePreset}
                    fromDate={fromDate}
                    toDate={toDate}
                    onFromDateChange={setFromDate}
                    onToDateChange={setToDate}
                    onClear={handleClearFilters}
                    resultsCount={playerTotal}
                    hasInvalidDateRange={hasInvalidDateRange}
                />
                <Flex className="admin-player-toolbar" justify="flex-end" align="center" gap={3} direction={{ base: 'column', sm: 'row' }}>
                    <ViewToggle value={viewMode.players} onChange={(next) => setViewMode((current) => ({ ...current, players: next }))} />
                    <Button leftIcon={<AddIcon />} className="btn-primary" colorScheme="brand" onClick={() => openModal('player', null, 'add')}>Add Player</Button>
                </Flex>

                {playerLoading ? <Stack spacing={3}>{[1, 2, 3, 4, 5].map((item) => <Box key={item} h="64px" bg={modalSoftBg} borderRadius="md" />)}</Stack> : playerError ? <Box border="1px dashed" borderColor="red.300" borderRadius="xl" p={8} textAlign="center"><Text color="red.500">{playerError}</Text><Button mt={3} onClick={() => void loadPlayers()}>Retry</Button></Box> : playerRows.length === 0 ? (
                  <Box border="1px dashed" borderColor="gray.300" borderRadius="xl" p={8} textAlign="center">
                    <Text fontWeight="bold">No players found</Text>
                    <Button variant="link" colorScheme="brand" mt={2} onClick={handleClearFilters}>Clear filters</Button>
                  </Box>
                ) : <>{viewMode.players === 'table' ? renderPlayersTable() : renderPlayersCards()}<Flex justify="space-between" align="center" mt={4}><Text fontSize="sm">Page {playerPage} of {Math.max(1, Math.ceil(playerTotal / playerPageSize))} · {playerTotal} players</Text><HStack><Button size="sm" onClick={() => setPlayerPage((page) => Math.max(1, page - 1))} isDisabled={playerPage === 1}>Previous</Button><Button size="sm" onClick={() => setPlayerPage((page) => page + 1)} isDisabled={playerPage >= Math.ceil(playerTotal / playerPageSize)}>Next</Button></HStack></Flex></>}
              </Stack>
            </TabPanel>

            <TabPanel p={0}>
              <Stack spacing={6}>
                <Flex justify="space-between" align="center" gap={3} direction={{ base: 'column', md: 'row' }}>
                  <Heading as="h3" size="md">Latest Updates</Heading>
                  <HStack>
                    <ViewToggle value={viewMode['latest-updates']} onChange={(next) => setViewMode((current) => ({ ...current, 'latest-updates': next }))} />
                    <Button leftIcon={<AddIcon />} className="btn-primary" colorScheme="brand" onClick={() => openModal('update', null, 'add')}>Add Update</Button>
                  </HStack>
                </Flex>
                {latestUpdatesLoading ? <Stack spacing={3}>{[1, 2, 3].map((item) => <Box key={item} h="56px" bg={modalSoftBg} borderRadius="md" />)}</Stack> : adminLatestUpdates.length === 0 ? <Box border="1px dashed" borderColor="gray.300" borderRadius="xl" p={8} textAlign="center"><Text fontWeight="bold">No latest updates yet</Text><Button mt={3} className="btn-primary" onClick={() => openModal('update', null, 'add')}>Add Update</Button></Box> : viewMode['latest-updates'] === 'table' ? renderLatestUpdateTable() : renderLatestUpdateCards()}
              </Stack>
            </TabPanel>

            <TabPanel p={0}>
              <Stack spacing={6}>
                <Flex justify="space-between" align="center" gap={3} direction={{ base: 'column', md: 'row' }}>
                  <Heading as="h3" size="md">Games</Heading>
                  <HStack>
                    <ViewToggle value={viewMode.games} onChange={(next) => setViewMode((current) => ({ ...current, games: next }))} />
                    <Button leftIcon={<AddIcon />} className="btn-primary" colorScheme="brand" onClick={() => openModal('game', null, 'add')}>Add Game</Button>
                  </HStack>
                </Flex>
                {viewMode.games === 'table' ? renderGameTable() : renderGameCards()}
              </Stack>
            </TabPanel>

            <TabPanel p={0}>
              <Stack spacing={6}>
                <Flex justify="space-between" align="center" gap={3} direction={{ base: 'column', md: 'row' }}>
                  <Box><Heading as="h3" size="md">Partners</Heading><Text fontSize="sm" color={modalMuted}>Visitors only see the logo. Name and category are for internal use and accessibility.</Text></Box>
                  <HStack>
                    <ViewToggle value={viewMode.partners} onChange={(next) => setViewMode((current) => ({ ...current, partners: next }))} />
                    <Button leftIcon={<AddIcon />} className="btn-primary" colorScheme="brand" onClick={() => openModal('partner', null, 'add')}>Add Partner</Button>
                  </HStack>
                </Flex>
                {partnersLoading ? <Stack spacing={3}>{[1, 2, 3].map((item) => <Box key={item} h="56px" bg={modalSoftBg} borderRadius="md" />)}</Stack> : partnersError ? <Box border="1px dashed" borderColor="red.300" borderRadius="xl" p={8} textAlign="center"><Text color="red.500">{partnersError instanceof Error && partnersError.message === 'Supabase is not configured' ? 'Supabase is not configured.' : 'Partners are unavailable right now.'}</Text><Button mt={3} onClick={retryPartners}>Retry</Button></Box> : partners.length === 0 ? <Box border="1px dashed" borderColor="gray.300" borderRadius="xl" p={8} textAlign="center"><Text fontWeight="bold">No partners yet</Text><Button mt={3} className="btn-primary" onClick={() => openModal('partner', null, 'add')}>Add Partner</Button></Box> : viewMode.partners === 'table' ? renderPartnerTable() : renderPartnerCards()}
              </Stack>
            </TabPanel>

            <TabPanel p={0}>
              <Stack spacing={6}>
                <Flex justify="space-between" align="center" gap={3} direction={{ base: 'column', md: 'row' }}>
                  <Heading as="h3" size="md">Events</Heading>
                  <HStack>
                    <ViewToggle value={viewMode.events} onChange={(next) => setViewMode((current) => ({ ...current, events: next }))} />
                    <Button leftIcon={<AddIcon />} className="btn-primary" colorScheme="brand" onClick={() => openModal('event', null, 'add')}>Add Event</Button>
                  </HStack>
                </Flex>
                {eventsLoading ? <Stack spacing={3}>{[1, 2, 3].map((item) => <Box key={item} h="56px" bg={modalSoftBg} borderRadius="md" />)}</Stack> : adminEvents.length === 0 ? <Box border="1px dashed" borderColor="gray.300" borderRadius="xl" p={8} textAlign="center"><Text fontWeight="bold">No events yet</Text><Button mt={3} className="btn-primary" onClick={() => openModal('event', null, 'add')}>Add Event</Button></Box> : viewMode.events === 'table' ? renderEventTable() : renderEventCards()}
              </Stack>
            </TabPanel>

            <TabPanel p={0}>
              <Stack spacing={6}>
                <Flex justify="space-between" align="center" gap={3} direction={{ base: 'column', md: 'row' }}>
                  <Heading as="h3" size="md">Timeline</Heading>
                  <Button className="btn-primary" onClick={() => openModal('timeline', null, 'add')}>Add Milestone</Button>
                </Flex>
                {renderTimelineTable()}
              </Stack>
            </TabPanel>

            <TabPanel p={0}>
              <Stack spacing={6}>
                <Flex justify="space-between" align="center" gap={3} direction={{ base: 'column', md: 'row' }}>
                  <Heading as="h3" size="md">Staffs</Heading>
                  <HStack>
                    <ViewToggle value={viewMode.staffs} onChange={(next) => setViewMode((current) => ({ ...current, staffs: next }))} />
                    <Button leftIcon={<AddIcon />} className="btn-primary" colorScheme="brand" onClick={() => openModal('staff', null, 'add')}>Add Staff</Button>
                  </HStack>
                </Flex>
                {staffLoading ? <Stack spacing={3}>{[1, 2, 3].map((item) => <Box key={item} h="56px" bg={modalSoftBg} borderRadius="md" />)}</Stack> : adminStaff.length === 0 ? <Box border="1px dashed" borderColor="gray.300" borderRadius="xl" p={8} textAlign="center"><Text fontWeight="bold">No staff members yet</Text><Button mt={3} className="btn-primary" onClick={() => openModal('staff', null, 'add')}>Add Staff</Button></Box> : viewMode.staffs === 'table' ? renderStaffTable() : renderStaffCards()}
              </Stack>
            </TabPanel>
          </TabPanels>
        </Tabs>
      </Stack>

      <Modal isOpen={Boolean(modalState)} onClose={handleModalClose} isCentered size="xl">
        <ModalOverlay />
        <ModalContent
          maxW="min(92vw, 1100px)"
          w="min(92vw, 1100px)"
          maxH="90dvh"
          borderRadius="2xl"
          overflow="hidden"
          bg={modalSurface}
        >
          <ModalHeader
            display="flex"
            alignItems="center"
            justifyContent="space-between"
            gap={4}
            borderBottom="1px solid"
            borderColor={modalBorder}
            px={6}
            py={4}
          >
            <Text as="span" fontSize="lg" fontWeight="bold">
              {modalState?.mode === 'view' ? 'View entry' : modalState?.mode === 'edit' ? 'Edit entry' : 'Add entry'}
            </Text>
            <ModalCloseButton position="static" />
          </ModalHeader>
          <ModalBody p={0} overflowY="auto" maxH="calc(90dvh - 140px)">
            <Box p={6}>
              {modalState?.mode === 'view' ? renderEntryDetails(modalState.kind, modalState.item) : renderModalForm()}
            </Box>
          </ModalBody>
          {modalState && modalState.mode !== 'view' && (
            <ModalFooter borderTop="1px solid" borderColor={modalBorder} px={6} py={4}>
              <Button variant="ghost" onClick={handleModalClose}>Cancel</Button>
              <Button className="btn-primary" colorScheme="brand" isDisabled={timelineSaving || gameSaving || gameLogoProcessing || partnerSaving || isImageUploading || partnerProcessing} isLoading={timelineSaving || gameSaving || gameLogoProcessing || partnerSaving || partnerProcessing} onClick={handleSaveModal}>Save</Button>
            </ModalFooter>
          )}
        </ModalContent>
      </Modal>

    </Container>
  )
}

