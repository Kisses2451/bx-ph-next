'use client'

import { Box, Button, Container, Grid, Heading, Skeleton, Text } from '@chakra-ui/react'
import { Reveal } from '../components/Reveal'
import { LogoTile } from '../components/LogoTile'
import { usePartners } from '../hooks/usePartners'

const GROUP_BY_CATEGORY = false

export function PartnersPage() {
  const { partners, isLoading, error, retry } = usePartners()
  return (
    <Container className="shared-container" maxW="none" px={0}>
      <Box className="partners-major-section">
        <Reveal variant="mask-line"><Box className="editorial-section partners-page__header">
          <Text className="editorial-eyebrow">Strategic partners</Text>
          <Heading className="editorial-heading" as="h1">PARTNERS</Heading>
          <Text className="editorial-intro">Partnerships that strengthen the player pathway, support community growth, and move the club forward.</Text>
        </Box></Reveal>

        {isLoading ? <Grid className="partners-logo-wall" templateColumns="repeat(auto-fill, minmax(150px, 200px))" gap={5} justifyContent="start">{[1, 2, 3].map((item) => <Skeleton key={item} className="partners-logo-skeleton" />)}</Grid>
          : error ? <Box className="editorial-card partners-state"><Text className="editorial-card__body">Partners are unavailable right now.</Text><Button onClick={retry} variant="outline" mt={4}>Retry</Button></Box>
            : partners.length === 0 ? <Box className="editorial-card partners-state"><Heading as="h2" size="md">Partnership announcements are coming soon.</Heading></Box>
              : <Grid className="partners-logo-wall" templateColumns="repeat(auto-fill, minmax(150px, 200px))" gap={5} justifyContent="start">{GROUP_BY_CATEGORY ? null : partners.map((partner, index) => <LogoTile key={partner.id} logoUrl={partner.logoUrl} name={partner.name} href={partner.websiteUrl} index={index} />)}</Grid>}
      </Box>
    </Container>
  )
}
