'use client'

import { Box, Container, Heading, Stack, Text } from '@chakra-ui/react'

export function ApplyPage() {
  return (
    <>
      <Container className="shared-container" maxW="none" px={0} py={0}>
        <Box className="editorial-section" position="relative" mb={8}>
          <Stack spacing={4}>
            <Text className="editorial-eyebrow">
              Join now
            </Text>
            <Heading className="editorial-heading" as="h1">
              Become part of the Bloodlust roster.
            </Heading>
            <Text className="editorial-intro">
              Share your profile, upload a headshot, and confirm your application before we review your next opportunity.
            </Text>
          </Stack>
        </Box>
      </Container>
    </>
  )
}
