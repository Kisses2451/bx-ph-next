'use client'

import { CheckCircleIcon } from '@chakra-ui/icons'
import { Box, Button, Container, Heading, Stack, Text, useColorModeValue } from '@chakra-ui/react'
import RouterLink from 'next/link'
import { useEffect, useState } from 'react'
import { LAST_APPLICANT_KEY } from '../lib/applicant'

export function SuccessPage() {
  // react-router passed the applicant via navigation state; Next.js has no
  // equivalent, so ApplyForm stores it in sessionStorage before redirecting.
  const [applicant, setApplicant] = useState<{ name?: string } | null>(null)

  useEffect(() => {
    try {
      const stored = window.sessionStorage.getItem(LAST_APPLICANT_KEY)
      if (stored) {
        setApplicant(JSON.parse(stored))
        window.sessionStorage.removeItem(LAST_APPLICANT_KEY)
      }
    } catch {
      setApplicant(null)
    }
  }, [])
  const surface = useColorModeValue('var(--surface)', 'var(--surface)')
  const border = useColorModeValue('var(--border)', 'var(--border)')

  return (
    <Container className="shared-container" maxW="none" px={0} py={{ base: 12, md: 16 }}>
      <Box maxW="62ch" mx="auto" bg={surface} borderRadius="0" border="1px solid" borderColor={border} p={8} textAlign="center">
        <Stack spacing={4} align="center">
          <CheckCircleIcon color="green.500" boxSize={12} />
          <Heading as="h1" size="lg">
            Application submitted successfully
          </Heading>
          <Text color="gray.600">
            {applicant ? `${applicant.name} has been added to the recruitment queue.` : 'Your player profile has been submitted successfully.'}
          </Text>
          <Button as={RouterLink} className="btn-primary" href="/" colorScheme="brand">
            Return home
          </Button>
        </Stack>
      </Box>
    </Container>
  )
}
