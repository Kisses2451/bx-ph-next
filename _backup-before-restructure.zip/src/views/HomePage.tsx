'use client'

import { ArrowForwardIcon, CalendarIcon, InfoOutlineIcon } from '@chakra-ui/icons'
import { Badge, Box, Button, Container, Heading, Link as ChakraLink, Stack, Text, useColorModeValue } from '@chakra-ui/react'
import { lazy, Suspense, useEffect, useState, type ReactNode } from 'react'
import RouterLink from 'next/link'
import { usePathname } from 'next/navigation'
import { Hero } from '../components/Hero'
import { FeaturedGameCard } from '../components/FeaturedGameCard'
import { HomeMarquee } from '../components/HomeMarquee'
import { Reveal } from '../components/Reveal'
import { usePlayers } from '../context/PlayerContext'
import { supabase } from '../lib/supabase'
import type { SupabaseEvent, SupabaseGame } from '../types/player'
import { useLatestUpdates } from '../hooks/useLatestUpdates'

type AnnouncementFrequency = 'per-session' | 'per-update' | 'always'
const ANNOUNCEMENT_FREQUENCY: AnnouncementFrequency = 'per-session'
const ANNOUNCEMENT_ROUTES = ['/']
const SHOW_TO_ADMINS = false
const ANNOUNCEMENT_SESSION_KEY = 'bx.announcement.seen'
const ANNOUNCEMENT_UPDATE_KEY = 'bx.announcement.lastSeen'
const LatestUpdateAnnouncementModal = lazy(() => import('../components/LatestUpdateAnnouncementModal').then((module) => ({ default: module.LatestUpdateAnnouncementModal })))
let storageUnavailableShown = false

type FeedItem =
  | { type: 'update'; id: string; date: string; tag: string | null; title: string; description: string | null }
  | { type: 'event'; id: string; date: string; title: string; description: string | null; location: string | null }

function SectionCard({ children, ...props }: { children: ReactNode } & Record<string, any>) {
  const className = props.className ? `editorial-card ${props.className}` : 'editorial-card'
  return (
    <Box
      display="flex"
      flexDirection="column"
      className={className}
      overflow="hidden"
      w="100%"
      minH="240px"
      textAlign="left"
      {...props}
    >
      {children}
    </Box>
  )
}

export function HomePage() {
  const surface = useColorModeValue('var(--surface)', 'var(--surface)')
  const border = useColorModeValue('var(--border)', 'var(--border)')
  const muted = useColorModeValue('var(--text-muted)', 'var(--text-muted)')
  const { isAuthenticated } = usePlayers()
  const { updates, latestUpdate, isLoading: updatesLoading, error: updatesError } = useLatestUpdates()
  const pathname = usePathname() ?? '/'
  const [featuredGames, setFeaturedGames] = useState<SupabaseGame[]>([])
  const [gamesLoading, setGamesLoading] = useState(true)
  const [gamesError, setGamesError] = useState(false)
  const [gamesRetryKey, setGamesRetryKey] = useState(0)
  const [upcomingEvents, setUpcomingEvents] = useState<SupabaseEvent[]>([])
  const [eventsLoading, setEventsLoading] = useState(true)
  const [isAnnouncementOpen, setIsAnnouncementOpen] = useState(false)

  useEffect(() => {
    let ignore = false
    const loadGames = async () => {
      setGamesLoading(true)
      setGamesError(false)
      if (!supabase) {
        setGamesLoading(false)
        return
      }
      const { data, error } = await supabase.from('games').select('id,title,image_url').eq('is_visible', true).order('sort_order').order('created_at')
      if (ignore) return
      if (error) {
        console.error('Featured games load failed:', error)
        setGamesError(true)
      } else setFeaturedGames((data ?? []) as SupabaseGame[])
      setGamesLoading(false)
    }
    void loadGames()
    window.addEventListener('games-updated', loadGames)
    return () => { ignore = true; window.removeEventListener('games-updated', loadGames) }
  }, [gamesRetryKey])

  useEffect(() => {
    let ignore = false
    const loadEvents = async () => {
      setEventsLoading(true)
      if (!supabase) {
        setEventsLoading(false)
        return
      }
      const today = new Intl.DateTimeFormat('en-CA', { timeZone: 'Asia/Manila', year: 'numeric', month: '2-digit', day: '2-digit' }).format(new Date())
      const { data, error } = await supabase.from('events').select('id,title,event_date,location,description,image_url').eq('is_visible', true).gte('event_date', today).order('event_date', { ascending: true }).order('sort_order', { ascending: true })
      if (ignore) return
      if (error) console.error('Events load failed:', error)
      else setUpcomingEvents((data ?? []) as SupabaseEvent[])
      setEventsLoading(false)
    }
    void loadEvents()
    window.addEventListener('events-updated', loadEvents)
    return () => { ignore = true; window.removeEventListener('events-updated', loadEvents) }
  }, [])
  const feedItems: FeedItem[] = [
    ...updates.map((item) => ({ type: 'update' as const, id: `update-${item.id}`, date: item.published_at ?? '', tag: item.tag, title: item.title, description: item.description })),
    ...upcomingEvents.map((item) => ({ type: 'event' as const, id: `event-${item.id}`, date: item.event_date, title: item.title, description: item.description, location: item.location })),
  ].sort((first, second) => {
    const firstTime = new Date(first.date).getTime()
    const secondTime = new Date(second.date).getTime()
    return secondTime - firstTime
  })
  const feedLoading = updatesLoading || eventsLoading
  const feedError = updatesError
  const hasFeed = !feedLoading && !feedError && feedItems.length > 0
  const featuredGamesNumber = hasFeed ? '002' : '001'

  useEffect(() => {
    if (updatesLoading || updatesError || !latestUpdate || !ANNOUNCEMENT_ROUTES.includes(pathname) || (!SHOW_TO_ADMINS && isAuthenticated)) return
    const forceShow = new URLSearchParams(window.location.search).get('announcement') === '1'
    const seenValue = `${latestUpdate.id}:${latestUpdate.updated_at ?? ''}`
    let shouldShow = forceShow || ANNOUNCEMENT_FREQUENCY === 'always'

    if (!shouldShow) {
      try {
        const storage = ANNOUNCEMENT_FREQUENCY === 'per-session' ? window.sessionStorage : window.localStorage
        const key = ANNOUNCEMENT_FREQUENCY === 'per-session' ? ANNOUNCEMENT_SESSION_KEY : ANNOUNCEMENT_UPDATE_KEY
        shouldShow = storage.getItem(key) !== seenValue
      } catch {
        shouldShow = !storageUnavailableShown
      }
    }

    if (!shouldShow) return
    const timer = window.setTimeout(() => {
      if (document.querySelector('[role="dialog"]')) return
      setIsAnnouncementOpen(true)
    }, 400)
    return () => window.clearTimeout(timer)
  }, [isAuthenticated, latestUpdate, pathname, updatesError, updatesLoading])

  const closeAnnouncement = () => {
    if (latestUpdate && ANNOUNCEMENT_FREQUENCY !== 'always') {
      const seenValue = `${latestUpdate.id}:${latestUpdate.updated_at ?? ''}`
      try {
        const storage = ANNOUNCEMENT_FREQUENCY === 'per-session' ? window.sessionStorage : window.localStorage
        const key = ANNOUNCEMENT_FREQUENCY === 'per-session' ? ANNOUNCEMENT_SESSION_KEY : ANNOUNCEMENT_UPDATE_KEY
        storage.setItem(key, seenValue)
      } catch {
        storageUnavailableShown = true
      }
    }
    setIsAnnouncementOpen(false)
  }

  return (
    <>
      <Hero />
      <HomeMarquee games={featuredGames} gamesLoading={gamesLoading} gamesError={gamesError} />
      <Container className="shared-container home-page" maxW="none" px={0}>
        <Stack spacing={0}>
          {hasFeed ? <Box className="editorial-section" id="latest-updates">
            <Reveal variant="slide-left"><Text className="editorial-eyebrow">001</Text><Heading className="editorial-heading" as="h2">THE FEED.</Heading><Text className="editorial-intro">The latest word from Bloodlust Philippines, alongside what is coming up next.</Text></Reveal>
            <Box className="editorial-feed">
              {feedItems.map((item, index) => index === 0 ? <Reveal key={item.id} variant="scale-in"><SectionCard className="editorial-feed__featured" bg={surface} borderColor={border}>
                <Badge className={`editorial-feed__badge editorial-feed__badge--${item.type}`} colorScheme={item.type === 'update' ? 'blue' : 'orange'}>{item.type === 'update' ? <InfoOutlineIcon mr={1} /> : <CalendarIcon mr={1} />} {item.type === 'update' ? 'UPDATE' : 'EVENT'}</Badge>
                <Text className="editorial-card__number">{item.date ? new Date(item.date).toLocaleDateString('en-PH', { dateStyle: 'medium' }) : 'Latest'}</Text>
                <Heading className="editorial-card__title" as="h3" noOfLines={2}>{item.title}</Heading>
                {item.type === 'event' && item.location ? <Text className="editorial-card__body" color={muted}>{item.location}</Text> : null}
                <Text className="editorial-card__body" color={muted} noOfLines={4}>{item.description ?? ''}</Text>
              </SectionCard></Reveal> : <Reveal key={item.id} index={index - 1}><Box className="editorial-feed__row">
                <Badge className={`editorial-feed__badge editorial-feed__badge--${item.type}`} colorScheme={item.type === 'update' ? 'blue' : 'orange'}>{item.type === 'update' ? <InfoOutlineIcon mr={1} /> : <CalendarIcon mr={1} />} {item.type === 'update' ? 'UPDATE' : 'EVENT'}</Badge>
                <Text className="editorial-feed__date">{item.date ? new Date(item.date).toLocaleDateString('en-PH', { month: 'short', day: 'numeric', year: 'numeric' }) : 'Latest'}</Text>
                <Box><Heading className="editorial-card__title" as="h4" size="md">{item.title}</Heading>{item.type === 'event' && item.location ? <Text className="editorial-card__body" color={muted}>{item.location}</Text> : null}{item.description ? <Text className="editorial-card__body" color={muted} noOfLines={2}>{item.description}</Text> : null}</Box>
              </Box></Reveal>)}
            </Box>
          </Box> : null}

          {gamesLoading ? <Box className="editorial-section featured-games-section"><Text className="editorial-eyebrow">{featuredGamesNumber}</Text><Heading className="editorial-heading" as="h2">FEATURED GAMES</Heading><Box className="featured-games-grid" aria-hidden="true">{[1, 2, 3].map((item) => <Box key={item} className="featured-game-skeleton" />)}</Box></Box> : gamesError ? <Box className="editorial-section featured-games-section"><Text className="editorial-card__body">Featured games are unavailable right now.</Text><Button onClick={() => setGamesRetryKey((key) => key + 1)} variant="outline" mt={4}>Retry</Button></Box> : featuredGames.length > 0 ? <Box className="editorial-section featured-games-section">
            <Reveal variant="scale-in"><Text className="editorial-eyebrow">{featuredGamesNumber}</Text><Heading className="editorial-heading" as="h2">FEATURED GAMES</Heading></Reveal>
            <Text className="featured-games-watermark" aria-hidden="true">PLAY</Text>
            <Box as="ul" role="list" className="featured-games-grid">
              {featuredGames.map((game) => <Box as="li" key={game.id}><FeaturedGameCard game={game} /></Box>)}
            </Box>
          </Box> : null}

          <Reveal variant="scale-in"><Box className="editorial-section surface-band home-cta-section" color="var(--text)" px={{ base: 5, md: 10 }}>
            <Text className="editorial-eyebrow">
              Ready to rise?
            </Text>
            <Heading as="h3" size="lg" mt={3}>
              Bring your next opportunity to the front line.
            </Heading>
            <ChakraLink className="editorial-link" as={RouterLink} href="/join" onClick={(event) => { event.preventDefault(); window.dispatchEvent(new CustomEvent('open-join-flow', { detail: event.currentTarget })) }}>
              Start your application <ArrowForwardIcon />
            </ChakraLink>
          </Box></Reveal>
        </Stack>
      </Container>
      {latestUpdate && isAnnouncementOpen ? <Suspense fallback={null}><LatestUpdateAnnouncementModal update={latestUpdate} isOpen={isAnnouncementOpen} keepSection={hasFeed} onClose={closeAnnouncement} /></Suspense> : null}
    </>
  )
}
